# Đánh giá chiến lược & lộ trình nâng cao chất lượng tín hiệu

> Góc nhìn của một trader chuyên nghiệp, soi vào code thật (`pattern_detector.py`,
> `strategy_router.py`, `learner_v2.py`, `risk_manager.py`). Mục tiêu: **vào lệnh
> sớm hơn, lọc nhiễu tốt hơn, không phá vỡ kỷ luật rủi ro**.

---

## 1. Điểm mạnh hiện tại (giữ nguyên)

- **Hai chiến lược bổ trợ**: Daily Reversal (mean-reversion) + LTR (liquidity sweep) — khi đồng thuận (confluence) là setup chất lượng cao.
- **Learner Bayesian** gate theo confidence — tự bỏ qua bucket thua, không cần can thiệp tay.
- **Meta-learner** phân bổ vốn theo expected-R thực tế từng strategy.
- **Risk-first**: split TP 50/30/20, SL = extreme ± buffer, cooldown per-symbol. Đây là nền tảng đúng — đa số bot retail chết vì thiếu cái này.

---

## 2. Vấn đề LỚN NHẤT — độ trễ tín hiệu (đúng câu hỏi của anh)

**Đây là gốc rễ của "vào lệnh muộn".** Trong `pattern_detector.py`:

```python
rev = (high - cur_low) / high * 100.0
if reversal_min_pct <= rev <= reversal_max_pct:   # reversal_min = 1.2%
    trig_price = high * (1 - reversal_min_pct/100)
```

Bot **chờ giá đảo chiều ĐỦ 1.2% từ đỉnh** rồi mới kích hoạt. Nghĩa là:

- Khi tín hiệu fire, giá đã đi 1.2% theo hướng anh muốn → **anh ăn phần giữa, mất phần đầu ngon nhất**
- Risk:Reward bị bóp: SL vẫn tính từ extreme (xa), nhưng entry đã muộn → R thực tế nhỏ hơn lý thuyết
- Nếu reversal nhanh & mạnh, có khi chạm `reversal_max` (6.5%) trước cả khi bot kịp 1 nến → bỏ lỡ hoàn toàn

### Hướng khắc phục (xếp theo tỷ lệ lợi ích/rủi ro)

**A. Early-warning trigger 2 tầng (KHUYẾN NGHỊ #1)**
- Tầng cảnh báo: khi `rev >= 0.5%` (chưa đủ 1.2%) **VÀ** nến hiện tại đóng ngược hướng push gốc → bot phát "early signal", đặt **limit order chờ** tại vùng pullback thay vì market khi đã muộn.
- Tầng xác nhận: giữ logic 1.2% làm fallback nếu limit không khớp.
- Lợi: vào sớm 0.5–0.7%, cải thiện R trung bình ~30–50% mà không tăng số lệnh xấu (vì vẫn cần nến xác nhận).

**B. Momentum exhaustion thay vì % cứng**
- Thay "đảo 1.2%" bằng tín hiệu **kiệt sức động lượng** tại extreme: RSI phân kỳ, nến rejection (wick dài), volume giảm dần trên đoạn push.
- LTR đã có một phần (rejection wick) — kéo logic này sang base reversal để fire **ngay tại đỉnh/đáy** thay vì chờ giá quay đầu.

**C. ATR-normalized thresholds (QUAN TRỌNG cho đa token)**
- `initial_move_pct = 1.05%` nghĩa khác nhau hoàn toàn giữa BTC (vol thấp) và DOGE/ASTER (vol cao).
- Đổi sang **bội số ATR**: `initial_move >= 1.2 × ATR(14)`. BTC sẽ trigger ở ~0.8%, DOGE ở ~2.5% — đúng đặc tính từng coin → ít nhiễu hơn, bắt đúng "bất thường" thật.

---

## 3. Vấn đề neo giá theo daily-open (cấu trúc)

Dùng giá mở cửa ngày GMT+7 làm mốc tạo **điểm gãy lúc 00:00**: một cú pump bắt đầu 23:00 bị "reset" lúc nửa đêm → bỏ lỡ hoặc tính sai initial_move.

**Hướng:** thêm mốc tham chiếu **rolling** song song:
- VWAP 24h trượt, hoặc
- High/Low của 24h gần nhất (không cắt theo lịch)

Giữ daily-open cho backtest tương thích, nhưng cho live ưu tiên rolling anchor → bắt được reversal xuyên đêm.

---

## 4. Thiếu xác nhận orderflow ở base reversal

Base reversal là **pure price** — không nhìn volume/CVD/OI. Đây là nguồn false signal lớn nhất (giá đảo do nhiễu, không phải do dòng tiền thật đảo).

**Hướng:** đưa 3 confirm của LTR vào base reversal làm **bộ lọc cộng điểm** (không bắt buộc, cộng vào confidence):
- Funding z-score ngược chiều push (đám đông kẹt)
- OI giảm khi giá đảo (đóng vị thế bắt buộc)
- CVD divergence (delta mua/bán phân kỳ với giá)

Learner_v2 đã có context vector chứa các feature này — chỉ cần đảm bảo base reversal cũng nạp đủ context khi `record_outcome`.

---

## 5. Entry execution — đang để lại tiền trên bàn

Hiện vào **1 lệnh market tại trigger**. Nâng cấp:

- **Scale-in 2 phần**: 60% tại trigger, 40% tại limit sâu hơn 0.3–0.5% (nếu giá còn pullback) → giá vốn tốt hơn.
- **Maker-first**: đặt post-only limit, chỉ market khi sắp hết cửa sổ → tiết kiệm 5–10 bps phí mỗi lệnh, cộng dồn đáng kể.
- `executor` đã có `limit_offset_bps` — mở rộng thành thuật toán 2 chân.

---

## 6. Quản trị rủi ro nâng cao (bảo vệ vốn)

- **Trailing sau TP1**: sau khi chốt 50% tại 1R, dời SL về breakeven → biến lệnh thành "free trade", tâm lý + bảo toàn vốn.
- **Daily loss limit**: nếu thua > X% equity/ngày → dừng vào lệnh mới đến hết ngày (chống chuỗi thua trong regime xấu).
- **Regime filter cứng**: meta-learner đã giảm size khi strategy yếu; thêm hard-stop khi BTC regime = "high-vol chop" (reversal chết trong choppy).
- **Correlation cap**: 10 token nhưng BTC/ETH/SOL tương quan cao → giới hạn tổng exposure cùng chiều (tránh "1 lệnh × 5 lần").

---

## 7. Lộ trình triển khai đề xuất (ưu tiên)

| Ưu tiên | Hạng mục | Công sức | Tác động |
|---|---|---|---|
| 🔴 P1 | Early-warning 2 tầng (mục 2A) | Trung bình | Cao — vào sớm, tăng R |
| 🔴 P1 | ATR-normalized thresholds (2C) | Thấp | Cao — giảm nhiễu đa token |
| 🟠 P2 | Orderflow confirm vào base reversal (4) | Trung bình | Cao — lọc false signal |
| 🟠 P2 | Trailing BE sau TP1 (6) | Thấp | Trung bình — bảo vệ vốn |
| 🟡 P3 | Rolling anchor (3) | Trung bình | Trung bình |
| 🟡 P3 | Scale-in 2 chân (5) | Cao | Trung bình |
| 🟢 P4 | Daily loss limit + correlation cap (6) | Thấp | Cao về dài hạn |

---

## 8. Cảnh báo trung thực (honest failure modes)

- **Edge sẽ phân rã.** Reversal pattern phổ biến → bị arb. Learner bù một phần nhưng phải theo dõi expected-R hàng tuần; nếu âm 30 lệnh liên tiếp → tạm dừng, review.
- **Vào sớm hơn = nhiều false signal hơn** nếu không kèm bộ lọc orderflow. P1 (early-warning) PHẢI đi cùng P2 (confirm), không làm lẻ.
- **ATR-normalized cần re-backtest** toàn bộ — đừng deploy thẳng lên live, chạy walk-forward 6–12 tháng trước.
- **Bot này không phải máy in tiền.** Nó là khung kỷ luật + học máy. Lợi nhuận đến từ việc thực thi nhất quán một edge mỏng qua nhiều lệnh, không phải từ 1 lệnh lớn.

---

*Sẵn sàng triển khai bất kỳ hạng mục P1/P2 nào khi anh quyết định — sẽ làm trên nhánh riêng + backtest trước khi đụng vào live.*
