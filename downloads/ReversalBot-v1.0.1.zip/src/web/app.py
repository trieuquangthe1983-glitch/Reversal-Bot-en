"""FastAPI app exposing the bot DB as JSON + serving the index.html SPA.

Routes
------
GET  /                              -> index.html
GET  /api/health                    -> {ok}
POST /api/login                     -> sets `session` cookie
POST /api/logout
GET  /api/me

POST /api/vault/unlock              -> stores VaultSession in memory for this session
POST /api/vault/lock
GET  /api/vault/status

GET    /api/users                   (admin)
POST   /api/users                   (admin) -- create user
DELETE /api/users/{user_id}         (admin)

GET    /api/keys                    -- list (masked) for current user
POST   /api/keys                    (vault) -- add new key
POST   /api/keys/{id}/enable-live   -- two-step confirm
POST   /api/keys/{id}/test          (vault) -- fetch_balance on exchange
DELETE /api/keys/{id}

GET    /api/parameters              -- all active overrides
POST   /api/parameters              -- set
GET    /api/parameters/{ns}/{key}/history

GET    /api/trades?status=&limit=
GET    /api/trades/summary
GET    /api/patterns?limit=
GET    /api/learner-buckets
GET    /api/equity?limit=
GET    /api/audit?event=&limit=
GET    /api/dashboard               -- aggregate stats for landing page
"""
from __future__ import annotations
from pathlib import Path
from typing import Any, Optional

from contextlib import asynccontextmanager

from fastapi import Body, Depends, FastAPI, HTTPException, Response, status
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from datetime import datetime, timezone

from ..db import (ApiKeyRepo, AuditRepo, EquityRepo, LearnerRepo,
                 ParameterRepo, PatternRepo, PortfolioSnapshotRepo, TradeRepo,
                 TuningRepo, UserRepo, WatchlistRepo, init_db)
from ..db.connection import DB_PATH
from ..db.repositories import SessionRepo
from ..licensing import (LicenseManager, LicenseStatus, TIERS, tier_info,
                         machine_id, machine_fingerprint_blob,
                         LicenseCodeError, PaymentVerifyError,
                         LicenseServerError)
from ..licensing.manager import LicenseRateLimitError
from ..utils import PROJECT_ROOT, setup_logger
from .deps import (drop_vault_session, get_vault_session, require_admin,
                  require_session, require_vault, store_vault_session,
                  require_active_license)

log = setup_logger("web")


@asynccontextmanager
async def _lifespan(app: FastAPI):
    if not DB_PATH.exists():
        init_db()
    log.info("web UI started, DB=%s", DB_PATH)
    yield


app = FastAPI(title="Crypto Reversal Bot — Dashboard", version="0.1.0",
              lifespan=_lifespan)


# =========================================================================
# Cookie sliding refresh
# =========================================================================
# Browser keeps the cookie for 30 days, but the DB session has an 8h
# sliding TTL — the server is authoritative. On every successful authed
# request we re-emit the cookie so the browser's expiry also slides.
COOKIE_MAX_AGE = 30 * 24 * 3600


@app.middleware("http")
async def _refresh_session_cookie(request, call_next):
    response = await call_next(request)
    # Only refresh if a valid session cookie came in AND response is success.
    session_token = request.cookies.get("session")
    if (session_token and 200 <= response.status_code < 400
            and not request.url.path.startswith("/api/logout")):
        response.set_cookie(
            key="session", value=session_token,
            httponly=True, samesite="lax", secure=False,
            max_age=COOKIE_MAX_AGE, path="/",
        )
    return response


# =========================================================================
# Pydantic schemas
# =========================================================================
class LoginIn(BaseModel):
    username: str
    password: str


class VaultIn(BaseModel):
    password: str


class CreateUserIn(BaseModel):
    username: str
    password: str
    role: str = "user"


class AddKeyIn(BaseModel):
    label: str
    exchange: str = "okx"      # okx | gateio | binance | bybit ...
    api_key: str
    secret: str
    passphrase: str = ""        # not used for gateio/binance
    is_testnet: bool = True


class EnableLiveIn(BaseModel):
    confirm_token: str


class ParamSetIn(BaseModel):
    namespace: str
    key: str
    value: Any
    description: str = ""


class ChangePasswordIn(BaseModel):
    old_password: str
    new_password: str


class WatchlistAddIn(BaseModel):
    token: str
    binance_symbol: str
    okx_symbol: Optional[str] = None
    gateio_symbol: Optional[str] = None
    enabled: bool = True
    max_position_size_usdt: Optional[float] = None
    cooldown_hours_override: Optional[float] = None
    notes: str = ""


class WatchlistUpdateIn(BaseModel):
    binance_symbol: Optional[str] = None
    okx_symbol: Optional[str] = None
    gateio_symbol: Optional[str] = None
    enabled: Optional[bool] = None
    max_position_size_usdt: Optional[float] = None
    cooldown_hours_override: Optional[float] = None
    notes: Optional[str] = None


class CalculateOrderIn(BaseModel):
    symbol: str
    side: str                          # LONG | SHORT
    entry: float
    sl: Optional[float] = None         # absolute price
    sl_pct: Optional[float] = None     # OR distance from entry in %
    equity_usdt: float
    risk_per_trade_pct: float = 0.5
    max_leverage: int = 10
    tp_r_multiples: list[float] = [1.0, 2.0, 3.0]


# =========================================================================
# Health + static
# =========================================================================
@app.get("/api/health")
def health():
    return {"ok": True, "db": str(DB_PATH), "db_exists": DB_PATH.exists()}


# =========================================================================
# Auth
# =========================================================================
@app.post("/api/login")
def login(payload: LoginIn, response: Response):
    try:
        user = UserRepo.authenticate(payload.username, payload.password)
    except ValueError as e:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, str(e))
    token = SessionRepo.create(user["id"])
    response.set_cookie(
        key="session", value=token,
        httponly=True, samesite="lax", secure=False,   # secure=True if HTTPS
        max_age=COOKIE_MAX_AGE, path="/",
    )
    return {
        "ok": True,
        "user": {"id": user["id"], "username": user["username"], "role": user["role"]},
    }


@app.post("/api/logout")
def logout(response: Response, ctx: dict = Depends(require_session)):
    drop_vault_session(ctx["token"])
    SessionRepo.revoke(ctx["token"])
    response.delete_cookie("session")
    return {"ok": True}


@app.get("/api/me")
def me(ctx: dict = Depends(require_session)):
    vs = get_vault_session(ctx["token"])
    return {
        "user": {
            "id": ctx["user"]["id"], "username": ctx["user"]["username"],
            "role": ctx["user"]["role"], "last_login_at": ctx["user"]["last_login_at"],
        },
        "vault_unlocked": vs is not None,
    }


# =========================================================================
# Vault
# =========================================================================
@app.post("/api/vault/unlock")
def vault_unlock(payload: VaultIn, ctx: dict = Depends(require_session)):
    try:
        vs = UserRepo.unlock_vault(ctx["user"]["username"], payload.password)
    except ValueError as e:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(e))
    store_vault_session(ctx["token"], vs)
    return {"ok": True, "unlocked": True}


@app.post("/api/vault/lock")
def vault_lock(ctx: dict = Depends(require_session)):
    drop_vault_session(ctx["token"])
    return {"ok": True, "unlocked": False}


@app.get("/api/vault/status")
def vault_status(ctx: dict = Depends(require_session)):
    return {"unlocked": get_vault_session(ctx["token"]) is not None}


# =========================================================================
# Users (admin)
# =========================================================================
@app.get("/api/users")
def list_users(ctx: dict = Depends(require_admin)):
    return UserRepo.list_all()


@app.post("/api/users")
def create_user(payload: CreateUserIn, ctx: dict = Depends(require_admin)):
    try:
        u = UserRepo.create(payload.username, payload.password, payload.role)
    except ValueError as e:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(e))
    return {"id": u["id"], "username": u["username"], "role": u["role"]}


@app.delete("/api/users/{user_id}")
def delete_user(user_id: int, ctx: dict = Depends(require_admin)):
    if user_id == ctx["user"]["id"]:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "cannot delete yourself")
    UserRepo.delete(user_id)
    return {"ok": True}


# =========================================================================
# API Keys
# =========================================================================
@app.get("/api/keys")
def list_keys(ctx: dict = Depends(require_session)):
    return ApiKeyRepo.list_for_user(ctx["user"]["id"])


@app.post("/api/keys")
def add_key(payload: AddKeyIn, both = Depends(require_vault)):
    ctx, vs = both
    try:
        k = ApiKeyRepo.add(
            user_id=ctx["user"]["id"], label=payload.label,
            exchange=payload.exchange.lower(),
            api_key=payload.api_key, secret=payload.secret,
            passphrase=payload.passphrase, is_testnet=payload.is_testnet,
            is_live_enabled=False, vault_sess=vs,
        )
    except Exception as e:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(e))
    return {"id": k["id"], "label": k["label"], "masked": k["api_key_masked"]}


@app.post("/api/keys/{key_id}/enable-live")
def enable_live(key_id: int, payload: EnableLiveIn,
               ctx: dict = Depends(require_session)):
    try:
        ApiKeyRepo.enable_live(key_id, ctx["user"]["id"], payload.confirm_token)
    except ValueError as e:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(e))
    return {"ok": True}


@app.post("/api/keys/{key_id}/test")
def test_key(key_id: int, both = Depends(require_vault)):
    ctx, vs = both
    k = ApiKeyRepo.get(key_id)
    if not k or k["user_id"] != ctx["user"]["id"]:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "no such key")
    try:
        creds = ApiKeyRepo.get_decrypted(key_id, vs)
        ex = _build_ccxt(k, creds)
        bal = _fetch_balance_for(ex, k["exchange"])
        usdt = bal.get("USDT", {}) or {}
        return {"ok": True, "free_usdt": float(usdt.get("free", 0) or 0),
                "total_usdt": float(usdt.get("total", 0) or 0)}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, f"exchange call failed: {e}")


@app.delete("/api/keys/{key_id}")
def delete_key(key_id: int, ctx: dict = Depends(require_session)):
    ApiKeyRepo.delete(key_id, ctx["user"]["id"])
    return {"ok": True}


# =========================================================================
# Parameters
# =========================================================================
@app.get("/api/parameters")
def list_params(ctx: dict = Depends(require_session)):
    return ParameterRepo.all_active()


@app.post("/api/parameters")
def set_param(payload: ParamSetIn, ctx: dict = Depends(require_session)):
    p = ParameterRepo.set(payload.namespace, payload.key, payload.value,
                         user_id=ctx["user"]["id"],
                         description=payload.description)
    return {"ok": True, "value": p["value"], "set_at": p["set_at"]}


@app.get("/api/parameters/{namespace}/{key}/history")
def param_history(namespace: str, key: str, limit: int = 20,
                 ctx: dict = Depends(require_session)):
    return ParameterRepo.history(namespace, key, limit=limit)


# =========================================================================
# Read-only data
# =========================================================================
@app.get("/api/trades")
def list_trades(status_filter: Optional[str] = None, limit: int = 100,
               ctx: dict = Depends(require_session)):
    if status_filter == "open":
        return TradeRepo.open_positions()
    return TradeRepo.recent_closed(limit=limit)


@app.get("/api/trades/summary")
def trade_summary(ctx: dict = Depends(require_session)):
    return TradeRepo.summary_by_symbol()


@app.get("/api/patterns")
def list_patterns(limit: int = 100, ctx: dict = Depends(require_session)):
    return PatternRepo.recent(limit=limit)


@app.get("/api/learner-buckets")
def list_buckets(ctx: dict = Depends(require_session)):
    return LearnerRepo.list_buckets()


@app.get("/api/equity")
def list_equity(limit: int = 200, ctx: dict = Depends(require_session)):
    return EquityRepo.recent(limit=limit)


@app.get("/api/audit")
def list_audit(event: Optional[str] = None, limit: int = 100,
              ctx: dict = Depends(require_admin)):
    return AuditRepo.recent(limit=limit, event_type=event)


@app.get("/api/dashboard")
def dashboard(ctx: dict = Depends(require_session)):
    """Aggregate stats for landing page."""
    summary = TradeRepo.summary_by_symbol()
    open_pos = TradeRepo.open_positions()
    eq = EquityRepo.recent(limit=1)
    buckets = LearnerRepo.list_buckets()
    total_trades = sum(s["n"] for s in summary)
    total_r = sum((s["total_r"] or 0) for s in summary)
    total_wins = sum(s["wins"] for s in summary)
    return {
        "totals": {
            "trades_closed": total_trades,
            "wins": total_wins,
            "win_rate": round(total_wins / total_trades, 3) if total_trades else 0,
            "total_r": round(total_r, 2),
            "open_positions": len(open_pos),
            "learner_buckets": len(buckets),
        },
        "by_symbol": summary,
        "open_positions": open_pos[:10],
        "latest_equity": eq[0] if eq else None,
    }


# =========================================================================
# Password changes
# =========================================================================
@app.post("/api/users/me/password")
def change_login_password(payload: ChangePasswordIn,
                          ctx: dict = Depends(require_session)):
    try:
        UserRepo.change_password(ctx["user"]["id"],
                                payload.old_password, payload.new_password)
    except ValueError as e:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(e))
    return {"ok": True, "message": "login password changed"}


@app.post("/api/users/me/vault-password")
def change_vault_password(payload: ChangePasswordIn,
                          ctx: dict = Depends(require_session)):
    try:
        n = UserRepo.change_vault_password(
            ctx["user"]["id"], payload.old_password, payload.new_password,
        )
    except ValueError as e:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(e))
    except RuntimeError as e:
        raise HTTPException(status.HTTP_500_INTERNAL_SERVER_ERROR, str(e))
    # Old vault session is no longer valid -- force re-unlock
    from .deps import drop_vault_session
    drop_vault_session(ctx["token"])
    return {"ok": True, "n_keys_rotated": n,
            "message": "vault password changed; please unlock again"}


# =========================================================================
# Watchlist
# =========================================================================
@app.get("/api/watchlist")
def list_watchlist(enabled_only: bool = False,
                  ctx: dict = Depends(require_session)):
    return WatchlistRepo.list_all(enabled_only=enabled_only)


@app.post("/api/watchlist")
def add_watchlist(payload: WatchlistAddIn,
                 ctx: dict = Depends(require_session)):
    try:
        w = WatchlistRepo.add(
            token=payload.token, binance_symbol=payload.binance_symbol,
            okx_symbol=payload.okx_symbol, gateio_symbol=payload.gateio_symbol,
            enabled=payload.enabled,
            max_position_size_usdt=payload.max_position_size_usdt,
            cooldown_hours_override=payload.cooldown_hours_override,
            notes=payload.notes, user_id=ctx["user"]["id"],
        )
    except ValueError as e:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(e))
    return w


@app.put("/api/watchlist/{wid}")
def update_watchlist(wid: int, payload: WatchlistUpdateIn,
                    ctx: dict = Depends(require_session)):
    fields = {k: v for k, v in payload.model_dump().items() if v is not None}
    try:
        w = WatchlistRepo.update(wid, fields, user_id=ctx["user"]["id"])
    except ValueError as e:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(e))
    return w


@app.post("/api/watchlist/{wid}/toggle")
def toggle_watchlist(wid: int, ctx: dict = Depends(require_session)):
    try:
        return WatchlistRepo.toggle(wid, user_id=ctx["user"]["id"])
    except ValueError as e:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(e))


@app.delete("/api/watchlist/{wid}")
def delete_watchlist(wid: int, ctx: dict = Depends(require_session)):
    try:
        WatchlistRepo.delete(wid, user_id=ctx["user"]["id"])
    except ValueError as e:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(e))
    return {"ok": True}


# =========================================================================
# Portfolio (live fetch from exchange)
# =========================================================================
def _build_ccxt(chosen: dict, creds: dict):
    """Build a ccxt client for the given key row. Handles per-exchange
    quirks (Gate.io unified account, OKX passphrase, etc.)."""
    import ccxt
    name = (chosen["exchange"] or "okx").lower()
    try:
        ex_class = getattr(ccxt, name)
    except AttributeError:
        raise HTTPException(400, f"unsupported exchange: {name}")

    cfg = {
        "apiKey": creds["api_key"],
        "secret": creds["secret"],
        "enableRateLimit": True,
        "options": {"defaultType": "swap"},
    }
    if name == "okx":
        cfg["password"] = creds.get("passphrase", "")
    if name in ("gateio", "gate"):
        # Gate.io unified perp: USDT-settled swap pool. Unified Account
        # mode is read separately in _fetch_balance_for.
        cfg["options"]["defaultSettle"] = "usdt"

    ex = ex_class(cfg)
    if chosen["is_testnet"]:
        ex.set_sandbox_mode(True)
    return ex


def _fetch_balance_for(ex, exchange_name: str) -> dict:
    """Fetch balance. For Gate.io, prefer Unified Account pool (spot+future
    share one collateral); fall back to swap-subaccount if not enabled."""
    name = (exchange_name or "").lower()
    if name in ("gateio", "gate"):
        try:
            bal = ex.fetch_balance(params={"unifiedAccount": True})
            # If unified pool empty AND swap pool has funds, fall back.
            usdt = bal.get("USDT", {}) or {}
            if not (usdt.get("total") or 0):
                fb = ex.fetch_balance()
                if (fb.get("USDT", {}) or {}).get("total"):
                    return fb
            return bal
        except Exception:
            return ex.fetch_balance()
    return ex.fetch_balance()


def _pick_key(keys: list[dict], key_id: Optional[int]) -> dict:
    if key_id:
        chosen = next((k for k in keys if k["id"] == key_id), None)
        if not chosen:
            raise HTTPException(404, f"key id {key_id} not found for this user")
        return chosen
    # Prefer testnet, prefer most-recently-used
    return sorted(keys, key=lambda k: (
        not k["is_testnet"],
        -(int(bool(k["last_used_at"])) or 0),
        -k["id"],
    ))[0]


@app.get("/api/portfolio")
def portfolio(key_id: Optional[int] = None,
              snapshot: bool = True,
              both = Depends(require_vault)):
    """Fetch real balances + open positions from the exchange.

    Optionally pass ?key_id=N to choose a specific key; else picks the
    most-recently-used (or first) key. Each successful fetch is logged
    to portfolio_snapshots unless ?snapshot=false is passed.
    """
    ctx, vs = both
    keys = ApiKeyRepo.list_for_user(ctx["user"]["id"])
    if not keys:
        raise HTTPException(404, "no API keys configured")
    chosen = _pick_key(keys, key_id)

    creds = ApiKeyRepo.get_decrypted(chosen["id"], vs)
    ex = _build_ccxt(chosen, creds)

    # Resilient: a failing balance call should NOT blank the whole tab.
    # We return partial data + a `warnings` list so the UI can show what it
    # has and surface the error inline (instead of a hard 400).
    warnings: list[str] = []
    bal = {}
    try:
        bal = _fetch_balance_for(ex, chosen["exchange"])
    except Exception as e:
        msg = str(e)
        hint = ""
        if "Invalid Sign" in msg or "50113" in msg:
            hint = (" — API secret or passphrase looks wrong, or the key's "
                    "testnet flag doesn't match. Re-add the key.")
        elif "Unified" in msg or "unified" in msg:
            hint = " — enable Unified Account on the exchange web UI first."
        warnings.append(f"balance fetch failed: {msg}{hint}")

    try:
        positions = ex.fetch_positions()
    except Exception as e:
        positions = []
        warnings.append(f"positions fetch failed: {e}")

    holdings = []
    for coin, b in bal.items():
        if not isinstance(b, dict):
            continue
        total = b.get("total")
        if total is None or total == 0:
            continue
        holdings.append({
            "coin": coin,
            "free": float(b.get("free") or 0),
            "used": float(b.get("used") or 0),
            "total": float(total),
        })
    holdings.sort(key=lambda h: -h["total"])

    open_pos = []
    total_unrealized = 0.0
    for p in positions:
        contracts = p.get("contracts") or 0
        if not contracts:
            continue
        upnl = float(p.get("unrealizedPnl") or 0)
        total_unrealized += upnl
        open_pos.append({
            "symbol": p.get("symbol"),
            "side": (p.get("side") or "").upper(),
            "contracts": float(contracts),
            "entry_price": float(p.get("entryPrice") or 0),
            "mark_price": float(p.get("markPrice") or 0),
            "unrealized_pnl": upnl,
            "leverage": p.get("leverage"),
            "notional": float(p.get("notional") or 0),
        })

    usdt = bal.get("USDT", {}) or {}
    free_usdt = float(usdt.get("free") or 0)
    used_usdt = float(usdt.get("used") or 0)
    total_usdt = float(usdt.get("total") or 0)
    total_equity = total_usdt + total_unrealized

    result = {
        "key_used": {
            "id": chosen["id"], "label": chosen["label"],
            "exchange": chosen["exchange"],
            "is_testnet": bool(chosen["is_testnet"]),
            "is_live_enabled": bool(chosen["is_live_enabled"]),
        },
        "free_usdt": free_usdt,
        "used_usdt": used_usdt,
        "total_usdt": total_usdt,
        "total_equity_usdt": total_equity,
        "total_unrealized_pnl": total_unrealized,
        "holdings": holdings,
        "positions": open_pos,
        "warnings": warnings,
        "ok": len(warnings) == 0,
        "fetched_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    }

    # Only snapshot when the balance call actually succeeded — don't pollute
    # history with empty rows from a transient auth failure.
    if snapshot and not warnings:
        try:
            snap_id = PortfolioSnapshotRepo.record(
                user_id=ctx["user"]["id"], key_id=chosen["id"],
                exchange=chosen["exchange"], is_testnet=bool(chosen["is_testnet"]),
                free_usdt=free_usdt, used_usdt=used_usdt,
                total_usdt=total_usdt, total_equity_usdt=total_equity,
                unrealized_pnl=total_unrealized,
                open_positions_count=len(open_pos),
                holdings=holdings, positions=open_pos,
                source="manual",
            )
            result["snapshot_id"] = snap_id
        except Exception as e:
            log.warning("portfolio snapshot insert failed: %s", e)

    return result


@app.get("/api/portfolio/history")
def portfolio_history(key_id: Optional[int] = None,
                      limit: int = 100,
                      mine_only: bool = True,
                      ctx: dict = Depends(require_session)):
    """Return recent portfolio snapshots (lightweight: no holdings/positions JSON)."""
    user_filter = ctx["user"]["id"] if mine_only else None
    rows = PortfolioSnapshotRepo.recent(
        user_id=user_filter, key_id=key_id, limit=limit,
    )
    return {"snapshots": rows, "count": len(rows)}


@app.get("/api/portfolio/history/{snapshot_id}")
def portfolio_history_detail(snapshot_id: int,
                             ctx: dict = Depends(require_session)):
    """Return full snapshot incl. holdings + positions arrays."""
    snap = PortfolioSnapshotRepo.get(snapshot_id)
    if not snap:
        raise HTTPException(404, "snapshot not found")
    # Owner-only (admins can see all)
    if (snap["user_id"] != ctx["user"]["id"]
            and ctx["user"]["role"] != "admin"):
        raise HTTPException(403, "not your snapshot")
    return snap


# =========================================================================
# Exchange history — REAL orders / positions / fills from the exchange
# =========================================================================
def _exchange_symbols_for(chosen: dict) -> list[str]:
    """Unified ccxt symbols for the chosen exchange, from the watchlist.
    Falls back to the per-exchange column; e.g. gateio_symbol or okx_symbol."""
    name = (chosen["exchange"] or "okx").lower()
    rows = WatchlistRepo.list_all(enabled_only=False)
    out = []
    for r in rows:
        if name in ("gateio", "gate"):
            sym = r.get("gateio_symbol")
        elif name == "okx":
            sym = r.get("okx_symbol")
        else:
            sym = r.get("okx_symbol") or r.get("gateio_symbol")
        if sym:
            out.append(sym)
    return out


@app.get("/api/exchange/live")
def exchange_live(key_id: Optional[int] = None, both = Depends(require_vault)):
    """Open positions + open orders straight from the exchange (real-time).

    This is the source of truth for the Trades tab's "Live" view — it does
    NOT depend on the bot's DB, so it shows trades made manually or before
    the bot recorded anything."""
    ctx, vs = both
    keys = ApiKeyRepo.list_for_user(ctx["user"]["id"])
    if not keys:
        raise HTTPException(404, "no API keys configured")
    chosen = _pick_key(keys, key_id)
    creds = ApiKeyRepo.get_decrypted(chosen["id"], vs)
    ex = _build_ccxt(chosen, creds)
    try:
        ex.load_markets()
    except Exception:
        pass
    from ..exchange_history import fetch_live_state
    symbols = _exchange_symbols_for(chosen)
    state = fetch_live_state(ex, symbols=symbols)
    state["key_used"] = {
        "id": chosen["id"], "label": chosen["label"],
        "exchange": chosen["exchange"], "is_testnet": bool(chosen["is_testnet"]),
    }
    return state


@app.get("/api/exchange/history")
def exchange_history(days: int = 30, key_id: Optional[int] = None,
                     both = Depends(require_vault)):
    """Executed fills + realized-PnL analytics from the exchange over the
    last `days`. Feeds the 'real trade history' evaluation in the UI."""
    if days < 1 or days > 365:
        raise HTTPException(400, "days must be 1..365")
    ctx, vs = both
    keys = ApiKeyRepo.list_for_user(ctx["user"]["id"])
    if not keys:
        raise HTTPException(404, "no API keys configured")
    chosen = _pick_key(keys, key_id)
    creds = ApiKeyRepo.get_decrypted(chosen["id"], vs)
    ex = _build_ccxt(chosen, creds)
    try:
        ex.load_markets()
    except Exception:
        pass
    from ..exchange_history import fetch_fill_history
    symbols = _exchange_symbols_for(chosen)
    if not symbols:
        raise HTTPException(400, "no symbols in watchlist for this exchange")
    result = fetch_fill_history(ex, symbols, days=days)
    result["key_used"] = {
        "id": chosen["id"], "label": chosen["label"],
        "exchange": chosen["exchange"], "is_testnet": bool(chosen["is_testnet"]),
    }
    return result


@app.post("/api/learner/import-history")
def learner_import_history(days: int = 90, key_id: Optional[int] = None,
                           both = Depends(require_vault)):
    """Backfill the learner's Beta-Bernoulli (win/loss) layer from REAL
    exchange fills, so the Learner tab shows aggregate stats from trades
    actually executed — even those the bot didn't place.

    Honest caveat: exchange fills carry realized PnL but NOT the original
    SL distance, so a true R-multiple can't be rebuilt. We seed win/loss
    per (symbol, side) using realized-PnL sign and store summed PnL in
    sum_r (so avg_r = avg realized USDT/fill). These buckets use
    init_bucket='import' / rev_bucket='real' to stay clearly separate from
    the bot's own learned buckets, and do NOT touch the L3 ML model.
    """
    if days < 1 or days > 365:
        raise HTTPException(400, "days must be 1..365")
    ctx, vs = both
    keys = ApiKeyRepo.list_for_user(ctx["user"]["id"])
    if not keys:
        raise HTTPException(404, "no API keys configured")
    chosen = _pick_key(keys, key_id)
    creds = ApiKeyRepo.get_decrypted(chosen["id"], vs)
    ex = _build_ccxt(chosen, creds)
    try:
        ex.load_markets()
    except Exception:
        pass

    from ..exchange_history import fetch_fill_history
    symbols = _exchange_symbols_for(chosen)
    if not symbols:
        raise HTTPException(400, "no symbols in watchlist for this exchange")
    hist = fetch_fill_history(ex, symbols, days=days)

    # Aggregate win/loss + summed PnL per (symbol, side) from PnL-bearing fills
    agg: dict[tuple, dict] = {}
    for f in hist["fills"]:
        if f["realized_pnl"] == 0:
            continue   # entry fills / fills with no realized component
        k = (f["symbol"], f["side"])
        a = agg.setdefault(k, {"wins": 0, "losses": 0, "sum_pnl": 0.0})
        if f["realized_pnl"] > 0:
            a["wins"] += 1
        else:
            a["losses"] += 1
        a["sum_pnl"] += f["realized_pnl"]

    imported = 0
    for (symbol, side), a in agg.items():
        n = a["wins"] + a["losses"]
        if n == 0:
            continue
        bucket_key = f"{symbol}|{side}|import|real"
        LearnerRepo.upsert_bucket(
            bucket_key=bucket_key, symbol=symbol, side=side,
            init_bucket="import", rev_bucket="real",
            alpha=float(a["wins"] + 1), beta=float(a["losses"] + 1),
            trades=n, sum_r=round(a["sum_pnl"], 4),
        )
        imported += 1

    AuditRepo.log(ctx["user"]["id"], "learner_import_history",
                  {"exchange": chosen["exchange"], "days": days,
                   "buckets_imported": imported,
                   "fills_seen": hist["totals"]["n_fills"]})
    return {
        "ok": True,
        "buckets_imported": imported,
        "fills_seen": hist["totals"]["n_fills"],
        "realized_pnl": hist["totals"]["realized_pnl"],
        "win_rate": hist["totals"]["win_rate"],
        "days": days,
        "warnings": hist["warnings"],
        "note": "Imported buckets use init=import/rev=real. They reflect "
                "realized-PnL win/loss per symbol+side; avg_r column = avg "
                "USDT/fill (not a true R-multiple).",
    }


# =========================================================================
# Trade Calculator (pre-trade sizing math)
# =========================================================================
def _compute_order(payload: CalculateOrderIn) -> dict:
    """Pure function — sizing & R-multiple math. Easy to unit test."""
    side = payload.side.upper()
    if side not in ("LONG", "SHORT"):
        raise ValueError("side must be LONG or SHORT")
    if payload.entry <= 0:
        raise ValueError("entry must be positive")
    if payload.equity_usdt <= 0:
        raise ValueError("equity_usdt must be positive")
    if payload.risk_per_trade_pct <= 0 or payload.risk_per_trade_pct > 100:
        raise ValueError("risk_per_trade_pct must be 0 < x <= 100")
    if payload.sl is None and payload.sl_pct is None:
        raise ValueError("either sl (price) or sl_pct (distance %) is required")

    direction = 1 if side == "LONG" else -1
    if payload.sl is None:
        # SL distance from entry as %; SL is the WORSE direction
        sl = payload.entry - direction * payload.entry * payload.sl_pct / 100.0
    else:
        sl = float(payload.sl)
        # sanity check side
        if side == "LONG" and sl >= payload.entry:
            raise ValueError("LONG: SL must be below entry")
        if side == "SHORT" and sl <= payload.entry:
            raise ValueError("SHORT: SL must be above entry")

    sl_distance_abs = abs(payload.entry - sl)
    if sl_distance_abs <= 0:
        raise ValueError("SL must differ from entry")
    sl_distance_pct = sl_distance_abs / payload.entry * 100.0

    risk_usdt = payload.equity_usdt * payload.risk_per_trade_pct / 100.0
    contracts = risk_usdt / sl_distance_abs
    notional = contracts * payload.entry

    # Leverage: minimum that supports notional within equity, capped
    if notional <= payload.equity_usdt:
        leverage = 1
    else:
        import math as _math
        leverage = min(payload.max_leverage,
                      max(1, int(_math.ceil(notional / payload.equity_usdt))))
    margin_required = notional / leverage if leverage > 0 else 0
    margin_pct_of_equity = (margin_required / payload.equity_usdt * 100.0
                           if payload.equity_usdt else 0)

    # TPs
    tps = []
    for r in payload.tp_r_multiples:
        tp_price = payload.entry + direction * sl_distance_abs * r
        tp_pnl_usdt = r * risk_usdt
        tp_pct = (tp_price - payload.entry) / payload.entry * 100.0 * direction
        tps.append({
            "r": float(r),
            "price": round(tp_price, 8),
            "pnl_usdt": round(tp_pnl_usdt, 2),
            "pct_from_entry": round(tp_pct, 3),
        })

    # Rough liquidation estimate (ignores fees / maintenance margin)
    liq_distance_pct = 100.0 / leverage
    if side == "LONG":
        liq_price = payload.entry * (1 - liq_distance_pct / 100.0)
    else:
        liq_price = payload.entry * (1 + liq_distance_pct / 100.0)

    # Warnings
    warnings = []
    if sl_distance_pct < 0.30:
        warnings.append(f"SL distance only {sl_distance_pct:.2f}% — risk of noise stop-out")
    if sl_distance_pct > 5.0:
        warnings.append(f"SL distance {sl_distance_pct:.2f}% is wide — check setup")
    if margin_pct_of_equity > 50:
        warnings.append(f"Margin {margin_pct_of_equity:.1f}% of equity is heavy")
    if leverage > 10:
        warnings.append(f"Leverage {leverage}x — high liquidation risk")
    if payload.risk_per_trade_pct > 2.0:
        warnings.append(f"Risk per trade {payload.risk_per_trade_pct}% > 2% (aggressive)")

    return {
        "symbol": payload.symbol,
        "side": side,
        "entry": round(payload.entry, 8),
        "sl": round(sl, 8),
        "sl_distance_pct": round(sl_distance_pct, 3),
        "sl_distance_abs": round(sl_distance_abs, 8),
        "risk_usdt": round(risk_usdt, 2),
        "risk_per_trade_pct": payload.risk_per_trade_pct,
        "equity_usdt": payload.equity_usdt,
        "contracts": round(contracts, 8),
        "notional_usdt": round(notional, 2),
        "leverage": leverage,
        "margin_required": round(margin_required, 2),
        "margin_pct_of_equity": round(margin_pct_of_equity, 2),
        "liq_price_estimate": round(liq_price, 8),
        "liq_distance_pct": round(liq_distance_pct, 2),
        "tps": tps,
        "warnings": warnings,
    }


@app.post("/api/calculate-order")
def calculate_order(payload: CalculateOrderIn,
                   ctx: dict = Depends(require_session)):
    """Pre-trade sizing calculator. No order is placed."""
    try:
        return _compute_order(payload)
    except ValueError as e:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(e))


# =========================================================================
# Ticker (current price from Binance public API — no auth)
# =========================================================================
@app.get("/api/ticker")
def ticker(symbol: str, ctx: dict = Depends(require_session)):
    """Fetch last/bid/ask from Binance public API."""
    import ccxt
    ex = ccxt.binance({"enableRateLimit": True})
    try:
        t = ex.fetch_ticker(symbol)
    except Exception as e:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, f"ticker fetch failed: {e}")
    return {
        "symbol": symbol,
        "last": float(t["last"]) if t.get("last") else None,
        "bid": float(t["bid"]) if t.get("bid") else None,
        "ask": float(t["ask"]) if t.get("ask") else None,
        "high": float(t["high"]) if t.get("high") else None,
        "low": float(t["low"]) if t.get("low") else None,
        "fetched_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    }


# =========================================================================
# DB statistics (admin view of all tables)
# =========================================================================
@app.get("/api/stats/db")
def db_stats(ctx: dict = Depends(require_admin)):
    """Row counts + size per table."""
    from ..db.connection import get_db
    db = get_db()
    tables = [
        "users", "api_keys", "parameters", "pattern_detections",
        "trades", "learner_buckets", "tuning_runs", "equity_snapshots",
        "audit_log", "sessions", "watchlist", "portfolio_snapshots",
        "licenses", "payment_proofs", "activation_attempts",
    ]
    out = []
    for t in tables:
        try:
            n = db.execute(f"SELECT COUNT(*) AS n FROM {t}").fetchone()["n"]
        except Exception:
            n = 0
        out.append({"table": t, "rows": n})
    # DB file size
    try:
        from ..db.connection import DB_PATH
        size_kb = round(DB_PATH.stat().st_size / 1024, 1) if DB_PATH.exists() else 0
    except Exception:
        size_kb = 0
    return {"tables": out, "db_file_kb": size_kb}


# =========================================================================
# Licensing
# =========================================================================
class VerifyPaymentIn(BaseModel):
    tx_hash: str
    tier: str        # trial | monthly | quarterly | annual | lifetime
    network: str = "bsc"   # bsc | tron


class ActivateCodeIn(BaseModel):
    code: str


def _client_ip(request) -> str | None:
    """Best-effort IP extraction for rate-limiting."""
    if not request:
        return None
    fwd = request.headers.get("x-forwarded-for")
    if fwd:
        return fwd.split(",")[0].strip()
    return request.client.host if request.client else None


@app.get("/api/license/tiers")
def license_tiers():
    """Public pricing — fetched from the license server (or fallback to local)."""
    server_resp = LicenseManager.pricing()
    # Augment server tiers with UI-only fields the bot has
    out_tiers = []
    for t_data in server_resp.get("tiers", []):
        local = TIERS.get(t_data["name"])
        if local:
            t_data["label"] = local.base_label
            t_data["per_month_equiv"] = local.per_month_equiv
            t_data["display_price"] = local.display_price
        out_tiers.append(t_data)
    server_resp["tiers"] = out_tiers
    return server_resp


@app.get("/api/license/status")
def license_status():
    """Current machine's license state. No auth — we expose it so the SPA
    can decide whether to gate features at app start, even before login."""
    return LicenseManager.status().to_dict()


@app.get("/api/license/fingerprint")
def license_fingerprint():
    """Hardware fingerprint blob — shown in UI so users can email support
    with the exact ID if they need a transfer. Public because (a) it
    contains no PII beyond what the user can already get from `getmac`
    and (b) the no-license stage needs to display it before login exists."""
    return machine_fingerprint_blob()


@app.get("/api/license/trial-eligible")
def license_trial_eligible():
    """Proxy to the license server: tells the UI whether the Trial button
    should be enabled for this machine. Trial = first-license-only.
    Public — needed before login exists."""
    from ..licensing.client import _get, LicenseServerError
    mid = machine_id()
    try:
        return _get(f"/trial-eligible/{mid}")
    except LicenseServerError:
        # Server unreachable — be permissive (user can try; server enforces)
        return {"machine_id": mid, "trial_eligible": True,
                "reason": "license server unreachable; will be re-checked at verify time"}


@app.post("/api/license/verify-payment")
def license_verify_payment(payload: VerifyPaymentIn, request: __import__('fastapi').Request):
    """Step 1: submit BSC tx_hash + tier. Delegated to the license server."""
    if payload.tier not in TIERS:
        raise HTTPException(400, f"unknown tier: {payload.tier}")
    ip = _client_ip(request)
    try:
        return LicenseManager.verify_payment_and_issue_code(
            tx_hash=payload.tx_hash.strip(),
            requested_tier=payload.tier,
            network=payload.network,
            ip=ip,
        )
    except LicenseRateLimitError as e:
        raise HTTPException(status.HTTP_429_TOO_MANY_REQUESTS, str(e))
    except LicenseServerError as e:
        if not e.reachable:
            raise HTTPException(503,
                "license server unreachable — check your internet connection")
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(e))
    except PaymentVerifyError as e:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(e))


@app.post("/api/license/activate")
def license_activate(payload: ActivateCodeIn,
                    request: __import__('fastapi').Request,
                    session: Optional[str] = __import__('fastapi').Cookie(default=None)):
    """Step 2: provide the token from /verify-payment. We verify signature
    locally + register with the server. Login NOT required (first-time
    buyers can activate before signup)."""
    ip = _client_ip(request)
    user_id = None
    if session:
        uid = SessionRepo.get_user_id(session)
        user_id = uid
    try:
        status_out = LicenseManager.activate_code(
            code=payload.code.strip(), user_id=user_id, ip=ip,
        )
        return status_out.to_dict()
    except LicenseRateLimitError as e:
        raise HTTPException(status.HTTP_429_TOO_MANY_REQUESTS, str(e))
    except LicenseServerError as e:
        if not e.reachable:
            raise HTTPException(503, "license server unreachable")
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(e))
    except LicenseCodeError as e:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, str(e))


@app.post("/api/license/heartbeat")
def license_heartbeat():
    """Manual heartbeat trigger — UI button. Bot also calls this periodically."""
    return LicenseManager.heartbeat().to_dict()


@app.post("/api/license/peek")
def license_peek(payload: ActivateCodeIn):
    """Decode-only — show buyer what the code says without committing it."""
    return LicenseManager.peek(payload.code.strip())


@app.get("/api/license/admin/list")
def license_admin_list(ctx: dict = Depends(require_admin), limit: int = 100):
    """Admin view of all issued licenses."""
    from ..db.repositories import LicenseRepo
    return LicenseRepo.list_all(limit=limit)


@app.post("/api/license/admin/revoke/{license_id}")
def license_admin_revoke(license_id: int,
                         reason: str = "manual",
                         ctx: dict = Depends(require_admin)):
    LicenseManager.revoke(license_id, reason=reason)
    return {"ok": True, "license_id": license_id, "revoked_reason": reason}


# =========================================================================
# Serve index.html and static files LAST so /api/* is matched first
# =========================================================================
INDEX_PATH = PROJECT_ROOT / "index.html"


@app.get("/")
def root():
    if not INDEX_PATH.exists():
        return JSONResponse({"error": "index.html not found at project root"}, status_code=500)
    return FileResponse(INDEX_PATH)


@app.get("/favicon.ico")
def favicon():
    return Response(status_code=204)


# Catch-all SPA route (so refreshing /trades, /keys etc. still loads index.html)
@app.get("/{full_path:path}")
def spa_fallback(full_path: str):
    if full_path.startswith("api/"):
        raise HTTPException(404, "not found")
    if INDEX_PATH.exists():
        return FileResponse(INDEX_PATH)
    raise HTTPException(500, "index.html missing")
