"""Pull REAL order / position / fill history from the exchange.

Why this module exists
----------------------
The bot's SQLite `trades` table only contains trades the bot itself placed
through its scan->entry->fill->feedback loop. Trades made manually, or before
the bot's recording was wired up, live ONLY on the exchange. This module
reaches into the exchange via ccxt to surface that reality in the dashboard:

  * open positions      (fetch_positions)
  * open orders         (fetch_open_orders)
  * closed fills        (fetch_my_trades per symbol)
  * realized-PnL stats  (aggregated from fills)

Everything is defensive: each exchange call is wrapped so a single failing
symbol or unsupported method never blanks the whole view. Partial data +
a `warnings` list is always returned.

Limitations (told honestly to the operator)
  * Exchanges don't store the original SL distance, so we CANNOT reconstruct
    a true R-multiple from raw fills. We report realized PnL in USDT and %,
    and win/loss — which is enough for aggregate evaluation, but the ML
    learner's context vector cannot be rebuilt from history.
"""
from __future__ import annotations
import time
from datetime import datetime, timedelta, timezone
from typing import Optional

from .utils import setup_logger

log = setup_logger("exchange_history")


# ---------------------------------------------------------------------------
# Open positions + open orders (the "live now" view)
# ---------------------------------------------------------------------------
def fetch_live_state(ex, symbols: Optional[list[str]] = None) -> dict:
    """Return current open positions + open orders from the exchange.

    `ex` is a ready ccxt client (sandbox flag already set by caller).
    `symbols` optional list of unified symbols to scope open-order queries
    (some exchanges require a symbol for fetch_open_orders).
    """
    warnings: list[str] = []
    positions_out: list[dict] = []
    orders_out: list[dict] = []

    # --- open positions ---
    try:
        positions = ex.fetch_positions()
        for p in positions:
            contracts = p.get("contracts") or 0
            if not contracts:
                continue
            positions_out.append({
                "symbol": p.get("symbol"),
                "side": (p.get("side") or "").upper(),
                "contracts": float(contracts),
                "entry_price": float(p.get("entryPrice") or 0),
                "mark_price": float(p.get("markPrice") or 0),
                "liquidation_price": float(p.get("liquidationPrice") or 0)
                    if p.get("liquidationPrice") else None,
                "unrealized_pnl": float(p.get("unrealizedPnl") or 0),
                "leverage": p.get("leverage"),
                "notional": float(p.get("notional") or 0),
                "margin": float(p.get("initialMargin") or 0) or None,
                "percentage": float(p.get("percentage") or 0)
                    if p.get("percentage") is not None else None,
            })
    except Exception as e:
        warnings.append(f"fetch_positions failed: {e}")

    # --- open orders (pending limit/stop orders) ---
    try:
        # Try the all-symbols form first
        open_orders = ex.fetch_open_orders()
        orders_out.extend(_norm_orders(open_orders))
    except Exception:
        # Fall back to per-symbol (some exchanges require a symbol)
        if symbols:
            for sym in symbols:
                try:
                    oo = ex.fetch_open_orders(sym)
                    orders_out.extend(_norm_orders(oo))
                except Exception as e:
                    warnings.append(f"fetch_open_orders({sym}) failed: {e}")
        else:
            warnings.append("fetch_open_orders requires symbols; none provided")

    return {
        "positions": positions_out,
        "open_orders": orders_out,
        "warnings": warnings,
        "fetched_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    }


def _norm_orders(orders: list) -> list[dict]:
    out = []
    for o in orders:
        out.append({
            "id": o.get("id"),
            "symbol": o.get("symbol"),
            "side": (o.get("side") or "").upper(),
            "type": o.get("type"),
            "price": float(o.get("price") or 0) if o.get("price") else None,
            "amount": float(o.get("amount") or 0) if o.get("amount") else None,
            "filled": float(o.get("filled") or 0),
            "remaining": float(o.get("remaining") or 0),
            "status": o.get("status"),
            "reduce_only": bool((o.get("reduceOnly")
                                 or (o.get("info", {}) or {}).get("reduceOnly"))),
            "created_at": (datetime.fromtimestamp(o["timestamp"] / 1000,
                                                  tz=timezone.utc).isoformat(timespec="seconds")
                           if o.get("timestamp") else None),
        })
    return out


# ---------------------------------------------------------------------------
# Closed-fill history + realized PnL analytics
# ---------------------------------------------------------------------------
def fetch_fill_history(ex, symbols: list[str], days: int = 30,
                       max_per_symbol: int = 500) -> dict:
    """Pull executed fills per symbol over the last `days`, aggregate into
    per-symbol realized-PnL stats.

    Returns:
      {
        "fills":   [ {symbol, side, price, amount, cost, fee, realized_pnl, ts}, ... ],
        "by_symbol": [ {symbol, n_fills, buy_qty, sell_qty, realized_pnl, fees, ...} ],
        "totals":  {n_fills, realized_pnl, fees, win_fills, loss_fills, ...},
        "warnings": [...],
      }
    """
    warnings: list[str] = []
    fills: list[dict] = []
    since_ms = int((datetime.now(timezone.utc) - timedelta(days=days)).timestamp() * 1000)

    for sym in symbols:
        try:
            trades = ex.fetch_my_trades(sym, since=since_ms, limit=max_per_symbol)
        except Exception as e:
            warnings.append(f"fetch_my_trades({sym}) failed: {e}")
            continue
        for t in trades:
            info = t.get("info", {}) or {}
            # realized PnL field name differs per exchange; try common keys
            rpnl = (_safe_float(info.get("pnl"))
                    or _safe_float(info.get("realizedPnl"))
                    or _safe_float(info.get("realized_pnl"))
                    or _safe_float(info.get("profit"))
                    or 0.0)
            fee = 0.0
            if t.get("fee") and t["fee"].get("cost") is not None:
                fee = _safe_float(t["fee"]["cost"])
            fills.append({
                "symbol": t.get("symbol"),
                "side": (t.get("side") or "").upper(),
                "price": _safe_float(t.get("price")),
                "amount": _safe_float(t.get("amount")),
                "cost": _safe_float(t.get("cost")),
                "fee": fee,
                "realized_pnl": rpnl,
                "order_id": t.get("order"),
                "ts": (datetime.fromtimestamp(t["timestamp"] / 1000,
                                              tz=timezone.utc).isoformat(timespec="seconds")
                       if t.get("timestamp") else None),
            })

    # Aggregate per symbol
    by_symbol: dict[str, dict] = {}
    for f in fills:
        s = by_symbol.setdefault(f["symbol"], {
            "symbol": f["symbol"], "n_fills": 0, "buy_qty": 0.0, "sell_qty": 0.0,
            "realized_pnl": 0.0, "fees": 0.0,
        })
        s["n_fills"] += 1
        if f["side"] == "BUY":
            s["buy_qty"] += f["amount"]
        else:
            s["sell_qty"] += f["amount"]
        s["realized_pnl"] += f["realized_pnl"]
        s["fees"] += f["fee"]

    by_symbol_list = sorted(by_symbol.values(),
                            key=lambda x: x["realized_pnl"], reverse=True)

    total_pnl = sum(f["realized_pnl"] for f in fills)
    total_fees = sum(f["fee"] for f in fills)
    # win/loss measured on fills that carried a realized-pnl value
    pnl_fills = [f for f in fills if f["realized_pnl"] != 0]
    wins = sum(1 for f in pnl_fills if f["realized_pnl"] > 0)
    losses = sum(1 for f in pnl_fills if f["realized_pnl"] < 0)

    # Sort fills newest-first for display
    fills.sort(key=lambda f: f["ts"] or "", reverse=True)

    return {
        "fills": fills,
        "by_symbol": by_symbol_list,
        "totals": {
            "n_fills": len(fills),
            "realized_pnl": round(total_pnl, 4),
            "fees": round(total_fees, 4),
            "net_pnl": round(total_pnl - total_fees, 4),
            "win_fills": wins,
            "loss_fills": losses,
            "win_rate": round(wins / (wins + losses), 3) if (wins + losses) else None,
        },
        "days": days,
        "warnings": warnings,
        "fetched_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    }


def _safe_float(v) -> float:
    try:
        return float(v)
    except (TypeError, ValueError):
        return 0.0
