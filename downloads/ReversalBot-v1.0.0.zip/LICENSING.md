# Licensing & Activation

Reversal Bot uses a self-contained licensing system. You pay in **USDT on BSC (BEP20)**, the bot verifies your transaction on-chain, and a machine-bound activation code is minted.

## Tiers

| Tier | Price (USDT) | Duration | Discount | Notes |
|---|---|---|---|---|
| **Trial** | 29 | 30 days | — | One-shot per machine |
| **Monthly** | 39 | 30 days | — | Pay as you go |
| **Quarterly** | 111 | 90 days | 5% off | vs. monthly |
| **Annual** | 397 | 365 days | 15% off | vs. monthly |
| **Lifetime** | 569 | Unlimited | — | All future updates included |

Pricing math: monthly base = 39 USDT. Quarterly = 39 × 3 × 0.95 ≈ 111. Annual = 39 × 12 × 0.85 ≈ 397.

## How to activate

### 1. Send payment

Send **the exact USDT amount** for your tier on **BSC (BEP20)** to:

```
0xFdE5bE00bA5db63a93abf7922ee831dB62257550
```

USDT-BEP20 contract: `0x55d398326f99059fF775485246999027B3197955`

⚠️ Do NOT send from ERC20, TRC20, or any other network. BEP20 only.

### 2. Wait for ≥12 confirmations

About 30 seconds on BSC. You can watch the tx at https://bscscan.com.

### 3. Run the bot's web dashboard

```bash
python scripts/run_web.py
# Open http://localhost:8788
```

On the login screen, click **🔑 Activate**. Paste your BSC transaction hash and pick the tier you paid for.

### 4. The bot mints your activation code

After on-chain verification (~3-8 seconds), the dashboard shows your code. Save it somewhere safe — you'll need it if you ever reinstall.

### 5. Activate the code

Click "Continue to activate" or paste the code in step 2. It binds to this machine (sha256 of MAC + platform info).

## What can go wrong, and how to fix it

| Error | Cause | Fix |
|---|---|---|
| `transaction not found on BSC` | Wrong tx hash, or sent on a non-BSC network | Double-check on bscscan.com |
| `only N confirmations (need 12)` | Tx is still propagating | Wait ~30 seconds and retry |
| `amount X USDT does not match any tier` | Sent the wrong amount, or gas fee subtracted from received | Email support — we'll match it manually |
| `no USDT-BEP20 transfer to <wallet>` | Sent BNB instead of USDT, or to wrong address | Verify the receipt on bscscan.com |
| `this transaction has already been used` | The same tx was previously consumed | Email support if you believe this is wrong |
| `license is bound to a different machine` | You're activating on a machine other than the one that minted the code | Email support for a transfer |
| `too many failed attempts` | Rate-limit: 5 failures/hour/IP | Wait an hour |
| `this machine has already used its trial` | Trial is one-shot per machine | Buy a paid tier |

## Transferring a license

If you need to move your license to a new machine (hardware upgrade, OS reinstall, etc.):

1. Email **dht.io.vn@gmail.com** with:
   - Your activation code (or first/last 4 chars if you've lost it)
   - The original machine ID (visible in the License tab)
   - The new machine ID (visible on the login screen of the new install)
2. We'll revoke the old binding and issue a new code for the new machine.

## How the activation code works (technical)

A code is 40 bytes encoded as base32 → 64 chars grouped as `AAAA-BBBB-...`:

```
[1 byte version]
[1 byte tier_id]
[4 bytes issued_at UNIX seconds]
[4 bytes expires_at UNIX seconds, 0xFFFFFFFF = lifetime]
[8 bytes random nonce]
[12 bytes machine_id prefix]
[10 bytes HMAC-SHA256(body, master_secret)]
```

When you activate:
1. We decode base32 → verify length is 40 bytes
2. Verify the HMAC matches our master secret
3. Verify the bound machine prefix matches the current machine's id
4. Verify expiry is in the future
5. Verify the code isn't already in the database (replay protection)
6. Insert a `licenses` row binding this machine until `expires_at`

## Refunds & disputes

We don't offer automatic refunds, but if there's a clear problem (bot doesn't run, exchange you needed is unsupported, etc.) within **7 days** of purchase, email **dht.io.vn@gmail.com** and we'll work something out.

## Privacy

The bot does NOT send your activation code, tx_hash, or machine ID to any third party. Everything stays on your machine. The only network call is to BSC public RPC nodes for on-chain verification.
