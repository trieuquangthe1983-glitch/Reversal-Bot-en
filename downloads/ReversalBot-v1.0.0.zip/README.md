# Reversal Bot

Automated detector and trader for **intraday reversal** patterns in GMT+7 daily candles across 10 tokens: BTC, ETH, SOL, SUI, XRP, ZEC, LINK, ONDO, ASTER, DOGE.

> **Target pattern**: Within a daily candle (00:00–24:00 GMT+7), price moves ≥ **1.05%** from open in one direction, then reverses **1.2%–6.5%** from the intraday extreme.

Two strategies run in parallel: the base **Daily Reversal** plus a **Liquidity-Trap Reversal (LTR)** model. A `StrategyRouter` merges them into "confluence" signals when both fire same-side. An adaptive Bayesian + online-logistic learner (`learner_v2`) gates trades by confidence per (symbol, side, bucket). A meta-learner reallocates risk per strategy by rolling expected-R.

See [ADVANTAGES.md](ADVANTAGES.md) for the feature comparison and [LICENSING.md](LICENSING.md) for purchase + activation.

---

## 1. Install

```bash
python -m venv .venv
.venv\Scripts\activate          # Windows
# source .venv/bin/activate      # Linux/macOS
pip install -r requirements.txt
```

Python 3.10+ required.

## 2. Bootstrap the database + first user

```bash
python scripts/manage.py init                       # create DB + seed 10 tokens
python scripts/manage.py user create -u trader      # interactive password setup
```

## 3. Buy a license

Open the dashboard:

```bash
python scripts/run_web.py
# -> http://localhost:8788
```

On the login screen, click **💎 Pricing** → choose a tier → send USDT-BEP20 → paste the tx hash → activate. Full walkthrough in [LICENSING.md](LICENSING.md).

Tiers at a glance:

| Tier | Price | Duration |
|---|---|---|
| Trial | 29 USDT | 30 days, one-shot per machine |
| Monthly | 39 USDT | 30 days |
| Quarterly | 111 USDT | 90 days (5% off) |
| Annual | 397 USDT | 365 days (15% off) |
| Lifetime | 569 USDT | No expiry |

Payment wallet (BSC, BEP20 USDT only): `0xFdE5bE00bA5db63a93abf7922ee831dB62257550`

## 4. Add your exchange API key

Once logged in:

1. Open the **🔓 Unlock vault** flow.
2. Click **API Keys → + Add key**. Choose `okx` (testnet) or `gateio` (live).
   * For Gate.io: enable **Unified Account** on Gate.io's web UI first (Wallet → Unified Account → Enable). The bot uses isolated 15× by default.
3. For live trading on mainnet, click **🚨 Enable LIVE** and type `I_UNDERSTAND_REAL_MONEY` to confirm.

## 5. Run the bot

```bash
# dry-run / paper trading
set DRY_RUN=true
python scripts/run_live.py

# live (requires active license)
set DRY_RUN=false
set BOT_USER=trader
set VAULT_PASSWORD=<your vault password>
python scripts/run_live.py
```

The bot scans the universe every 60 seconds (configurable in `config.yaml`), opens at most `max_concurrent_positions` (default 5), and respects per-symbol cooldown (default 4 hours).

## 6. Backtest

```bash
python scripts/fetch_history.py       # downloads 2 years of Binance 1h data
python scripts/run_backtest.py        # writes reports/*.csv
```

## 7. Monitor

The dashboard shows:

- **Dashboard** — equity curve, win-rate, R PnL, open positions
- **Portfolio** — live exchange balance + snapshot history
- **Watchlist** — toggle per-token scanning
- **Calculator** — pre-trade sizing math
- **Trades** — open + closed with full size/notional/margin/leverage
- **Patterns** — every detection (acted-on + skipped, with reasons)
- **Parameters** — runtime override of `config.yaml`
- **Learner** — Bayesian posterior per bucket
- **Audit** — security log (login, vault, API key use, parameter change, license events)
- **DB Browser** — row counts per table
- **License** — current status + admin license list

## 8. Configuration

Edit `config.yaml`. Common knobs:

```yaml
pattern:
  initial_move_pct: 1.05
  reversal_min_pct: 1.20
  reversal_max_pct: 6.50

risk:
  risk_per_trade_pct: 0.5
  max_leverage: 10
  max_concurrent_positions: 5
  per_symbol_cooldown_hours: 4

gateio:
  leverage: 15
  margin_mode: "isolated"
  unified_account: true
```

Runtime overrides via the Parameters tab persist to DB and survive restarts.

## 9. Security model

- **Login**: bcrypt cost-12, lockout after 5 failed attempts (15 min)
- **Vault**: separate password, Fernet + PBKDF2-310k key derivation, atomic rotation
- **Sessions**: HttpOnly cookie, sliding 8h TTL, 30-day max-age
- **API keys**: encrypted at rest, decrypted only in memory when vault is unlocked
- **LIVE confirm**: two-step enable for mainnet keys
- **License**: HMAC-signed activation codes bound to machine fingerprint
- **Audit**: every sensitive event logged to `audit_log`

Full details in [SECURITY.md](SECURITY.md).

## 10. Tests

```bash
pytest tests/ -v
```

100+ tests gate every release. See [ADVANTAGES.md § Tests as code-of-truth](ADVANTAGES.md#11-tests-as-code-of-truth).

---

## Support

Email **dht.io.vn@gmail.com** for:

- License transfers between machines
- Refund requests (within 7 days)
- Tx-hash verification failures
- Bug reports & feature requests

## License

Proprietary. Each purchase grants a single-machine license; see [LICENSING.md](LICENSING.md).
