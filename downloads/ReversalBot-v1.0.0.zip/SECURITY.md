# SECURITY — Đọc trước khi nạp API key thật

## 1. Mô hình tin cậy (threat model)

DB của bot lưu **2 thứ nhạy cảm**:

| Loại | Thuật toán | Khóa được lưu trên disk? |
|---|---|---|
| Mật khẩu đăng nhập | **bcrypt** (cost=12) | Có (hash, không khôi phục được) |
| API key sàn giao dịch | **Fernet** (AES-128-CBC + HMAC-SHA256) | Có (ciphertext) |
| Khóa giải mã Fernet | **PBKDF2-HMAC-SHA256** (310k vòng, salt 16-byte) | **KHÔNG.** Dẫn xuất từ vault password mỗi phiên |

**Hệ quả quan trọng:**
- Nếu kẻ tấn công đánh cắp `state/bot.db` mà không có vault password → **không giải mã được API key** (PBKDF2 với 310k vòng cản brute-force).
- Nếu vault password yếu (vd. `12345`) → có thể bị brute-force offline → mất API key.
- Nếu cả vault password và DB cùng bị compromise → API key bị lộ. Đây là lý do **mainnet key luôn cần `key enable-live`** (2-step) và quy tắc IP whitelist trên sàn.

## 2. Quy tắc cứng khi setup

1. **Vault password ≥ 16 ký tự**, đủ 3/4 loại (chữ hoa, chữ thường, số, ký tự đặc biệt).
2. **Vault password KHÁC login password**. Đặt khác để nếu CLI login bị log shoulder-surf, API key vẫn an toàn.
3. **Không lưu vault password ra file phẳng**. Cách an toàn nhất: nhập tay mỗi lần qua `getpass`. Cách thực dụng: env var `VAULT_PASSWORD` chỉ cho phiên CLI hiện hành — đừng cho vào `.env` được commit.
4. **API key sàn phải bật IP whitelist** và **chỉ cấp quyền `trade`**, KHÔNG cấp `withdraw`. Đây là phòng thủ chiều sâu — kể cả key lộ, hacker không rút được tiền.
5. **Bật `key enable-live` rồi mới đặt `DRY_RUN=false`**. Bot mặc định từ chối chạy thật với key chưa được enable-live.
6. **Sao lưu** `state/bot.db` + ghi nhớ vault password ở chỗ an toàn (1Password, KeePass). **KHÔNG có cơ chế khôi phục** nếu mất vault password — toàn bộ API key trong DB thành không khôi phục được.

## 3. Cấu trúc bảng `audit_log`

Mọi sự kiện nhạy cảm đều ghi log:

| event_type | Khi nào |
|---|---|
| `user_create` / `user_delete` | Tạo / xoá user |
| `login` / `login_fail` | Đăng nhập (success/fail) |
| `vault_unlock` / `vault_unlock_fail` | Mở/đóng vault |
| `key_add` / `key_delete` | Thêm/xoá API key |
| `key_access` | Bot/CLI đọc & giải mã key |
| `key_enable_live` | Bật quyền mainnet |
| `param_change` | Thay đổi tham số |
| `bot_start` / `bot_stop` | Bot online/offline |

```powershell
python scripts/manage.py audit --tail 100
python scripts/manage.py audit --event key_access     # ai đã đọc key
```

## 4. Lockout & rate limiting

- Sau **5 lần** login sai → tài khoản bị khoá **15 phút** (`auth.MAX_FAILED_LOGINS`, `LOCKOUT_MINUTES`).
- Vault sai password → **không có lockout** (chống rate-limit attack có hại hơn). Brute-force bị giới hạn tự nhiên bởi 310k vòng PBKDF2 (~0.3-1s/attempt trên CPU thường).

## 5. Quy trình thay đổi mật khẩu / xoay key (rotation)

### Đổi vault password
Hiện tại CLI chưa có lệnh đổi vault password. Workaround:
```powershell
# 1. List keys, ghi nhớ id
python scripts/manage.py key list -u trader
# 2. Decrypt + xem (KHÔNG show plaintext). Cách an toàn: tạo user mới
python scripts/manage.py user create -u trader-v2
# 3. Add lại từng key với vault password mới
python scripts/manage.py key add -u trader-v2 --exchange okx --testnet
# 4. Xoá user cũ
python scripts/manage.py user delete -u trader
```
> Cải tiến tương lai: lệnh `vault rotate` để re-encrypt mọi key bằng key mới — sẵn sàng được thêm vào v2.

### Xoay API key
Mỗi 60-90 ngày khuyến nghị thay key trên sàn → `manage.py key delete` cái cũ → `key add` cái mới.

## 6. File permissions

- Trên **Linux/Mac**: `init_db()` tự `chmod 600` cho `state/bot.db`.
- Trên **Windows**: phải thiết lập ACL thủ công:
  ```powershell
  $acl = Get-Acl "state\bot.db"
  $acl.SetAccessRuleProtection($true, $false)
  $rule = New-Object System.Security.AccessControl.FileSystemAccessRule(
    [System.Security.Principal.WindowsIdentity]::GetCurrent().Name,
    "FullControl", "Allow")
  $acl.AddAccessRule($rule)
  Set-Acl "state\bot.db" $acl
  ```

## 7. Backup & recovery

```powershell
# Backup (mã hóa bằng 7-zip)
7z a -tzip -mhe=on -p"BackupPass" bot_db_backup.zip state/bot.db
# Restore
7z x bot_db_backup.zip
```

**Không backup `state/bot.db` lên cloud chưa mã hoá** — đó là bypass toàn bộ phòng thủ ở trên.

## 8. Cảnh báo cuối cùng

- Code này **chưa được audit chuyên nghiệp**. Đối với số tiền lớn, hãy thuê security review hoặc dùng hardware wallet (Trezor + custom signer).
- Đừng chạy bot trên **máy cá nhân dùng chung** hoặc **máy có nhiều browser extension lạ** — đó là vectơ tấn công lớn nhất, không phải code.
- Nếu nghi ngờ máy bị compromise: **revoke API key trên sàn ngay**, rồi xử lý máy sau. Sàn revoke là phòng thủ cuối cùng có thực sự.
