# Playbook giao dịch đòn bẩy — Reversal Pattern Intraday

> Dưới góc nhìn của một trader đòn bẩy 10+ năm. Đây là **cấu trúc setup** mà bot
> sẽ thực thi tự động và là khung tư duy để bạn review/can thiệp thủ công khi cần.

---

## 1. Định nghĩa setup

Một ngày GMT+7 đủ điều kiện vào lệnh khi và chỉ khi:

| Điều kiện | Giá trị | Lý do |
|---|---|---|
| **Initial move** | `|price - day_open| / day_open >= 1.05%` | Đủ lớn để loại nhiễu, đủ phổ biến để có thanh khoản |
| **Reversal magnitude** | `1.20% <= |extreme - retrace| / extreme <= 6.50%` | <1.2% là noise; >6.5% là *trend change*, không phải reversal trong ngày |
| **Time ordering** | Reversal xảy ra **sau** extreme, trong cùng ngày GMT+7 | Tránh bắt nhầm wick rồi tiếp diễn |

Hai loại setup:

- **SHORT setup** = rally rồi giảm (exhaustion ở đỉnh)
- **LONG setup** = giảm rồi tăng (capitulation rồi rebound)

## 2. Entry / SL / TP

```
SHORT setup:
  entry      = day_high * (1 - 1.20%)                  ← trigger price
  SL         = day_high * (1 + 0.30%)                  ← buffer 30 bps trên đỉnh
  risk_pct   = (SL - entry) / entry ≈ 1.5%             ← khoảng risk
  TP1 (1R)   = entry - 1.5%
  TP2 (2R)   = entry - 3.0%
  TP3 (3R)   = entry - 4.5%

LONG setup: đối xứng
```

### Exit policy mặc định — `split_tp`

| Mốc | % vị thế đóng | Lý do |
|---|---|---|
| TP1 (1R) | 50% | Bắt phần edge có win-rate cao nhất, lock profit, biến SL còn lại thành 0R |
| TP2 (2R) | 30% | Lấy phần lớn lợi nhuận từ runner |
| TP3 (3R) | 20% | Để chạy nốt nếu là big move; lệnh ăn 1.5R + đôi khi 2R+ |

Tail (nếu chưa đụng TP và hết ngày): đóng tại close cuối ngày GMT+7.

## 3. Sizing — không thương lượng

```
risk_per_trade = 0.5% equity
position_size  = risk_per_trade / SL_distance
leverage       = min(max_leverage, notional / 10% equity)
```

Với `risk_pct ≈ 1.5%` và `risk_per_trade = 0.5%`:
- notional = (equity × 0.5%) / 1.5% ≈ **33% equity**
- ở leverage 10x → margin chiếm ~3.3% equity / lệnh
- 3 lệnh đồng thời tối đa → < 10% equity bị khoá → còn dư cho biến động cực đoan

> **Quy tắc bất di bất dịch**: Đòn bẩy là công cụ làm sạch sizing, không phải nhân lợi nhuận. Nếu bạn cần leverage cao hơn 10x để cảm thấy "có ăn" → vấn đề ở edge, không phải ở leverage.

## 4. Khi nào KHÔNG vào lệnh (filter)

Bot tự bỏ qua khi gặp 1 trong các điều kiện:

1. **Confidence < 0.40** từ learner — bucket này đang lỗ liên tiếp
2. **Đang trong cooldown 12h** sau lệnh trước cùng symbol — tránh over-trade khi chart cho nhiều tín hiệu liên tiếp
3. **Đã có 3 lệnh mở** — giới hạn correlation risk
4. **Margin không đủ 95% equity** — tránh liquidation cascade
5. **Symbol không có trên OKX swap** — bot log warning + skip

Bạn có thể thêm filter thủ công:

- Bỏ vào lệnh nếu **funding rate cực đoan cùng chiều** (vd. SHORT setup nhưng funding rate đang +0.10%/8h → thị trường đã short quá nhiều, dễ short squeeze)
- Bỏ vào lệnh trong **window FOMC / CPI ±1h**
- Bỏ vào lệnh nếu **BTC dominance đang flip** mạnh trong 4h (cross-asset risk)

## 5. Edge thực sự đến từ đâu

Không phải từ "pattern đẹp". Edge của setup này là:

1. **Mean reversion ngắn hạn ở extremes**: sau cú push >1%, một phần lớn người đã FOMO/panic vào, lực còn lại yếu. Reversal 1.2%-6.5% là zone "thoát hàng" có thật.
2. **Liquidity vacuum**: SL của FOMO traders nằm ngay trên/dưới extreme. Phá qua → swept liquidity → quay đầu là price-action chuẩn.
3. **Sai số định nghĩa pattern**: ngưỡng 1.05% / 1.20% phải là *gần* đỉnh phân phối kurtosis của return ngày, nhưng *đã loại phần đuôi*. Learner sẽ tự dịch ngưỡng nếu phân phối thay đổi.

## 6. Tư duy nâng cao — phối hợp playbook với context

| Bối cảnh | Hành động đề xuất |
|---|---|
| BTC giảm mạnh + 4+ altcoin có SHORT setup trong cùng ngày | Vào BTC SHORT trước (deeper liquidity), giảm size altcoin |
| Funding rate cùng chiều bạn muốn vào (ví dụ funding rất âm + bạn muốn LONG) | Tăng size lên 0.7% risk (vì có thêm tailwind từ short squeeze tiềm năng) |
| Reversal_pct đã đạt > 4% lúc bạn được trigger | Cảnh giác: setup đang ở "cuối cú đảo chiều". Chuyển TP1 sang **0.5R** và giảm size 50%. |
| ASTER (lịch sử ngắn) cho tín hiệu | Trade size **0.25× bình thường** cho đến khi có >= 30 lệnh dữ liệu |

## 7. Báo cáo cần xem hàng tuần

```powershell
python scripts/retrain.py
```

Đặc biệt chú ý:
- Bucket nào có win-rate < 40% và > 20 trades → **xoá khỏi universe**
- Bucket nào win-rate > 60% và avg_R > 0.5 → **tăng risk_per_trade riêng** cho bucket đó (cần code mới)
- Token nào có expectancy âm liên tục trong 30 lệnh → tạm loại
