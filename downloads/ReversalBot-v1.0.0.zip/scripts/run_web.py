"""Launch the web dashboard.

Usage:
    python scripts/run_web.py
    python scripts/run_web.py --host 0.0.0.0 --port 8788    # expose on LAN
    python scripts/run_web.py --port 9100                   # custom port

The default port (8788) can be overridden with --port or the WEB_PORT env var
so customers running multiple bots on one machine don't get a conflict.
"""
from __future__ import annotations
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import uvicorn

from src.db import init_db
from src.db.connection import DB_PATH
from src.keepalive import allow_sleep, prevent_sleep, report_status
from src.utils import setup_logger

log = setup_logger("run_web")


def main():
    ap = argparse.ArgumentParser()
    import os
    ap.add_argument("--host", default="127.0.0.1", help="Listen address (default: localhost only)")
    ap.add_argument("--port", type=int,
                    default=int(os.getenv("WEB_PORT", "8788")),
                    help="HTTP port (default: 8788 or $WEB_PORT)")
    ap.add_argument("--reload", action="store_true")
    ap.add_argument("--no-keepalive", action="store_true",
                    help="Don't prevent Windows from sleeping (default: prevent)")
    args = ap.parse_args()

    if not DB_PATH.exists():
        log.info("initializing DB at %s", DB_PATH)
        init_db()

    if not args.no_keepalive:
        prevent_sleep()
        log.info(report_status())

    log.info("====================================================")
    log.info("Reversal Bot Dashboard")
    log.info("URL:  http://%s:%d/", args.host if args.host != "0.0.0.0" else "localhost", args.port)
    log.info("DB:   %s", DB_PATH)
    log.info("Press Ctrl+C to stop")
    log.info("====================================================")
    if args.host == "0.0.0.0":
        log.warning("WARNING: binding to 0.0.0.0 -- accessible from network!")
        log.warning("ONLY do this on a private LAN. NEVER expose this to the public internet.")

    try:
        uvicorn.run(
            "src.web.app:app",
            host=args.host,
            port=args.port,
            reload=args.reload,
            log_level="info",
        )
    finally:
        if not args.no_keepalive:
            allow_sleep()
            log.info("keepalive released")


if __name__ == "__main__":
    main()
