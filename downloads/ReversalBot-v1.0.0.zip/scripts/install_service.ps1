# =============================================================================
# Install bot + web dashboard as Windows Services via NSSM
# =============================================================================
# Why: Windows Services keep running after logout, auto-restart on crash,
# and don't need a terminal window. Combined with src/keepalive.py
# (called automatically by run_live.py and run_web.py), the bot stays
# active 24/7 as long as the machine is on.
#
# Prerequisites:
#   1. Run this script as Administrator (right-click PowerShell -> Run as admin)
#   2. NSSM auto-installed via Chocolatey if missing
#
# Usage:
#   .\scripts\install_service.ps1 -Action install
#   .\scripts\install_service.ps1 -Action start
#   .\scripts\install_service.ps1 -Action stop
#   .\scripts\install_service.ps1 -Action remove
#   .\scripts\install_service.ps1 -Action status
#
# Service names:
#   ReversalBot      (the trading loop)
#   ReversalBotWeb   (the web dashboard on http://localhost:8788)
# =============================================================================

param(
    [Parameter(Mandatory=$true)]
    [ValidateSet("install","start","stop","remove","status","logs")]
    [string]$Action,

    [switch]$WebOnly,
    [switch]$BotOnly
)

$ErrorActionPreference = "Stop"
$ProjectRoot = Split-Path -Parent $PSScriptRoot
$PythonExe = (Get-Command python).Source
$BotSvc = "ReversalBot"
$WebSvc = "ReversalBotWeb"

function Test-Admin {
    $current = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($current)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Ensure-NSSM {
    if (Get-Command nssm -ErrorAction SilentlyContinue) {
        Write-Host "[OK] nssm already installed" -ForegroundColor Green
        return
    }
    Write-Host "[INFO] nssm not found. Installing via Chocolatey..." -ForegroundColor Yellow
    if (-not (Get-Command choco -ErrorAction SilentlyContinue)) {
        Write-Host "[INFO] Chocolatey not found. Installing Chocolatey first..." -ForegroundColor Yellow
        Set-ExecutionPolicy Bypass -Scope Process -Force
        [System.Net.ServicePointManager]::SecurityProtocol = `
            [System.Net.ServicePointManager]::SecurityProtocol -bor 3072
        iex ((New-Object System.Net.WebClient).DownloadString('https://community.chocolatey.org/install.ps1'))
        $env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + `
                    [System.Environment]::GetEnvironmentVariable("Path","User")
    }
    choco install nssm -y --no-progress | Out-Null
    if (-not (Get-Command nssm -ErrorAction SilentlyContinue)) {
        throw "nssm installation failed. Install manually from https://nssm.cc/download"
    }
    Write-Host "[OK] nssm installed" -ForegroundColor Green
}

function Install-Service {
    param([string]$Name, [string]$Script, [string]$Description)
    if (Get-Service -Name $Name -ErrorAction SilentlyContinue) {
        Write-Host "[INFO] Service '$Name' already exists. Removing first..." -ForegroundColor Yellow
        nssm stop $Name confirm | Out-Null
        nssm remove $Name confirm | Out-Null
    }
    Write-Host "[INFO] Installing service '$Name'..."
    nssm install $Name $PythonExe $Script
    nssm set $Name AppDirectory $ProjectRoot
    nssm set $Name Description $Description
    nssm set $Name Start SERVICE_AUTO_START
    nssm set $Name AppStdout "$ProjectRoot\logs\$Name.stdout.log"
    nssm set $Name AppStderr "$ProjectRoot\logs\$Name.stderr.log"
    nssm set $Name AppRotateFiles 1
    nssm set $Name AppRotateBytes 10485760    # 10 MB
    nssm set $Name AppThrottle 3000           # don't restart faster than 3s
    nssm set $Name AppRestartDelay 5000       # 5s delay between auto-restarts
    nssm set $Name AppExit Default Restart
    # Pass DRY_RUN env so the service is safe-by-default
    nssm set $Name AppEnvironmentExtra "DRY_RUN=true" "PYTHONUNBUFFERED=1"
    Write-Host "[OK] Service '$Name' installed" -ForegroundColor Green
}

function Get-ServiceState {
    param([string]$Name)
    $svc = Get-Service -Name $Name -ErrorAction SilentlyContinue
    if ($null -eq $svc) { return "NOT_INSTALLED" }
    return $svc.Status
}

# ============================================================================
# Action dispatch
# ============================================================================
switch ($Action) {
    "install" {
        if (-not (Test-Admin)) { throw "Run this script as Administrator." }
        Ensure-NSSM
        New-Item -ItemType Directory -Path "$ProjectRoot\logs" -Force | Out-Null

        if (-not $WebOnly) {
            Install-Service -Name $BotSvc `
                -Script "$ProjectRoot\scripts\run_live.py" `
                -Description "Crypto Reversal Bot (trading loop)"
        }
        if (-not $BotOnly) {
            Install-Service -Name $WebSvc `
                -Script "$ProjectRoot\scripts\run_web.py" `
                -Description "Crypto Reversal Bot - Web Dashboard"
        }

        Write-Host ""
        Write-Host "Services installed. To start them:" -ForegroundColor Cyan
        Write-Host "    .\scripts\install_service.ps1 -Action start"
        Write-Host ""
        Write-Host "NOTE: by default services run with DRY_RUN=true (no real orders)." -ForegroundColor Yellow
        Write-Host "      To enable live trading, edit env vars:" -ForegroundColor Yellow
        Write-Host "      nssm set $BotSvc AppEnvironmentExtra DRY_RUN=false BOT_USER=trader VAULT_PASSWORD=..." -ForegroundColor Yellow
    }

    "start" {
        if (-not (Test-Admin)) { throw "Run this script as Administrator." }
        if (-not $WebOnly) { nssm start $BotSvc; Start-Sleep 2 }
        if (-not $BotOnly) { nssm start $WebSvc; Start-Sleep 2 }
        & $PSCommandPath -Action status
    }

    "stop" {
        if (-not (Test-Admin)) { throw "Run this script as Administrator." }
        if (-not $WebOnly) { nssm stop $BotSvc confirm }
        if (-not $BotOnly) { nssm stop $WebSvc confirm }
    }

    "remove" {
        if (-not (Test-Admin)) { throw "Run this script as Administrator." }
        if (-not $WebOnly) {
            nssm stop $BotSvc confirm | Out-Null
            nssm remove $BotSvc confirm | Out-Null
            Write-Host "[OK] $BotSvc removed" -ForegroundColor Green
        }
        if (-not $BotOnly) {
            nssm stop $WebSvc confirm | Out-Null
            nssm remove $WebSvc confirm | Out-Null
            Write-Host "[OK] $WebSvc removed" -ForegroundColor Green
        }
    }

    "status" {
        Write-Host ""
        Write-Host "Service Status:" -ForegroundColor Cyan
        Write-Host "  $BotSvc : $(Get-ServiceState $BotSvc)"
        Write-Host "  $WebSvc : $(Get-ServiceState $WebSvc)"
        Write-Host ""
        Write-Host "Web URL: http://localhost:8788/"
        Write-Host "Logs:    $ProjectRoot\logs\"
    }

    "logs" {
        $log = "$ProjectRoot\logs\$BotSvc.stdout.log"
        if (Test-Path $log) {
            Get-Content $log -Tail 50 -Wait
        } else {
            Write-Host "Log file not found: $log" -ForegroundColor Yellow
        }
    }
}
