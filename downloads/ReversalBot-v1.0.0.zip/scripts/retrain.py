"""Offline: rebuild learner state from a closed_trades.json log AND from
backtest results. Useful for warm-starting the learner.

Usage:
    python scripts/retrain.py [--seed-from-backtest]
"""
from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pandas as pd
from rich.console import Console
from rich.table import Table

from src.learner import AdaptiveLearner, bucket_initial_move, bucket_reversal
from src.playbook import TradeSetup
from src.utils import PROJECT_ROOT, load_config, setup_logger

log = setup_logger("retrain")
console = Console()


def seed_from_backtest(learner: AdaptiveLearner) -> int:
    p = PROJECT_ROOT / "reports" / "backtest_trades.csv"
    if not p.exists():
        log.warning("no backtest_trades.csv -- run run_backtest.py first")
        return 0
    df = pd.read_csv(p)
    n = 0
    for _, row in df.iterrows():
        setup = TradeSetup(
            symbol=row["symbol"], side=row["side"],
            entry=row["entry"], sl=row["sl"],
            tp1=0, tp2=0, tp3=0,
            risk_pct=0, rr_at_tp1=1, rr_at_tp2=2, rr_at_tp3=3,
            pattern_date=row["date_gmt7"],
            initial_move_pct=row["initial_move_pct"],
            reversal_pct=row["reversal_pct"],
            confidence=0.5,
        )
        learner.record_outcome(setup, row["r_pnl"])
        n += 1
    return n


def summarize(learner: AdaptiveLearner):
    rows = []
    for k, bs in learner.state.buckets.items():
        rows.append({
            "key": k,
            "trades": bs.trades,
            "win_prob_mean": round(bs.win_prob_mean, 3),
            "avg_r": round(bs.avg_r, 3),
            "alpha": round(bs.alpha, 2),
            "beta": round(bs.beta, 2),
        })
    if not rows:
        console.print("[yellow]no buckets yet[/yellow]")
        return
    df = pd.DataFrame(rows).sort_values("trades", ascending=False)
    tbl = Table(title="Learner Buckets")
    for c in df.columns:
        tbl.add_column(c, justify="right")
    for _, r in df.head(30).iterrows():
        tbl.add_row(*[str(v) for v in r.values])
    console.print(tbl)
    out = PROJECT_ROOT / "reports" / "learner_buckets.csv"
    df.to_csv(out, index=False)
    console.print(f"saved {out}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed-from-backtest", action="store_true")
    args = ap.parse_args()
    cfg = load_config()
    learner = AdaptiveLearner(
        prior_alpha=cfg["learner"]["prior_alpha"],
        prior_beta=cfg["learner"]["prior_beta"],
        decay_factor=cfg["learner"]["decay_factor"],
    )
    if args.seed_from_backtest:
        n = seed_from_backtest(learner)
        log.info("seeded learner with %d backtest trades", n)
    summarize(learner)


if __name__ == "__main__":
    main()
