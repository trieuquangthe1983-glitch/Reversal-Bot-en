"""Run the live bot loop (dry-run by default).

Set DRY_RUN=false in .env to send orders to OKX testnet.

Usage:
    python scripts/run_live.py
"""
from __future__ import annotations
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.bot import ReversalBot


def main():
    bot = ReversalBot()
    bot.run_forever()


if __name__ == "__main__":
    main()
