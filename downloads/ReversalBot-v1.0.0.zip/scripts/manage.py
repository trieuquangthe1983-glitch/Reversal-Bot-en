"""CLI for user/key/parameter management.

Usage examples:
    python scripts/manage.py init
    python scripts/manage.py user create -u trader
    python scripts/manage.py user list
    python scripts/manage.py key add -u trader --exchange okx --testnet
    python scripts/manage.py key list -u trader
    python scripts/manage.py key enable-live --id 3 -u trader
    python scripts/manage.py key delete --id 3 -u trader
    python scripts/manage.py params show
    python scripts/manage.py params set pattern initial_move_pct 1.20
    python scripts/manage.py params history pattern initial_move_pct
    python scripts/manage.py audit --tail 50
    python scripts/manage.py stats
"""
from __future__ import annotations
import argparse
import getpass
import json
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from rich.console import Console
from rich.table import Table

from src.db import (
    ApiKeyRepo, AuditRepo, EquityRepo, LearnerRepo, ParameterRepo,
    PatternRepo, TradeRepo, TuningRepo, UserRepo, init_db,
)
from src.db.connection import DB_PATH

console = Console()


# -------------------------------------------------------------------------
# helpers
# -------------------------------------------------------------------------
def _prompt_password(label: str, confirm: bool = False) -> str:
    pw = getpass.getpass(f"{label}: ")
    if confirm:
        pw2 = getpass.getpass(f"{label} (confirm): ")
        if pw != pw2:
            console.print("[red]passwords do not match[/red]")
            sys.exit(1)
    return pw


def _require_user(username: str) -> dict:
    u = UserRepo.get_by_username(username)
    if not u:
        console.print(f"[red]no such user: {username}[/red]")
        sys.exit(1)
    return u


def _unlock_vault(username: str):
    pw = os.getenv("VAULT_PASSWORD") or _prompt_password(f"Vault password for {username}")
    try:
        return UserRepo.unlock_vault(username, pw)
    except ValueError as e:
        console.print(f"[red]vault unlock failed: {e}[/red]")
        sys.exit(1)


def _print_rows(rows: list[dict], title: str = "") -> None:
    if not rows:
        console.print(f"[yellow]no rows[/yellow]")
        return
    tbl = Table(title=title, show_lines=False)
    for c in rows[0].keys():
        tbl.add_column(str(c), overflow="fold")
    for r in rows:
        tbl.add_row(*[str(r.get(c, "")) for c in rows[0].keys()])
    console.print(tbl)


# -------------------------------------------------------------------------
# commands
# -------------------------------------------------------------------------
def cmd_init(args):
    init_db()
    console.print(f"[green]DB initialized at {DB_PATH}[/green]")
    console.print("Next: create your first user with [bold]manage.py user create -u <name>[/bold]")


def cmd_user_create(args):
    pw = _prompt_password("Login password", confirm=True)
    try:
        u = UserRepo.create(args.username, pw, role=args.role)
    except ValueError as e:
        console.print(f"[red]{e}[/red]")
        sys.exit(1)
    console.print(f"[green]user '{u['username']}' created (id={u['id']})[/green]")
    console.print("[yellow]NOTE:[/yellow] login password is also your vault password by default.")
    console.print("[yellow]If you forget the vault password, encrypted API keys are unrecoverable.[/yellow]")


def cmd_user_list(args):
    _print_rows(UserRepo.list_all(), title="Users")


def cmd_user_login(args):
    pw = _prompt_password(f"Login password for {args.username}")
    try:
        u = UserRepo.authenticate(args.username, pw)
        console.print(f"[green]authenticated as {u['username']} (role={u['role']})[/green]")
    except ValueError as e:
        console.print(f"[red]{e}[/red]")
        sys.exit(1)


def cmd_user_delete(args):
    u = _require_user(args.username)
    confirm = input(f"DELETE user {u['username']} and all their keys? type 'DELETE': ")
    if confirm != "DELETE":
        console.print("aborted")
        return
    UserRepo.delete(u["id"])
    console.print(f"[green]user {u['username']} deleted[/green]")


def cmd_key_add(args):
    u = _require_user(args.username)
    sess = _unlock_vault(args.username)
    api_key = input("API key:        ").strip()
    secret = getpass.getpass("API secret:     ")
    passphrase = ""
    if args.exchange.lower() in {"okx", "kucoin"}:
        passphrase = getpass.getpass("API passphrase: ")
    label = args.label or input("Label (e.g. okx-live-main): ").strip() or "default"
    try:
        k = ApiKeyRepo.add(
            user_id=u["id"], label=label, exchange=args.exchange.lower(),
            api_key=api_key, secret=secret, passphrase=passphrase,
            is_testnet=args.testnet, is_live_enabled=False, vault_sess=sess,
        )
    except Exception as e:
        console.print(f"[red]failed to add key: {e}[/red]")
        sys.exit(1)
    console.print(f"[green]key '{k['label']}' added (id={k['id']}, masked={k['api_key_masked']})[/green]")
    if not args.testnet:
        console.print("[yellow]mainnet key stored but NOT live-enabled. "
                      "Use [bold]key enable-live --id N -u {u}[/bold] to allow real orders.[/yellow]")


def cmd_key_list(args):
    u = _require_user(args.username)
    rows = ApiKeyRepo.list_for_user(u["id"])
    _print_rows(rows, title=f"API keys for {u['username']}")


def cmd_key_enable_live(args):
    u = _require_user(args.username)
    console.print("[bold red]You are about to enable LIVE (real money) trading for this key.[/bold red]")
    console.print(f"key id: {args.id}")
    confirm = input("Type EXACTLY  I_UNDERSTAND_REAL_MONEY  to proceed: ")
    try:
        ApiKeyRepo.enable_live(args.id, u["id"], confirm)
        console.print(f"[green]key {args.id} is now live-enabled[/green]")
    except ValueError as e:
        console.print(f"[red]{e}[/red]")
        sys.exit(1)


def cmd_key_delete(args):
    u = _require_user(args.username)
    ApiKeyRepo.delete(args.id, u["id"])
    console.print(f"[green]key {args.id} deleted[/green]")


def cmd_key_test(args):
    """Verify a key works by fetching balance from the exchange."""
    u = _require_user(args.username)
    sess = _unlock_vault(args.username)
    k = ApiKeyRepo.get(args.id)
    if not k or k["user_id"] != u["id"]:
        console.print("[red]no such key for this user[/red]")
        sys.exit(1)
    creds = ApiKeyRepo.get_decrypted(args.id, sess)
    import ccxt
    ex_class = getattr(ccxt, k["exchange"])
    ex = ex_class({
        "apiKey": creds["api_key"], "secret": creds["secret"],
        "password": creds["passphrase"], "enableRateLimit": True,
        "options": {"defaultType": "swap"},
    })
    if k["is_testnet"]:
        ex.set_sandbox_mode(True)
    try:
        bal = ex.fetch_balance()
        usdt = bal.get("USDT", {})
        console.print(f"[green]OK - free USDT: {usdt.get('free', 0)}[/green]")
    except Exception as e:
        console.print(f"[red]auth failed: {e}[/red]")
        sys.exit(1)


# ---- parameters ----------------------------------------------------------
def cmd_params_show(args):
    all_p = ParameterRepo.all_active()
    if not all_p:
        console.print("[yellow]no DB overrides; bot will use config.yaml[/yellow]")
        return
    for ns, kv in all_p.items():
        tbl = Table(title=f"namespace: {ns}")
        tbl.add_column("key"); tbl.add_column("value")
        for k, v in kv.items():
            tbl.add_row(k, json.dumps(v))
        console.print(tbl)


def cmd_params_set(args):
    try:
        value = json.loads(args.value)
    except json.JSONDecodeError:
        value = args.value         # treat as plain string
    ParameterRepo.set(args.namespace, args.key, value,
                      description=args.description or "")
    console.print(f"[green]set {args.namespace}.{args.key} = {value!r}[/green]")


def cmd_params_history(args):
    hist = ParameterRepo.history(args.namespace, args.key, limit=args.limit)
    if not hist:
        console.print("[yellow]no history[/yellow]"); return
    tbl = Table(title=f"{args.namespace}.{args.key} history")
    for c in ("set_at", "value", "active", "set_by_user_id"):
        tbl.add_column(c)
    for h in hist:
        tbl.add_row(h["set_at"], json.dumps(h["value"]), str(h["active"]),
                    str(h["set_by_user_id"] or ""))
    console.print(tbl)


# ---- audit ---------------------------------------------------------------
def cmd_audit(args):
    rows = AuditRepo.recent(limit=args.tail, event_type=args.event)
    _print_rows(rows, title="Audit log")


# ---- stats ---------------------------------------------------------------
def cmd_stats(args):
    console.print(f"[bold]DB:[/bold] {DB_PATH}")
    pats = PatternRepo.recent(limit=1)
    trades = TradeRepo.summary_by_symbol()
    buckets = LearnerRepo.list_buckets()
    eq = EquityRepo.recent(limit=1)
    console.print(f"patterns logged: ...")
    _print_rows(trades, title="Trades by symbol")
    _print_rows(buckets[:20], title="Learner buckets (top 20)")
    if eq:
        console.print(f"latest equity: {eq[0]['equity_usdt']} USDT @ {eq[0]['ts']}")


# -------------------------------------------------------------------------
# argparse
# -------------------------------------------------------------------------
def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="manage.py")
    sub = p.add_subparsers(dest="cmd", required=True)

    sub.add_parser("init").set_defaults(func=cmd_init)

    user = sub.add_parser("user").add_subparsers(dest="action", required=True)
    a = user.add_parser("create"); a.add_argument("-u", "--username", required=True)
    a.add_argument("--role", default="user"); a.set_defaults(func=cmd_user_create)
    user.add_parser("list").set_defaults(func=cmd_user_list)
    a = user.add_parser("login"); a.add_argument("-u", "--username", required=True)
    a.set_defaults(func=cmd_user_login)
    a = user.add_parser("delete"); a.add_argument("-u", "--username", required=True)
    a.set_defaults(func=cmd_user_delete)

    key = sub.add_parser("key").add_subparsers(dest="action", required=True)
    a = key.add_parser("add"); a.add_argument("-u", "--username", required=True)
    a.add_argument("--exchange", default="okx", choices=["okx", "binance", "bybit", "kucoin"])
    a.add_argument("--label"); a.add_argument("--testnet", action="store_true")
    a.set_defaults(func=cmd_key_add)
    a = key.add_parser("list"); a.add_argument("-u", "--username", required=True)
    a.set_defaults(func=cmd_key_list)
    a = key.add_parser("enable-live"); a.add_argument("-u", "--username", required=True)
    a.add_argument("--id", type=int, required=True); a.set_defaults(func=cmd_key_enable_live)
    a = key.add_parser("delete"); a.add_argument("-u", "--username", required=True)
    a.add_argument("--id", type=int, required=True); a.set_defaults(func=cmd_key_delete)
    a = key.add_parser("test"); a.add_argument("-u", "--username", required=True)
    a.add_argument("--id", type=int, required=True); a.set_defaults(func=cmd_key_test)

    params = sub.add_parser("params").add_subparsers(dest="action", required=True)
    params.add_parser("show").set_defaults(func=cmd_params_show)
    a = params.add_parser("set"); a.add_argument("namespace"); a.add_argument("key")
    a.add_argument("value"); a.add_argument("--description", default="")
    a.set_defaults(func=cmd_params_set)
    a = params.add_parser("history"); a.add_argument("namespace"); a.add_argument("key")
    a.add_argument("--limit", type=int, default=20); a.set_defaults(func=cmd_params_history)

    a = sub.add_parser("audit"); a.add_argument("--tail", type=int, default=50)
    a.add_argument("--event"); a.set_defaults(func=cmd_audit)

    sub.add_parser("stats").set_defaults(func=cmd_stats)

    return p


def main():
    args = build_parser().parse_args()
    if not DB_PATH.exists() and args.cmd != "init":
        console.print(f"[yellow]DB not found, initializing at {DB_PATH}[/yellow]")
        init_db()
    args.func(args)


if __name__ == "__main__":
    main()
