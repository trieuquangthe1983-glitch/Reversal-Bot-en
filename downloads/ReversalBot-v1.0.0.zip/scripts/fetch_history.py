"""Download 1h OHLCV history for all configured symbols.

Usage:
    python scripts/fetch_history.py [--days 730] [--timeframe 1h] [--force]
"""
from __future__ import annotations
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.data_fetcher import DataFetcher
from src.utils import load_config, setup_logger

log = setup_logger("fetch_history")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--days", type=int, default=None)
    ap.add_argument("--timeframe", default=None)
    ap.add_argument("--force", action="store_true")
    args = ap.parse_args()

    cfg = load_config()
    days = args.days or cfg["backtest"]["history_days"]
    tf = args.timeframe or cfg["pattern"]["intraday_timeframe"]

    fetcher = DataFetcher("binance")
    for token, sym in cfg["universe"]["binance_symbols"].items():
        log.info("fetching %s (%s) tf=%s days=%d", token, sym, tf, days)
        try:
            df = fetcher.fetch_history(sym, timeframe=tf, days=days,
                                       force_refresh=args.force)
            log.info("  -> %d bars from %s to %s", len(df),
                     df.index.min() if len(df) else "?",
                     df.index.max() if len(df) else "?")
        except Exception as e:
            log.error("  FAILED: %s", e)


if __name__ == "__main__":
    main()
