"""End-to-end backtest pipeline:
   1. load cached 1h history
   2. detect reversal patterns for each symbol
   3. simulate trades
   4. emit CSV reports + summary table

Usage:
    python scripts/run_backtest.py
"""
from __future__ import annotations
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pandas as pd
from rich.console import Console
from rich.table import Table

from src.backtester import BTConfig, backtest, performance_summary
from src.data_fetcher import DataFetcher
from src.pattern_detector import detect_patterns, patterns_to_df
from src.statistics_analyzer import export_reports
from src.utils import PROJECT_ROOT, load_config, setup_logger

log = setup_logger("backtest")
console = Console()


def main():
    cfg = load_config()
    fetcher = DataFetcher("binance")

    all_patterns = []
    intraday_by_symbol: dict[str, pd.DataFrame] = {}
    days_observed: dict[str, int] = {}

    for token, sym in cfg["universe"]["binance_symbols"].items():
        log.info("loading %s (%s)", token, sym)
        df = fetcher.fetch_history(
            sym,
            timeframe=cfg["pattern"]["intraday_timeframe"],
            days=cfg["backtest"]["history_days"],
        )
        if df.empty:
            log.warning("no data for %s -- skipping", sym)
            continue
        intraday_by_symbol[sym] = df
        days_observed[sym] = (df.index.max() - df.index.min()).days
        pats = detect_patterns(
            df, symbol=sym,
            initial_move_pct=cfg["pattern"]["initial_move_pct"],
            reversal_min_pct=cfg["pattern"]["reversal_min_pct"],
            reversal_max_pct=cfg["pattern"]["reversal_max_pct"],
            tz_offset_hours=cfg["timezone"]["offset_hours"],
            min_bars_per_day=cfg["pattern"]["min_bars_per_day"],
        )
        log.info("  -> %d patterns", len(pats))
        all_patterns.extend(pats)

    if not all_patterns:
        log.error("NO patterns detected. Check thresholds in config.yaml")
        return

    patterns_df = patterns_to_df(all_patterns)

    # 1) statistical reports
    export_reports(patterns_df, days_observed, out_prefix="patterns")

    # 2) backtest trades
    bt_cfg = BTConfig(
        fee_pct=cfg["backtest"]["fee_pct"],
        slippage_pct=cfg["backtest"]["slippage_pct"],
        sl_buffer_pct=cfg["backtest"]["sl_buffer_pct"],
        tp_r_multiples=tuple(cfg["backtest"]["tp_r_multiples"]),
        exit_policy=cfg["backtest"]["exit_policy"],
        split_tp_weights=tuple(cfg["backtest"]["split_tp_weights"]),
    )
    trades = backtest(all_patterns, intraday_by_symbol, bt_cfg,
                     tz_offset_hours=cfg["timezone"]["offset_hours"])
    if trades.empty:
        log.warning("backtest produced 0 trades")
        return
    trades_path = PROJECT_ROOT / "reports" / "backtest_trades.csv"
    trades.to_csv(trades_path, index=False)
    log.info("backtest trades written: %s", trades_path)

    perf = performance_summary(trades)
    perf_path = PROJECT_ROOT / "reports" / "backtest_performance.csv"
    perf.to_csv(perf_path, index=False)

    # 3) console summary
    tbl = Table(title="Per-symbol Backtest Performance")
    for col in perf.columns:
        tbl.add_column(col, justify="right")
    for _, row in perf.iterrows():
        tbl.add_row(*[str(v) for v in row.values])
    console.print(tbl)

    total_R = trades["r_pnl"].sum()
    win_rate = (trades["r_pnl"] > 0).mean()
    console.print(f"\n[bold]Total trades:[/bold] {len(trades)}")
    console.print(f"[bold]Total R-PnL:[/bold] {total_R:.2f}R")
    console.print(f"[bold]Win rate:[/bold] {win_rate:.1%}")
    console.print(f"[bold]Expectancy per trade:[/bold] {trades['r_pnl'].mean():.3f}R")


if __name__ == "__main__":
    main()
