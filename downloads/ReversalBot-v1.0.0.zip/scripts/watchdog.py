"""Watchdog: keeps the bot + web alive.

For users who can't or don't want to install a Windows Service. Run this
in a terminal (or scheduled task) and it will:
  - prevent Windows from sleeping
  - spawn `run_live.py` and `run_web.py` as subprocesses
  - restart any subprocess that exits
  - exponential back-off if a process keeps crashing
  - log to logs/watchdog.log

Usage:
    python scripts/watchdog.py                   # both bot + web
    python scripts/watchdog.py --web-only
    python scripts/watchdog.py --bot-only
    python scripts/watchdog.py --max-restarts 100
"""
from __future__ import annotations
import argparse
import os
import signal
import subprocess
import sys
import time
from pathlib import Path
from typing import Optional

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.keepalive import allow_sleep, prevent_sleep, report_status
from src.utils import PROJECT_ROOT, ensure_dir, setup_logger

log = setup_logger("watchdog")


class ManagedProcess:
    """Spawn a Python script, restart it if it exits."""

    def __init__(self, name: str, script: str, max_restarts: int = 50):
        self.name = name
        self.script = script
        self.max_restarts = max_restarts
        self.restart_count = 0
        self.proc: Optional[subprocess.Popen] = None
        self.backoff_seconds = 1.0

    def start(self):
        if self.proc and self.proc.poll() is None:
            return  # already running
        env = os.environ.copy()
        env["PYTHONUNBUFFERED"] = "1"
        log_path = PROJECT_ROOT / "logs" / f"{self.name}.subprocess.log"
        ensure_dir(log_path.parent)
        # subprocess inherits keepalive flag through parent process state
        self.proc = subprocess.Popen(
            [sys.executable, "-u", self.script],
            cwd=str(PROJECT_ROOT),
            env=env,
            stdout=open(log_path, "ab"),
            stderr=subprocess.STDOUT,
            creationflags=subprocess.CREATE_NEW_PROCESS_GROUP if os.name == "nt" else 0,
        )
        log.info("[%s] started pid=%d log=%s", self.name, self.proc.pid, log_path.name)

    def is_alive(self) -> bool:
        return self.proc is not None and self.proc.poll() is None

    def check_and_restart(self):
        if self.is_alive():
            # reset backoff if process has been running > 60s
            return
        if self.proc is not None:
            rc = self.proc.returncode
            log.warning("[%s] exited rc=%s (restart #%d/%d)",
                       self.name, rc, self.restart_count + 1, self.max_restarts)
        if self.restart_count >= self.max_restarts:
            log.error("[%s] reached max_restarts; giving up", self.name)
            return
        time.sleep(self.backoff_seconds)
        self.restart_count += 1
        self.backoff_seconds = min(self.backoff_seconds * 1.5, 60.0)
        self.start()

    def stop(self):
        if self.proc and self.proc.poll() is None:
            log.info("[%s] terminating pid=%d", self.name, self.proc.pid)
            try:
                if os.name == "nt":
                    self.proc.send_signal(signal.CTRL_BREAK_EVENT)
                else:
                    self.proc.terminate()
                self.proc.wait(timeout=10)
            except (subprocess.TimeoutExpired, OSError):
                self.proc.kill()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--web-only", action="store_true")
    ap.add_argument("--bot-only", action="store_true")
    ap.add_argument("--max-restarts", type=int, default=50)
    ap.add_argument("--check-interval", type=int, default=10,
                   help="Seconds between health checks (default: 10)")
    args = ap.parse_args()

    prevent_sleep()
    log.info(report_status())
    log.info("watchdog starting...")

    procs: list[ManagedProcess] = []
    if not args.web_only:
        procs.append(ManagedProcess(
            "bot", str(PROJECT_ROOT / "scripts" / "run_live.py"),
            max_restarts=args.max_restarts,
        ))
    if not args.bot_only:
        procs.append(ManagedProcess(
            "web", str(PROJECT_ROOT / "scripts" / "run_web.py"),
            max_restarts=args.max_restarts,
        ))

    for p in procs:
        p.start()

    try:
        last_log = time.time()
        while True:
            for p in procs:
                p.check_and_restart()
            if time.time() - last_log > 300:    # heartbeat every 5 min
                alive = [p.name for p in procs if p.is_alive()]
                log.info("heartbeat: alive=%s", alive)
                last_log = time.time()
            time.sleep(args.check_interval)
    except KeyboardInterrupt:
        log.info("Ctrl+C received -- stopping all subprocesses")
    finally:
        for p in procs:
            p.stop()
        allow_sleep()
        log.info("watchdog stopped, keepalive released")


if __name__ == "__main__":
    main()
