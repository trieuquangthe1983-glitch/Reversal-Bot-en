# Chiến lược — Phân tích chiều sâu

## A. Cấu trúc dữ liệu của pattern

Mỗi pattern là một bản ghi với các cột (sau khi chạy `run_backtest.py`):

```
symbol, date_gmt7, side, day_open, day_close,
extreme, extreme_time_utc,
reversal_target, reversal_time_utc,
initial_move_pct, reversal_pct,
trigger_price, trigger_time_utc
```

Mỗi pattern → 1 trade trong `backtest_trades.csv` với:

```
entry, sl, outcome (sl/tp1/tp2/tp3/eod/partial_tp_eod),
r_pnl (đơn vị R-multiple), pct_pnl, exit_price
```

## B. Các thống kê quan trọng nhất (đọc trong reports/)

1. **patterns_base_rate.csv** — Token nào cho nhiều pattern/năm nhất?
    - Kỳ vọng: SOL/SUI/ONDO > BTC/ETH (vol cao hơn)
    - Nếu ASTER có < 30 pattern, đừng tin số liệu của nó.

2. **patterns_conditional.csv** — P(reversal >= R | initial >= I)
    - Đây là **bảng edge thô**. Tìm các ô có:
        - n_qualified >= 30 (đủ sample)
        - prob >= 0.6 (60% các pattern initial-X đạt reversal-Y)
    - Đó là "sweet spot" để xét lại ngưỡng trong config.

3. **backtest_performance.csv** — Cuối cùng vào tiền là R-multiples
    - Lọc: expectancy_R > 0.15 + profit_factor > 1.4 + trades >= 50
    - Symbol nào không pass → loại khỏi universe live.

## C. Logic "tại sao 1.05% và 1.2%"?

Đó là giá trị mặc định từ yêu cầu bạn đưa. Nhưng đừng cứng nhắc — sau khi backtest:

- Chạy `run_backtest.py` với grid trong `learner.threshold_search_grid` thay đổi `initial_move_pct` từ 0.8 đến 2.5
- So sánh expectancy R ở từng giá trị
- Pick giá trị **flat plateau** (không phải giá trị tối ưu cô lập — đó là overfitting)

Một plateau bền là dấu hiệu pattern có cơ sở thị trường thực sự, không phải artifact.

## D. Sai lầm dễ mắc

1. **Survivorship trong dataset**: ASTER không có data trước Q3/2025 → bỏ qua đợt sập tháng đó của thị trường → win-rate giả cao. Lọc theo `days_observed >= 365` trước khi so sánh.

2. **Lookahead bias trong backtester**: Tôi đã cẩn thận lấy `bars STRICTLY AFTER trigger_time_utc`. Đừng tự sửa lại thành `>=`.

3. **Same-bar SL & TP collision**: Khi trong 1 bar 1h, giá đụng cả SL và TP, backtester ưu tiên SL (pessimistic). Đó là quy ước an toàn — đừng đảo lại để "đẹp report".

4. **Confidence inflation**: Khi learner thấy 5 bucket toàn thắng → confidence tăng → size tăng → giàu nhanh trên backtest. Trên live, hãy giữ cap `risk_per_trade_pct = 0.5%` cứng, không scale lên.

5. **Mixing futures với spot data**: Binance spot vs Binance futures có funding/basis ảnh hưởng. Bot này dùng spot OHLCV làm tín hiệu và futures OKX để execute — basis nhỏ nhưng tồn tại. Nếu muốn tinh, dùng `okx` làm cả data fetcher (chỉ cần đổi 1 dòng trong `bot.py`).

## E. Lộ trình tinh chỉnh sau backtest đầu tiên

```
Ngày 1: fetch_history + run_backtest          → reports/
Ngày 1: đọc patterns_base_rate + performance  → loại token expectancy âm
Ngày 1: retrain.py --seed-from-backtest       → khởi tạo learner
Ngày 2-7: run_live (DRY_RUN=true)             → so sánh log vs backtest
Tuần 2: bật DRY_RUN=false trên testnet         → 20-30 lệnh thật
Tuần 3-4: retrain.py định kỳ                   → xem learner buckets
Tuần 4: review confidence/winrate per bucket   → loại bucket < 0.4
```

## F. Mô hình online learning chi tiết

Lý do chọn **Beta-Bernoulli + Thompson** thay vì XGBoost/LSTM:

| Tiêu chí | Beta-Thompson | XGBoost/NN |
|---|---|---|
| Số lệnh để có signal | ~20 trades/bucket | hàng nghìn |
| Giải thích được | Có (α, β trực quan) | Khó |
| Robust với regime change | Có (decay factor) | Cần retrain liên tục |
| Risk overfitting | Thấp | Cao |
| Resource | CPU, nhẹ | Cần GPU nếu deep |

Quy tắc cập nhật chính xác:

```
# Mỗi trade đóng:
d = decay_factor  (default 0.985)
alpha_new = (alpha_old - prior_alpha) * d + prior_alpha + (1 if win else 0)
beta_new  = (beta_old  - prior_beta)  * d + prior_beta  + (0 if win else 1)
```

Decay áp dụng vào **evidence vượt prior**, không lên prior. Nhờ vậy bucket cũ
yên tĩnh (không trade) sẽ về dần prior (uniform) thay vì lệch mãi.

Sau N trades = 50: nửa đời effective của một evidence cũ ≈ `ln(2) / |ln(0.985)| ≈ 46 trades`.
Nói cách khác, bot "quên" một lệnh cũ sau khoảng 46 lệnh mới.

## G. Mở rộng

- **Multi-timeframe filter**: chỉ trade SHORT khi EMA50 daily đang giảm → đã có data, thêm 5 dòng vào `bot.scan_once()`.
- **Funding-rate filter**: ccxt có `fetch_funding_rate(symbol)` cho OKX → tích hợp dễ.
- **Telegram alerts**: `.env.example` đã chừa `TELEGRAM_BOT_TOKEN`/`CHAT_ID`. Hook vào `bot._take_trade()` để gửi entry/exit notifications.
- **Walk-forward optimization**: thêm script `scripts/walk_forward.py` chia data thành rolling windows 6/3 tháng.
