@echo off
REM ============================================================
REM  Reversal Bot - Windows installer launcher
REM  Customer double-clicks this file to install everything.
REM ============================================================
title Reversal Bot - Installer

REM Auto-elevate to admin (needed for Python install + Start Menu shortcuts)
net session >nul 2>&1
if %errorLevel% NEQ 0 (
    echo Requesting administrator privileges...
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

cd /d "%~dp0\.."
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"

echo.
echo Press any key to close this window...
pause >nul
