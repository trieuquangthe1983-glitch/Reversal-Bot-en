# =============================================================================
#  Reversal Bot — release packager (seller-side only)
# =============================================================================
#  Run from project root:  pwsh -File installer\build-release.ps1
#  Output:  dist\ReversalBot-v<VERSION>.zip
#
#  Excludes (sensitive / dev-only):
#    - state\           (your local DB + license cache)
#    - logs\
#    - .venv\
#    - __pycache__\
#    - .pytest_cache\
#    - .git\
#    - reports\         (backtest CSVs)
#    - data\            (parquet OHLCV cache, ~5 MB - users can re-download)
#    - tests\           (skipped to keep ZIP small; ship in docs/dev edition)
#    - *.db / *.pem / .env
# =============================================================================
$ErrorActionPreference = "Stop"

$ProjectRoot = Split-Path -Parent $PSScriptRoot
$Version     = "1.0.0"   # bump on each release
$ZipName     = "ReversalBot-v$Version.zip"
$DistDir     = Join-Path $ProjectRoot "dist"
$ZipPath     = Join-Path $DistDir $ZipName
$StagingDir  = Join-Path $DistDir "_staging_$Version"

Write-Host "================================================================"
Write-Host "  Reversal Bot - Release Packager"
Write-Host "  Version: $Version"
Write-Host "================================================================"
Write-Host ""

# Clean previous build
if (Test-Path $DistDir) { Remove-Item -Recurse -Force $DistDir }
New-Item -ItemType Directory -Path $StagingDir | Out-Null

Write-Host "  [1/4] Copying files to staging..." -ForegroundColor Yellow

$exclude = @(
    "state", "logs", ".venv", "venv", "__pycache__", ".pytest_cache",
    ".git", ".github", "reports", "data", "tests", "dist",
    "node_modules", ".vscode", ".idea"
)

robocopy $ProjectRoot $StagingDir /E `
    /XD $exclude `
    /XF "*.db" "*.db-shm" "*.db-wal" "*.pem" ".env" "*.log" "*.parquet" "*.csv" "*.pyc" "run.ps1" `
    /NFL /NDL /NJH /NJS /NC /NS | Out-Null

# Verify no secrets in staging
Write-Host "  [2/4] Verifying no secrets in staging..." -ForegroundColor Yellow

$secrets = Get-ChildItem -Path $StagingDir -Recurse -File | Where-Object {
    $_.Name -match "\.(pem|env|key)$" -or
    $_.Name -match "private" -or
    $_.FullName -match "\\state\\"
}
if ($secrets) {
    Write-Host "  ABORTED - secrets detected in staging:" -ForegroundColor Red
    $secrets | ForEach-Object { Write-Host "    $($_.FullName)" -ForegroundColor Red }
    Remove-Item -Recurse -Force $StagingDir
    exit 1
}
Write-Host "    OK - no secrets found" -ForegroundColor Green

# Verify required files
$required = @(
    "src", "scripts", "index.html", "config.yaml", "requirements.txt",
    "README.md", "INSTALL.md", "LICENSING.md", "ADVANTAGES.md",
    "installer\install.bat", "installer\install.ps1", "installer\uninstall.bat"
)
foreach ($f in $required) {
    $path = Join-Path $StagingDir $f
    if (-not (Test-Path $path)) {
        Write-Host "  MISSING required file: $f" -ForegroundColor Red
        exit 1
    }
}
Write-Host "    OK - all required files present" -ForegroundColor Green

# Compute size before zipping
$staged = Get-ChildItem -Path $StagingDir -Recurse -File | Measure-Object -Property Length -Sum
Write-Host "    Staged: $($staged.Count) files, $([math]::Round($staged.Sum/1KB, 1)) KB" -ForegroundColor Green

Write-Host "  [3/4] Creating ZIP..." -ForegroundColor Yellow
Compress-Archive -Path "$StagingDir\*" -DestinationPath $ZipPath -CompressionLevel Optimal -Force
$zipSize = (Get-Item $ZipPath).Length
Write-Host "    ZIP: $ZipPath" -ForegroundColor Green
Write-Host "    Size: $([math]::Round($zipSize/1KB, 1)) KB" -ForegroundColor Green

Write-Host "  [4/4] Cleaning staging..." -ForegroundColor Yellow
Remove-Item -Recurse -Force $StagingDir
Write-Host "    Done" -ForegroundColor Green

Write-Host ""
Write-Host "================================================================"
Write-Host "  Release built successfully!" -ForegroundColor Green
Write-Host "================================================================"
Write-Host ""
Write-Host "  ZIP file: $ZipPath"
Write-Host ""
Write-Host "  Distribution checklist:"
Write-Host "    [_] Upload ZIP to download server / Gumroad / Lemon Squeezy"
Write-Host "    [_] Update download link on landing page"
Write-Host "    [_] Tag git commit: git tag v$Version && git push --tags"
Write-Host "    [_] Announce update to existing customers"
Write-Host ""
