# =============================================================================
#  Reversal Bot — automated installer for Windows
# =============================================================================
#  What this does, in order:
#    1. Check Python 3.10+ (offers download if missing)
#    2. Create a venv at .venv\ (isolated from system Python)
#    3. Install all dependencies from requirements.txt
#    4. Initialize the SQLite DB + seed watchlist
#    5. Create Start Menu shortcuts (Start Bot / Stop Bot / Open Dashboard)
#    6. Create desktop shortcut
#    7. Open a browser to license activation
#
#  Customer runs via install.bat (double-click). They DON'T edit this file.
# =============================================================================
$ErrorActionPreference = "Stop"

$ProjectRoot = Split-Path -Parent $PSScriptRoot
$VenvDir     = Join-Path $ProjectRoot ".venv"
$PythonExe   = Join-Path $VenvDir "Scripts\python.exe"

function Write-Header($msg) {
    Write-Host ""
    Write-Host "================================================================"
    Write-Host "  $msg" -ForegroundColor Cyan
    Write-Host "================================================================"
}

function Write-Ok($msg)    { Write-Host "  [OK] $msg" -ForegroundColor Green }
function Write-Step($msg)  { Write-Host "  --> $msg" -ForegroundColor Yellow }
function Write-Warn($msg)  { Write-Host "  [!]  $msg" -ForegroundColor Yellow }
function Write-Err($msg)   { Write-Host "  [X]  $msg" -ForegroundColor Red }


# =============================================================================
# 1. Banner
# =============================================================================
Clear-Host
Write-Host @"
================================================================
                     REVERSAL BOT INSTALLER
                          v1.0.0
================================================================

  This installer will:
    1. Check / install Python 3.10+
    2. Set up an isolated Python environment
    3. Install all bot dependencies
    4. Initialize the bot's database
    5. Create Start Menu and Desktop shortcuts

  Estimated time: 3-5 minutes (depending on internet speed)
  Disk space:     ~500 MB

  Press Ctrl+C at any time to abort safely.

"@ -ForegroundColor Cyan

Read-Host "Press Enter to begin installation..."


# =============================================================================
# 2. Python check
# =============================================================================
Write-Header "Step 1/6 - Checking Python"

$pythonCmd = $null
foreach ($cmd in @("python", "py -3.12", "py -3.11", "py -3.10")) {
    try {
        $version = & $cmd.Split(" ")[0] $cmd.Split(" ")[1..99] --version 2>&1
        if ($version -match "Python 3\.(1[0-9]|[2-9][0-9])") {
            $pythonCmd = $cmd
            Write-Ok "Found: $version"
            break
        }
    } catch { }
}

if (-not $pythonCmd) {
    Write-Warn "Python 3.10 or newer not found."
    Write-Host ""
    Write-Host "  Please install Python first:"
    Write-Host "    1. Download: https://www.python.org/downloads/" -ForegroundColor White
    Write-Host "    2. Run the installer" -ForegroundColor White
    Write-Host "    3. IMPORTANT: Tick 'Add Python to PATH' on the first screen" -ForegroundColor Yellow
    Write-Host "    4. Click 'Install Now'" -ForegroundColor White
    Write-Host "    5. Close + re-open this installer after install" -ForegroundColor White
    Write-Host ""
    Start-Process "https://www.python.org/downloads/"
    Read-Host "Press Enter to exit"
    exit 1
}


# =============================================================================
# 3. Create venv
# =============================================================================
Write-Header "Step 2/6 - Creating Python virtual environment"

if (Test-Path $VenvDir) {
    Write-Step "Removing existing venv (clean install)..."
    Remove-Item -Recurse -Force $VenvDir
}

Write-Step "Creating $VenvDir ..."
& $pythonCmd.Split(" ")[0] $pythonCmd.Split(" ")[1..99] -m venv $VenvDir
if ($LASTEXITCODE -ne 0) {
    Write-Err "Failed to create venv. Check Python install."
    Read-Host "Press Enter to exit"
    exit 1
}
Write-Ok "Virtual environment created"


# =============================================================================
# 4. Install dependencies
# =============================================================================
Write-Header "Step 3/6 - Installing dependencies (this is the slow step)"

Write-Step "Upgrading pip..."
& $PythonExe -m pip install --upgrade pip --quiet 2>&1 | Out-Null

Write-Step "Installing from requirements.txt..."
$reqFile = Join-Path $ProjectRoot "requirements.txt"
& $PythonExe -m pip install -r $reqFile
if ($LASTEXITCODE -ne 0) {
    Write-Err "pip install failed. Check internet connection."
    Read-Host "Press Enter to exit"
    exit 1
}
Write-Ok "All dependencies installed"


# =============================================================================
# 5. Initialize DB
# =============================================================================
Write-Header "Step 4/6 - Initializing database"

$initScript = @"
import sys
sys.path.insert(0, r'$ProjectRoot')
from src.db import init_db, DB_PATH
init_db()
print(f'DB initialized at: {DB_PATH}')
"@

$initScript | & $PythonExe -
if ($LASTEXITCODE -ne 0) {
    Write-Err "DB init failed"
    Read-Host "Press Enter to exit"
    exit 1
}
Write-Ok "Database ready"


# =============================================================================
# 6. Create launcher scripts (visible in project root)
# =============================================================================
Write-Header "Step 5/6 - Creating launcher scripts"

$startBat = Join-Path $ProjectRoot "START-BOT.bat"
@"
@echo off
title Reversal Bot - Dashboard
cd /d "%~dp0"
echo Starting Reversal Bot Dashboard...
echo.
echo Dashboard URL: http://localhost:8788
echo Press Ctrl+C in this window to stop the bot.
echo.
".venv\Scripts\python.exe" scripts\run_web.py
pause
"@ | Out-File -FilePath $startBat -Encoding ASCII
Write-Ok "Created START-BOT.bat"

$stopBat = Join-Path $ProjectRoot "STOP-BOT.bat"
@"
@echo off
title Reversal Bot - Stop
echo Stopping all Reversal Bot processes...
taskkill /F /IM python.exe /FI "WINDOWTITLE eq Reversal Bot - Dashboard*" 2>nul
echo Done.
timeout /t 2 >nul
"@ | Out-File -FilePath $stopBat -Encoding ASCII
Write-Ok "Created STOP-BOT.bat"

$tradeBat = Join-Path $ProjectRoot "START-TRADING.bat"
@"
@echo off
title Reversal Bot - Trading Loop
cd /d "%~dp0"
echo ================================================================
echo   Reversal Bot - Trading Loop
echo ================================================================
echo.
echo This window runs the trading strategy in DRY_RUN mode by default.
echo To enable LIVE trading on mainnet, set DRY_RUN=false before
echo launching this script.
echo.
echo Press Ctrl+C to stop.
echo.
if not defined DRY_RUN set DRY_RUN=true
".venv\Scripts\python.exe" scripts\run_live.py
pause
"@ | Out-File -FilePath $tradeBat -Encoding ASCII
Write-Ok "Created START-TRADING.bat"


# =============================================================================
# 7. Start Menu + Desktop shortcuts
# =============================================================================
Write-Header "Step 6/6 - Creating shortcuts"

$WshShell = New-Object -ComObject WScript.Shell
$startMenu = [Environment]::GetFolderPath("Programs")
$desktop   = [Environment]::GetFolderPath("Desktop")
$botFolder = Join-Path $startMenu "Reversal Bot"
New-Item -ItemType Directory -Force -Path $botFolder | Out-Null

function New-Shortcut($name, $target, $iconLocation, $args) {
    $sm = $WshShell.CreateShortcut((Join-Path $botFolder "$name.lnk"))
    $sm.TargetPath = $target
    $sm.Arguments = $args
    $sm.WorkingDirectory = $ProjectRoot
    if ($iconLocation) { $sm.IconLocation = $iconLocation }
    $sm.Save()
    Write-Ok "Start Menu: $name"
}

New-Shortcut "Start Reversal Bot" $startBat $null ""
New-Shortcut "Stop Reversal Bot"  $stopBat  $null ""
New-Shortcut "Start Trading Loop" $tradeBat $null ""

# Desktop shortcut to the dashboard launcher (most common use)
$desk = $WshShell.CreateShortcut((Join-Path $desktop "Reversal Bot.lnk"))
$desk.TargetPath = $startBat
$desk.WorkingDirectory = $ProjectRoot
$desk.Description = "Open the Reversal Bot dashboard"
$desk.Save()
Write-Ok "Desktop shortcut created"


# =============================================================================
# 8. Done
# =============================================================================
Write-Header "Installation complete!"
Write-Host @"

  Next steps:

    1. ACTIVATE YOUR LICENSE
       The dashboard is about to open in your browser.
       On the home screen, click "Activate" to redeem a code,
       or "Pricing" to see all tiers.

    2. CREATE YOUR ADMIN ACCOUNT
       After license activation, you'll see the Sign-In screen.
       In a PowerShell window, run:

         cd "$ProjectRoot"
         .venv\Scripts\python.exe scripts\manage.py user create -u admin

       Then return to the browser and sign in.

    3. ADD YOUR EXCHANGE API KEY
       Sign in -> Unlock vault -> API Keys -> + Add key
       Recommended: start with OKX demo trading (free \$10k testnet).

    4. RUN THE BOT
       Double-click "START-TRADING.bat" on your desktop or in this folder.

  Support: dht.io.vn@gmail.com

"@ -ForegroundColor White

Write-Step "Opening dashboard in browser..."
Start-Process $startBat
Start-Sleep -Seconds 3
Start-Process "http://localhost:8788"

Write-Host ""
Write-Host "Installation finished. You can close this window." -ForegroundColor Green
