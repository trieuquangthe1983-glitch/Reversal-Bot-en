@echo off
title Reversal Bot - Uninstaller
echo ================================================================
echo                  Reversal Bot - Uninstaller
echo ================================================================
echo.
echo  This will:
echo    - Stop any running bot processes
echo    - Remove Start Menu shortcuts
echo    - Remove Desktop shortcut
echo    - DELETE the .venv folder (frees ~500 MB)
echo.
echo  NOT removed (your data is safe):
echo    - state\bot.db          (your license + users + trades + DB)
echo    - state\learner.json    (learner state)
echo    - logs\                 (history of bot activity)
echo.
echo  To completely wipe, delete this whole folder afterwards.
echo.
choice /m "Continue with uninstall"
if errorlevel 2 exit /b

REM Kill bot processes
taskkill /F /IM python.exe /FI "WINDOWTITLE eq Reversal Bot*" 2>nul

REM Remove shortcuts
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$sm = [Environment]::GetFolderPath('Programs'); ^
   Remove-Item -Recurse -Force (Join-Path $sm 'Reversal Bot') -ErrorAction SilentlyContinue; ^
   $desk = [Environment]::GetFolderPath('Desktop'); ^
   Remove-Item -Force (Join-Path $desk 'Reversal Bot.lnk') -ErrorAction SilentlyContinue; ^
   Write-Host 'Shortcuts removed.' -ForegroundColor Green"

REM Remove venv
if exist "%~dp0..\.venv" (
    echo Removing .venv folder...
    rmdir /S /Q "%~dp0..\.venv"
)

REM Remove launcher batch files
del /F /Q "%~dp0..\START-BOT.bat" 2>nul
del /F /Q "%~dp0..\STOP-BOT.bat" 2>nul
del /F /Q "%~dp0..\START-TRADING.bat" 2>nul

echo.
echo Uninstall complete. Your state and logs were preserved.
echo To delete those too, manually remove this folder.
echo.
pause
