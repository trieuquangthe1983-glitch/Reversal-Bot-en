# Why Reversal Bot

A scoring of what this bot does that most retail trading bots don't.

## TL;DR

| Capability | Reversal Bot | Typical retail bot |
|---|---|---|
| **Strategy depth** | Two complementary models (daily reversal + Liquidity-Trap Reversal) with explicit confluence detection | One strategy hard-coded |
| **Learning** | Bayesian Beta-Bernoulli + Gaussian E[R] + online logistic per bucket, with meta-learner allocating risk per strategy | Static parameters or naive grid search |
| **Risk** | Risk-% sizing, split TP 50/30/20 at 1R/2R/3R, per-symbol cooldown, max concurrent positions, confidence-scaled size | Fixed lot size or % equity |
| **Execution** | OKX testnet + Gate.io live (Unified Account, isolated 15× default), pluggable factory | Single exchange, single mode |
| **Persistence** | SQLite (WAL) with 14 tables, full audit + portfolio snapshot history | JSON files or no persistence |
| **Auth** | bcrypt cost-12 login + Fernet+PBKDF2 vault for API keys + sliding 8h sessions | Plaintext API keys in config |
| **Verification** | Self-tests: 100+ pytest cases gating release | Untested |
| **Licensing** | Cryptographic activation codes + on-chain BSC payment verification | None or trivial |
| **Anti-fraud** | Rate-limited activation, 1 license = 1 machine binding, tx_hash uniqueness, audit-logged everything | Easy to clone |
| **Operator UX** | 12-tab browser dashboard (FastAPI + Alpine + Chart.js) | CLI only or no UI |

---

## 1. Two strategies in one engine

The base strategy detects **daily candles (GMT+7) that move ≥1.05% from open and then reverse 1.2–6.5% from the intraday extreme**, entering counter-trend on the reversal. Statistically grounded — 2 years of Binance 1h OHLCV across 10 tokens (BTC, ETH, SOL, SUI, XRP, ZEC, LINK, ONDO, ASTER, DOGE) feed the backtester, expectancy is computed in R units.

The second strategy — **Liquidity-Trap Reversal (LTR)** — independently fires on HTF swing-pool sweeps with LTF rejection wicks, gated by funding rate z-score, OI delta, and CVD divergence. A `StrategyRouter` runs both on each scan; when they fire same-side a **confluence trade** is taken with tighter SL and wider TPs.

Compare: most retail bots have one fixed strategy with no theory backing it.

## 2. Adaptive learner v2 (Bayesian + Frequentist + online ML)

Three layers per (symbol, side, init_bucket, rev_bucket):

- **L1 Beta-Bernoulli posterior** for win-rate
- **L2 Gaussian E[R]** for expected R-multiple
- **L3 online logistic regression** with 14 contextual features (initial/reversal/ATR, BTC regime, funding z-score, OI delta, CVD divergence, hour-of-day sin/cos, day-of-week sin/cos)

Confidence blends across layers gated by sample size; sub-0.40 setups are auto-skipped. State persists to `state/learner_v2.json` so restarts don't reset learning.

## 3. Meta-learner risk weighting

EMA expected-R per strategy → `tanh(ema_r)` → risk-weight multiplier capped 0.2–1.6× base allocation. Base allocations: reversal 0.60, LTR 0.40, confluence 1.30. When confluence prints good R, it gets more capital; when LTR underperforms, it gets less — automatically, with no manual tuning.

## 4. Risk-first sizing

- `risk_per_trade_pct` of equity → contracts derived from SL distance
- `max_leverage` cap with auto leverage selection
- Split TP at 1R/2R/3R (50%/30%/20%) — captures both quick wins and runners
- Per-symbol cooldown to avoid revenge-trading the same setup
- `max_concurrent_positions` ceiling
- Confidence-scaled size (<0.50 = proportionally smaller, <0.40 = skip)

## 5. Multi-exchange execution

Pluggable executor factory:

```python
_make_executor("gateio", default_leverage=15) -> GateioExecutor
_make_executor("okx") -> OKXExecutor
```

Gate.io support is full-stack: Unified Account balance read via `unifiedAccount: true`, isolated margin per-symbol, contract conversion using `market[contractSize]`, SL/TP via ccxt unified `stopLossPrice`/`takeProfitPrice`. Reduced-only brackets attach after entry fill.

## 6. SQLite as the system of record

14 tables, all WAL-mode for concurrent reads:

`users`, `api_keys`, `parameters` (versioned), `pattern_detections`, `trades`, `learner_buckets`, `tuning_runs`, `equity_snapshots`, `audit_log`, `sessions`, `watchlist`, `portfolio_snapshots`, `licenses`, `payment_proofs`, `activation_attempts`.

Every state change is queryable in SQL. No silent state in JSON files.

## 7. Hardened authentication

- **bcrypt cost-12** for login passwords with account lockout after 5 failures
- **Fernet + PBKDF2-310k** for API key vault (separate password from login)
- **Sliding 8h session TTL** + 30-day cookie max-age, sliding on every request
- **Atomic vault rotation**: change vault password → re-encrypts all keys in one transaction
- **Two-step LIVE enable** for mainnet keys (`I_UNDERSTAND_REAL_MONEY` confirm token)

## 8. Pre-trade calculator (no risk to play with)

Plug entry/SL/equity → get contracts, notional, margin required, liquidation estimate, TP ladder, and **5 safety warnings** (SL too tight, SL too wide, heavy margin, high leverage, aggressive risk). 1-click quick-fill from any detected pattern.

## 9. Licensing + on-chain payment

- USDT-BEP20 payment to a published wallet
- Server-side verification of tx_hash via BSC public RPC (no third-party API key needed)
- HMAC-signed activation codes bound to your machine
- Hybrid architecture: starts self-contained, supports optional online server check (future-proof)
- 1 license = 1 machine, transferable via support email (`dht.io.vn@gmail.com`)

## 10. Anti-fraud belt

- **Rate limit**: 5 failed activation attempts/hour/IP
- **tx_hash uniqueness**: each transaction can only mint one code
- **Trial gate**: machine_id checked so users can't endlessly redeem the trial
- **Replay protection**: each code carries a nonce, every code persisted in DB
- **Hard expiry**: bot startup refuses to run if license is expired or absent (unless `DRY_RUN=true` + `LICENSE_BYPASS=1` for testing)
- **Audit log**: every login, vault unlock, key access, parameter change, watchlist edit, license event recorded

## 11. Tests as code-of-truth

100+ pytest cases gate every release:

- Pattern detector: short/long setup, reversal-max excluded, current-day
- Risk: sizing, leverage caps, confidence scaling
- Learner v1 + v2: bucket increment, persistence, strategy isolation, logistic overfit
- LTR: swing detection, sweep+rejection, confluence score bounds
- Web: auth flow, vault unlock, key add/test/enable-live, calculator math, portfolio snapshot history, session sliding, license tiers/codes/activation

## 12. Browser dashboard, no install

Single-file SPA (`index.html`) → Tailwind CDN + Alpine.js + Chart.js. No npm, no bundler, no build step. Open `http://localhost:8788` and you have:

Dashboard · Portfolio (with snapshot history) · Watchlist · Calculator · Trades · Patterns · Parameters · API Keys · Learner · Audit · DB Browser · License · Settings.

---

## Honest failure modes

Things we don't hide:

1. **The HMAC secret embeds in the binary.** If someone reverse-engineers it they can mint codes — that's why we're moving to hybrid online verification. Realistically: $29-$569 product, this is acceptable first-line defense.
2. **The reversal pattern's edge will degrade.** Markets adapt. The learner partially compensates but you should monitor weekly.
3. **VPS with random MAC won't work.** Machine binding requires a stable MAC; cloud VMs that randomize MAC each boot trigger re-activation. Email support for a transfer.
4. **Gate.io requires Unified Account.** If you don't enable it manually on Gate.io's web UI first, balance reads fail. The UI shows a hint.
5. **LTR adds 60s/scan in rate-limit cost.** Funding/OI/CVD fetches are per-symbol per loop. Acceptable for 10 symbols on a 60s loop, won't scale to hundreds.

Support: **dht.io.vn@gmail.com**
