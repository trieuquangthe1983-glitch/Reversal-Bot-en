# 📦 Reversal Bot — Installation Guide

**English** · [Tiếng Việt below](#installation-tiếng-việt)

---

## Quick Start (3 minutes)

1. **Extract** the `ReversalBot.zip` you downloaded to a folder of your choice
   (e.g., `C:\ReversalBot\`).
2. **Double-click** `installer\install.bat` inside the extracted folder.
3. Approve the **administrator** prompt when Windows asks.
4. Wait ~3 minutes for the installer to download Python deps.
5. The dashboard opens automatically at **http://localhost:8788**.

That's it. Three Start Menu shortcuts and a Desktop shortcut are created
for you.

---

## What you get

After install you have:

| File | Purpose |
|---|---|
| `START-BOT.bat` (in project root + Desktop) | Opens the web dashboard |
| `START-TRADING.bat` | Starts the trading loop (DRY_RUN by default) |
| `STOP-BOT.bat` | Kills all bot processes |
| Start Menu → `Reversal Bot` folder | Shortcuts to all 3 above |
| `installer\uninstall.bat` | Clean removal (keeps your data) |

---

## First-time setup checklist

After installation, do these once:

### ☐ 1. Activate your license

On the dashboard home screen:
- Click **💎 Pricing** to see all 5 tiers
- Pay USDT on **BSC (BEP20)** or **Tron (TRC20)** to the displayed wallet
- Wait 30 seconds for blockchain confirmations
- Click **🔑 Activate** → select network → paste tx hash → tier → submit
- Activation code is minted automatically and bound to your machine

### ☐ 2. Create an admin user

Open **PowerShell** in the install folder:

```powershell
cd "C:\ReversalBot"
.venv\Scripts\python.exe scripts\manage.py user create -u admin
```

Choose a strong password (≥12 chars, mix of upper/lower/digits/symbols).

### ☐ 3. Sign in

Go back to the dashboard at http://localhost:8788 — sign in with the
account you just created. You'll see the main dashboard.

### ☐ 4. Unlock vault

Click **🔓 Unlock vault** in the header. Use the same password as login
(for the very first user; you can change it later).

### ☐ 5. Add an exchange API key

Tab **API Keys** → **+ Add key**:
- Pick **OKX** (testnet recommended for first-time) or **Gate.io**
- Paste your API key + secret + passphrase (OKX needs all 3)
- Tick **Testnet** if it's a demo-trading key
- Save

For Gate.io: enable **Unified Account** on Gate.io's web UI first.

### ☐ 6. Configure trading defaults

Tab **⚙️ Settings**:
- **Timezone**: dropdown — pick your region
- **Trading defaults**: risk %, max leverage, max positions, etc.

### ☐ 7. Test in DRY_RUN

Double-click `START-TRADING.bat` — the bot scans every 60 seconds.
In DRY_RUN mode, it detects patterns and logs them but does NOT place
real orders. Watch logs in the terminal window or in the **Patterns**
tab of the dashboard.

### ☐ 8. Enable LIVE trading (when ready)

⚠️ **Real money.** Test thoroughly in DRY_RUN first.

In **API Keys** tab, click **🚨 Enable LIVE** on a mainnet key.
You'll be asked to type `I_UNDERSTAND_REAL_MONEY` as confirmation.

Then close `START-TRADING.bat` and re-launch with:
```powershell
$env:DRY_RUN = "false"
.\START-TRADING.bat
```

---

## Troubleshooting

| Problem | Fix |
|---|---|
| "Python 3.10 not found" | Install Python from https://python.org, **tick "Add to PATH"** during install |
| Dashboard won't open (`localhost:8788` ERR_CONNECTION_REFUSED) | Run `START-BOT.bat` — server isn't running |
| Login fails on Edge | Edge Tracking Prevention blocks cookies. Switch to **Basic** mode in Edge Settings, or use Chrome |
| OKX `Invalid Sign` (code 50113) | Re-create API key on OKX, double-check secret + passphrase, make sure Testnet flag matches |
| Gate.io `Unified Account` errors | Enable Unified Account on Gate.io web UI first |
| License "no longer active" | Check internet connection; bot heartbeats license server every 6h |
| "Port 8788 in use" | Another app uses this port. Edit `START-BOT.bat` and add `--port 9100` |

---

## Updating

When a new version comes out:

1. Download the new ZIP
2. Run `installer\uninstall.bat` (your data is preserved)
3. Extract new version OVER the old folder
4. Run `installer\install.bat` again

Your license, users, trades, and learner state all persist in `state\`
which is **not touched** by uninstall.

---

## Support

📧 **Email:** dht.io.vn@gmail.com

When emailing support, include:
- Your machine ID (visible in dashboard → License tab)
- License tier
- Screenshot or text of the error
- What you were doing when the error happened

---

# Installation (Tiếng Việt)

## Cài đặt nhanh (3 phút)

1. **Giải nén** file `ReversalBot.zip` đã tải về vào thư mục anh thích
   (ví dụ `C:\ReversalBot\`)
2. **Click đúp** vào `installer\install.bat` trong thư mục vừa giải nén
3. Chấp nhận yêu cầu **administrator** khi Windows hỏi
4. Chờ ~3 phút để installer tải dependencies Python
5. Dashboard tự mở tại **http://localhost:8788**

Xong. 3 shortcut Start Menu + 1 shortcut Desktop được tạo sẵn.

## Checklist lần đầu setup

### ☐ 1. Kích hoạt bản quyền

Màn hình chính dashboard:
- Click **💎 Pricing** xem 5 gói
- Chuyển USDT trên **BSC (BEP20)** hoặc **Tron (TRC20)** tới ví hiển thị
- Chờ 30 giây để blockchain confirm
- Click **🔑 Activate** → chọn network → paste tx hash → chọn tier → submit

### ☐ 2. Tạo user admin

Mở **PowerShell** trong thư mục cài:

```powershell
cd "C:\ReversalBot"
.venv\Scripts\python.exe scripts\manage.py user create -u admin
```

Đặt mật khẩu mạnh (≥12 ký tự, mix chữ hoa/thường/số/ký tự đặc biệt).

### ☐ 3. Đăng nhập + unlock vault + add API key + test

Theo các bước 3-8 ở phần tiếng Anh trên.

## Khắc phục sự cố

Bảng troubleshooting xem ở phần tiếng Anh — error message của bot hiển
thị bằng tiếng Anh nên dễ tìm.

## Hỗ trợ

📧 **Email:** dht.io.vn@gmail.com

Khi liên hệ, kèm:
- Machine ID (xem ở tab License)
- Gói bản quyền đang dùng
- Screenshot hoặc text lỗi
- Anh đang làm gì khi gặp lỗi
