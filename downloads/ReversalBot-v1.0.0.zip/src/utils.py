"""Shared utilities: logging, config loading, timezone math."""
from __future__ import annotations
import logging
import os
import sys
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any

import yaml
from dotenv import load_dotenv

PROJECT_ROOT = Path(__file__).resolve().parent.parent


def load_env() -> None:
    """Load .env from project root if present."""
    env_path = PROJECT_ROOT / ".env"
    if env_path.exists():
        load_dotenv(env_path)
    else:
        load_dotenv(PROJECT_ROOT / ".env.example")


def load_config(path: str | None = None) -> dict[str, Any]:
    """Load config.yaml."""
    cfg_path = Path(path) if path else PROJECT_ROOT / "config.yaml"
    with open(cfg_path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def setup_logger(name: str, level: str | None = None) -> logging.Logger:
    """Console + file logger."""
    level = level or os.getenv("LOG_LEVEL", "INFO")
    logger = logging.getLogger(name)
    if logger.handlers:
        return logger
    logger.setLevel(level)
    fmt = logging.Formatter(
        "%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    sh = logging.StreamHandler(sys.stdout)
    sh.setFormatter(fmt)
    logger.addHandler(sh)
    logs_dir = PROJECT_ROOT / "logs"
    logs_dir.mkdir(exist_ok=True)
    fh = logging.FileHandler(logs_dir / f"{name}.log", encoding="utf-8")
    fh.setFormatter(fmt)
    logger.addHandler(fh)
    return logger


def utc_to_gmt7_date(ts_utc: datetime) -> str:
    """Return GMT+7 calendar date (YYYY-MM-DD) for a UTC timestamp."""
    if ts_utc.tzinfo is None:
        ts_utc = ts_utc.replace(tzinfo=timezone.utc)
    return (ts_utc + timedelta(hours=7)).strftime("%Y-%m-%d")


def gmt7_day_window_utc(date_str: str) -> tuple[datetime, datetime]:
    """Return (start_utc, end_utc) for a GMT+7 calendar date.

    GMT+7 00:00 == UTC 17:00 previous day.
    """
    d = datetime.strptime(date_str, "%Y-%m-%d").replace(tzinfo=timezone.utc)
    start = d - timedelta(hours=7)
    end = start + timedelta(days=1)
    return start, end


def pct(a: float, b: float) -> float:
    """Percent change a vs b (signed). pct(110, 100) -> 10.0"""
    if b == 0:
        return 0.0
    return (a - b) / b * 100.0


def ensure_dir(p: Path) -> Path:
    p.mkdir(parents=True, exist_ok=True)
    return p
