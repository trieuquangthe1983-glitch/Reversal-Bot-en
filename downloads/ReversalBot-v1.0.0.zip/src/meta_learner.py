"""Meta-learner: cross-strategy risk allocation.

Each closed trade reports (strategy, r_pnl). The meta-learner keeps a
decayed expected-R per strategy and produces a *risk weight* that the
risk manager multiplies on top of the base `risk_per_trade_pct`.

Rules of the game:
  - All strategies start at equal weight (= configured base allocation).
  - Each closed trade nudges its strategy's weight up (positive R) or down
    (negative R), with exponential decay so old evidence fades.
  - Weights are floored (so a losing strategy never drops to 0 — we still
    need data to detect a regime change) and capped (to avoid concentration).
  - Weights are L1-normalized to the configured TOTAL fraction so the
    portfolio's gross risk stays bounded.

Storage: JSON in state/meta_learner.json.
"""
from __future__ import annotations
import json
import math
import time
from dataclasses import dataclass, field, asdict
from typing import Optional

from .utils import PROJECT_ROOT, setup_logger, ensure_dir

log = setup_logger("meta_learner")
STATE_DIR = ensure_dir(PROJECT_ROOT / "state")
STATE_FILE = STATE_DIR / "meta_learner.json"


@dataclass
class StrategyStats:
    trades: int = 0
    wins: int = 0
    sum_r: float = 0.0
    ema_r: float = 0.0           # exponential moving average of R
    last_ts: float = 0.0

    @property
    def win_rate(self) -> float:
        return self.wins / self.trades if self.trades else 0.0

    @property
    def avg_r(self) -> float:
        return self.sum_r / self.trades if self.trades else 0.0


@dataclass
class MetaLearnerState:
    stats: dict[str, StrategyStats] = field(default_factory=dict)
    # Configured allocation (e.g. {"reversal": 0.6, "ltr": 0.4, "confluence": 0.5})
    # 'confluence' is a multiplier — when both fire, position is sized as the
    # confluence weight (typically > 1) on top of either base allocation.
    base_allocation: dict[str, float] = field(
        default_factory=lambda: {"reversal": 0.60, "ltr": 0.40, "confluence": 1.30},
    )
    ema_alpha: float = 0.10      # weight given to newest trade
    min_weight: float = 0.20     # floor multiplier (vs base alloc)
    max_weight: float = 1.60     # cap multiplier (vs base alloc)


class MetaLearner:

    def __init__(self,
                 base_allocation: Optional[dict[str, float]] = None,
                 ema_alpha: float = 0.10,
                 min_weight: float = 0.20,
                 max_weight: float = 1.60):
        self.state = MetaLearnerState(ema_alpha=ema_alpha,
                                      min_weight=min_weight,
                                      max_weight=max_weight)
        if base_allocation:
            self.state.base_allocation = dict(base_allocation)
        self._load()

    # -- persistence ----------------------------------------------------
    def _load(self) -> None:
        if not STATE_FILE.exists():
            return
        try:
            raw = json.loads(STATE_FILE.read_text())
            self.state.ema_alpha = raw.get("ema_alpha", 0.10)
            self.state.min_weight = raw.get("min_weight", 0.20)
            self.state.max_weight = raw.get("max_weight", 1.60)
            self.state.base_allocation = raw.get(
                "base_allocation", self.state.base_allocation,
            )
            self.state.stats = {k: StrategyStats(**v)
                                for k, v in raw.get("stats", {}).items()}
        except Exception as e:
            log.warning("meta state load failed (%s) -- starting fresh", e)

    def save(self) -> None:
        try:
            STATE_FILE.write_text(json.dumps({
                "ema_alpha": self.state.ema_alpha,
                "min_weight": self.state.min_weight,
                "max_weight": self.state.max_weight,
                "base_allocation": self.state.base_allocation,
                "stats": {k: asdict(v) for k, v in self.state.stats.items()},
            }, indent=2))
        except Exception as e:
            log.error("meta save failed: %s", e)

    # -- core API -------------------------------------------------------
    def record(self, strategy: str, r_pnl: float) -> None:
        s = self.state.stats.setdefault(strategy, StrategyStats())
        s.trades += 1
        if r_pnl > 0:
            s.wins += 1
        s.sum_r += float(r_pnl)
        # EMA update on R
        a = self.state.ema_alpha
        s.ema_r = (1 - a) * s.ema_r + a * float(r_pnl)
        s.last_ts = time.time()
        log.info("meta record %s r=%.3f -> ema_r=%.3f trades=%d wr=%.2f",
                 strategy, r_pnl, s.ema_r, s.trades, s.win_rate)
        self.save()

    def weight(self, strategy: str) -> float:
        """Risk multiplier for `strategy`. Returns a non-negative float that
        the risk manager multiplies onto the base `risk_per_trade_pct`."""
        base = self.state.base_allocation.get(strategy, 0.5)
        s = self.state.stats.get(strategy)
        if s is None or s.trades < 5:
            return base   # no info yet; use base allocation directly

        # Map ema_r to a multiplier centered at 1.0:
        # ema_r =  0   -> 1.0
        # ema_r = +0.5 -> ~1.4
        # ema_r = -0.5 -> ~0.6
        # ema_r = +1.0 -> ~1.8 (then capped by max_weight)
        mult = 1.0 + 0.8 * math.tanh(s.ema_r)
        mult = max(self.state.min_weight, min(self.state.max_weight, mult))
        return float(base * mult)

    def snapshot(self) -> dict:
        return {
            "base_allocation": dict(self.state.base_allocation),
            "weights": {k: round(self.weight(k), 3)
                        for k in self.state.base_allocation},
            "stats": {k: {"trades": v.trades, "wins": v.wins,
                          "win_rate": round(v.win_rate, 3),
                          "avg_r": round(v.avg_r, 3),
                          "ema_r": round(v.ema_r, 3)}
                      for k, v in self.state.stats.items()},
        }
