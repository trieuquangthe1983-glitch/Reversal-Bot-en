"""FastAPI web UI for the trading bot DB."""
from .app import app

__all__ = ["app"]
