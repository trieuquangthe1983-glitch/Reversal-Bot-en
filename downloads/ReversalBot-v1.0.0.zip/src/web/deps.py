"""Auth dependencies + in-memory vault session store."""
from __future__ import annotations
import threading
from typing import Optional

from fastapi import Cookie, Depends, HTTPException, status

from ..db import UserRepo
from ..db.repositories import SessionRepo
from ..db.vault import VaultSession

# In-memory: token -> VaultSession. Lost on server restart by design.
_vault_sessions: dict[str, VaultSession] = {}
_lock = threading.Lock()


def store_vault_session(token: str, sess: VaultSession) -> None:
    with _lock:
        _vault_sessions[token] = sess


def get_vault_session(token: str) -> Optional[VaultSession]:
    with _lock:
        return _vault_sessions.get(token)


def drop_vault_session(token: str) -> None:
    with _lock:
        _vault_sessions.pop(token, None)


# --- FastAPI dependencies -------------------------------------------------
def require_session(session: Optional[str] = Cookie(default=None)) -> dict:
    """Return current user row, or raise 401."""
    if not session:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "not logged in")
    uid = SessionRepo.get_user_id(session)
    if not uid:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "session expired")
    user = UserRepo.get_by_id(uid)
    if not user:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "user not found")
    return {"user": user, "token": session}


def require_admin(ctx: dict = Depends(require_session)) -> dict:
    if ctx["user"]["role"] != "admin":
        raise HTTPException(status.HTTP_403_FORBIDDEN, "admin role required")
    return ctx


def require_vault(ctx: dict = Depends(require_session)) -> tuple[dict, VaultSession]:
    vs = get_vault_session(ctx["token"])
    if vs is None:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "vault is locked")
    if vs.user_id != ctx["user"]["id"]:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "vault belongs to a different user")
    return ctx, vs


def require_active_license(ctx: dict = Depends(require_session)) -> tuple[dict, object]:
    """Gate: block the endpoint if this machine has no active license.

    Returns (ctx, license_status). HTTP 402 Payment Required is the right
    status code for "you need to pay before this endpoint works".
    """
    from ..licensing import LicenseManager
    lic = LicenseManager.status()
    if not lic.is_active:
        raise HTTPException(
            status.HTTP_402_PAYMENT_REQUIRED,
            f"license required: {lic.reason}. "
            f"Visit the Pricing tab to purchase or activate."
        )
    return ctx, lic
