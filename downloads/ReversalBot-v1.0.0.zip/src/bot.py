"""Main live-trading loop.

Polls intraday data for each symbol every `poll_interval_seconds`.
For each symbol, checks if a reversal pattern is forming in the current
GMT+7 day. If so, builds a setup, sizes it (factoring confidence from
the learner), places the bracketed order on the exchange, and watches
for fill / exit.

Persistence:
  - All pattern detections, trades, learner buckets, equity snapshots are
    persisted to SQLite (state/bot.db) via src.db.
  - Legacy JSON files (state/open_trades.json, etc.) are still maintained
    for back-compat but the DB is the source of truth.

Credentials:
  - If env var BOT_USER is set, credentials are loaded from the DB vault.
    Vault password comes from env VAULT_PASSWORD or stdin getpass prompt.
  - Else falls back to EXCHANGE_API_KEY / EXCHANGE_API_SECRET in .env.

Parameters:
  - DB parameter overrides (set via manage.py params set) take precedence
    over config.yaml on every scan.
"""
from __future__ import annotations
import getpass
import json
import os
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

import pandas as pd

from .data_fetcher import DataFetcher
from .db import (ApiKeyRepo, AuditRepo, EquityRepo, LearnerRepo, ParameterRepo,
                 PatternRepo, StrategyOutcomeRepo, TradeRepo, UserRepo,
                 WatchlistRepo, init_db)
from .db.connection import DB_PATH
from .executor import OKXExecutor
from .gateio_executor import GateioExecutor
from .learner import AdaptiveLearner
from .learner_v2 import AdaptiveLearnerV2
from .meta_learner import MetaLearner
from .regime import classify as classify_regime
from .strategy_router import MarketBundle, StrategyRouter


def _make_executor(exchange: str, *, api_key: str | None = None,
                   api_secret: str | None = None, passphrase: str | None = None,
                   testnet: bool = True, dry_run: bool = True,
                   default_leverage: int | None = None):
    """Factory: pick the right executor for the given exchange name."""
    name = (exchange or "okx").lower()
    if name in ("gateio", "gate"):
        return GateioExecutor(api_key=api_key, api_secret=api_secret,
                              passphrase=passphrase, testnet=testnet,
                              dry_run=dry_run,
                              default_leverage=default_leverage or 15)
    # default: OKX
    return OKXExecutor(api_key=api_key, api_secret=api_secret,
                       passphrase=passphrase, testnet=testnet, dry_run=dry_run)
from .pattern_detector import check_current_day, ReversalPattern
from .playbook import build_setup, TradeSetup
from .risk_manager import size_position
from .context import ContextFeatures
from .utils import (PROJECT_ROOT, ensure_dir, load_config, load_env,
                   setup_logger)

log = setup_logger("bot")
STATE_DIR = ensure_dir(PROJECT_ROOT / "state")
OPEN_TRADES_FILE = STATE_DIR / "open_trades.json"
CLOSED_TRADES_FILE = STATE_DIR / "closed_trades.json"
COOLDOWN_FILE = STATE_DIR / "cooldown.json"


def _merge_db_overrides(cfg: dict) -> dict:
    """Apply DB parameter overrides on top of config.yaml."""
    overrides = ParameterRepo.all_active()
    for ns, kv in overrides.items():
        if ns not in cfg:
            cfg[ns] = {}
        for k, v in kv.items():
            cfg[ns][k] = v
            log.info("[param-override] %s.%s = %r", ns, k, v)
    return cfg


def _load_credentials_from_db() -> dict | None:
    """If BOT_USER is set, unlock vault and return decrypted creds for the
    key labeled BOT_KEY_LABEL (default: first live-enabled key, fallback first key).
    Returns None if BOT_USER not set."""
    username = os.getenv("BOT_USER")
    if not username:
        return None
    if not DB_PATH.exists():
        init_db()
    user = UserRepo.get_by_username(username)
    if not user:
        raise RuntimeError(f"BOT_USER={username} not found in DB. Create it with manage.py user create")
    vault_pwd = os.getenv("VAULT_PASSWORD") or getpass.getpass(f"Vault password for {username}: ")
    sess = UserRepo.unlock_vault(username, vault_pwd)

    keys = ApiKeyRepo.list_for_user(user["id"])
    if not keys:
        raise RuntimeError(f"no API keys for user {username}. Add with manage.py key add")
    label = os.getenv("BOT_KEY_LABEL")
    if label:
        chosen = next((k for k in keys if k["label"] == label), None)
        if not chosen:
            raise RuntimeError(f"no key labeled '{label}' for user {username}")
    else:
        # prefer live-enabled if DRY_RUN is false; else first testnet
        dry = os.getenv("DRY_RUN", "true").lower() == "true"
        if dry:
            chosen = next((k for k in keys if k["is_testnet"]), keys[0])
        else:
            live = [k for k in keys if k["is_live_enabled"] and not k["is_testnet"]]
            if not live:
                raise RuntimeError("DRY_RUN=false but no live-enabled mainnet key found.\n"
                                   "Use [manage.py key enable-live --id N] first.")
            chosen = live[0]

    creds = ApiKeyRepo.get_decrypted(chosen["id"], sess)
    return {
        "user_id": user["id"],
        "key_id": chosen["id"],
        "exchange": chosen["exchange"],
        "is_testnet": bool(chosen["is_testnet"]),
        "api_key": creds["api_key"],
        "secret": creds["secret"],
        "passphrase": creds.get("passphrase", ""),
    }


def _enforce_license() -> None:
    """Hard-stop the bot if this machine has no active license.

    Honors LICENSE_BYPASS=1 ONLY when DRY_RUN=true — i.e. unlicensed users
    can simulate the bot in dry-run mode but cannot place live orders.
    """
    from .licensing import LicenseManager
    bypass = os.getenv("LICENSE_BYPASS", "0") == "1"
    dry = os.getenv("DRY_RUN", "true").lower() == "true"
    if bypass and dry:
        log.warning("LICENSE_BYPASS=1 in DRY_RUN — license check skipped (sim only)")
        return
    lic = LicenseManager.status()
    if not lic.is_active:
        raise RuntimeError(
            f"\n{'=' * 60}\n"
            f"  LICENSE REQUIRED — bot will not start.\n"
            f"  Reason: {lic.reason}\n"
            f"  Machine ID: {lic.machine_id}\n"
            f"  Buy a license at the dashboard's Pricing tab, or\n"
            f"  email dht.io.vn@gmail.com for support.\n"
            f"{'=' * 60}\n"
        )
    log.info("license OK: tier=%s, %s",
             lic.tier,
             "lifetime" if lic.is_lifetime else f"{lic.days_remaining} days remaining")


class ReversalBot:
    def __init__(self):
        load_env()
        _enforce_license()
        self.cfg = _merge_db_overrides(load_config())
        self.dry_run = os.getenv("DRY_RUN", "true").lower() == "true"
        self.binance = DataFetcher("binance")     # intraday data source

        # Load creds from DB if BOT_USER set, else from env
        db_creds = _load_credentials_from_db()
        gate_lev = (self.cfg.get("gateio", {}) or {}).get("leverage", 15)
        if db_creds:
            self.user_id = db_creds["user_id"]
            self.key_id = db_creds["key_id"]
            self.exchange_name = (db_creds["exchange"] or "okx").lower()
            self.executor = _make_executor(
                self.exchange_name,
                api_key=db_creds["api_key"],
                api_secret=db_creds["secret"],
                passphrase=db_creds["passphrase"],
                testnet=db_creds["is_testnet"],
                dry_run=self.dry_run,
                default_leverage=gate_lev,
            )
            log.info("loaded credentials from DB vault: user_id=%s key_id=%s exchange=%s testnet=%s",
                     self.user_id, self.key_id, self.exchange_name, db_creds["is_testnet"])
        else:
            self.user_id = None
            self.key_id = None
            self.exchange_name = (os.getenv("EXCHANGE_NAME", "okx") or "okx").lower()
            self.executor = _make_executor(
                self.exchange_name,
                testnet=os.getenv("EXCHANGE_TESTNET", "true").lower() == "true",
                dry_run=self.dry_run,
                default_leverage=gate_lev,
            )
            log.info("loaded credentials from env (.env) exchange=%s", self.exchange_name)

        # v1 learner kept as fallback for legacy callers / dashboards
        self.learner = AdaptiveLearner(
            prior_alpha=self.cfg["learner"]["prior_alpha"],
            prior_beta=self.cfg["learner"]["prior_beta"],
            decay_factor=self.cfg["learner"]["decay_factor"],
        )
        # v2 learner is the primary one for live decisions
        v2_cfg = self.cfg.get("learner_v2", {}) or {}
        self.learner_v2 = AdaptiveLearnerV2(
            prior_alpha=v2_cfg.get("prior_alpha", self.cfg["learner"]["prior_alpha"]),
            prior_beta=v2_cfg.get("prior_beta", self.cfg["learner"]["prior_beta"]),
            decay_factor=v2_cfg.get("decay_factor", self.cfg["learner"]["decay_factor"]),
            min_trades_for_bucket=v2_cfg.get("min_trades_for_bucket", 5),
            min_trades_for_logistic=v2_cfg.get("min_trades_for_logistic", 30),
        )
        meta_cfg = self.cfg.get("meta_learner", {}) or {}
        self.meta = MetaLearner(
            base_allocation=meta_cfg.get("base_allocation"),
            ema_alpha=meta_cfg.get("ema_alpha", 0.10),
            min_weight=meta_cfg.get("min_weight", 0.20),
            max_weight=meta_cfg.get("max_weight", 1.60),
        )
        self.router = StrategyRouter(self.cfg)
        self.open_trades: dict[str, dict] = self._load(OPEN_TRADES_FILE, {})
        self.cooldown: dict[str, float] = self._load(COOLDOWN_FILE, {})
        # is_live: 0=dry, 1=testnet real, 2=mainnet
        if self.dry_run:
            self.is_live = 0
        elif db_creds and db_creds["is_testnet"]:
            self.is_live = 1
        elif not db_creds and os.getenv("EXCHANGE_TESTNET", "true").lower() == "true":
            self.is_live = 1
        else:
            self.is_live = 2
        log.info("bot init: dry_run=%s is_live=%s symbols=%d",
                 self.dry_run, self.is_live, len(self.cfg["universe"]["binance_symbols"]))

    # -- helpers --------------------------------------------------------
    @staticmethod
    def _load(path: Path, default):
        if path.exists():
            try:
                return json.loads(path.read_text(encoding="utf-8"))
            except Exception:
                return default
        return default

    def _save(self, path: Path, obj) -> None:
        # Explicit utf-8: Windows default is cp1252, which breaks non-ASCII
        # (e.g., trader names with diacritics, log messages with emoji).
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(obj, indent=2, default=str, ensure_ascii=False),
                        encoding="utf-8")

    def _is_on_cooldown(self, symbol: str) -> bool:
        until = self.cooldown.get(symbol, 0)
        return time.time() < until

    def _set_cooldown(self, symbol: str) -> None:
        hrs = self.cfg["risk"].get("per_symbol_cooldown_hours", 12)
        self.cooldown[symbol] = time.time() + hrs * 3600
        self._save(COOLDOWN_FILE, self.cooldown)

    def _tz_offset_hours(self) -> float:
        """Trading timezone offset (hours from UTC). DB override takes
        precedence over config.yaml; defaults to 7 (Vietnam) if neither set."""
        tz_cfg = self.cfg.get("timezone", {}) or {}
        return float(tz_cfg.get("offset_hours", 7))

    def _today_gmt7_bars(self, symbol: str) -> pd.DataFrame:
        """Returns bars within the current calendar day in the user-configured
        timezone (default GMT+7 / Vietnam). Function name kept for back-compat;
        the offset itself is now configurable via DB parameter timezone.offset_hours.
        """
        df = self.binance.fetch_recent(symbol, timeframe=self.cfg["pattern"]["intraday_timeframe"],
                                       limit=48)
        if df.empty:
            return df
        offset = self._tz_offset_hours()
        now_utc = pd.Timestamp.utcnow().tz_localize(None)
        local_today = (now_utc + pd.Timedelta(hours=offset)).strftime("%Y-%m-%d")
        day_start_utc = pd.Timestamp(local_today) - pd.Timedelta(hours=offset)
        return df[df.index >= day_start_utc]

    # ---- Regime + LTR data helpers ------------------------------------
    def _current_regime(self):
        """Compute BTC regime from daily bars. Cached for 30 min."""
        now = time.time()
        cached = getattr(self, "_regime_cache", None)
        if cached and now - cached[0] < 1800:
            return cached[1]
        try:
            btc_daily = self.binance.fetch_recent("BTC/USDT", timeframe="1d", limit=400)
            reg = classify_regime(btc_daily)
        except Exception as e:
            log.warning("regime classify failed: %s", e)
            reg = None
        self._regime_cache = (now, reg)
        return reg

    def _build_market_bundle(self, bn_sym: str) -> MarketBundle:
        """Assemble all data the router needs for one symbol. Failures in
        any LTR-specific source are tolerated — the router will just skip
        LTR detection if too much is missing."""
        today_df = self._today_gmt7_bars(bn_sym)

        ltr_cfg = self.cfg.get("ltr", {}) or {}
        htf_tf = ltr_cfg.get("htf_timeframe", "4h")
        ltf_tf = ltr_cfg.get("ltf_timeframe", "1h")
        htf_df = None
        ltf_df = None
        funding_now = None
        funding_hist = None
        oi_hist = None
        cvd_df = None

        if ltr_cfg.get("enabled", True):
            try:
                htf_df = self.binance.fetch_recent(bn_sym, timeframe=htf_tf,
                                                   limit=ltr_cfg.get("htf_bars", 60))
                ltf_df = self.binance.fetch_recent(bn_sym, timeframe=ltf_tf,
                                                   limit=ltr_cfg.get("ltf_bars", 30))
            except Exception as e:
                log.debug("LTR OHLCV fetch failed %s: %s", bn_sym, e)
            try:
                funding_now = self.binance.fetch_funding_rate(bn_sym)
                funding_hist = self.binance.fetch_funding_history(
                    bn_sym, limit=ltr_cfg.get("funding_history_bars", 30))
            except Exception as e:
                log.debug("LTR funding fetch failed %s: %s", bn_sym, e)
            try:
                oi_hist = self.binance.fetch_open_interest_history(
                    bn_sym, timeframe=ltr_cfg.get("oi_timeframe", "5m"),
                    limit=ltr_cfg.get("oi_history_bars", 30))
            except Exception as e:
                log.debug("LTR OI fetch failed %s: %s", bn_sym, e)
            try:
                cvd_df = self.binance.compute_tick_rule_cvd(
                    bn_sym, timeframe=ltr_cfg.get("cvd_timeframe", "1m"),
                    limit=ltr_cfg.get("cvd_bars", 60))
            except Exception as e:
                log.debug("LTR CVD fetch failed %s: %s", bn_sym, e)

        return MarketBundle(
            symbol=bn_sym,
            today_intraday_df=today_df,
            htf_df=htf_df, ltf_df=ltf_df,
            funding_now=funding_now,
            funding_history=funding_hist,
            oi_history=oi_hist,
            cvd_df=cvd_df,
            regime=self._current_regime(),
        )

    # -- core loop ------------------------------------------------------
    def _resolve_universe(self) -> tuple[dict, dict]:
        """Watchlist DB takes precedence over config.yaml. Picks the symbol
        column matching the active exchange (gateio_symbol for Gate.io,
        okx_symbol otherwise). Falls back to config.yaml if watchlist is empty."""
        bn, exec_map = WatchlistRepo.get_active_universe_for(self.exchange_name)
        if bn:
            return bn, exec_map
        cfg_uni = self.cfg["universe"]
        key = ("gateio_symbols" if self.exchange_name in ("gateio", "gate")
               else "okx_symbols")
        return cfg_uni["binance_symbols"], cfg_uni.get(key, {})

    def scan_once(self) -> list[TradeSetup]:
        new_setups: list[TradeSetup] = []
        binance_syms, exec_syms = self._resolve_universe()
        min_conf = self.cfg.get("learner_v2", {}).get("min_confidence", 0.40)
        for token, bn_sym in binance_syms.items():
            if self._is_on_cooldown(token):
                continue
            if len(self.open_trades) >= self.cfg["risk"]["max_concurrent_positions"]:
                log.info("max concurrent positions reached; skipping new entries")
                break
            try:
                bundle = self._build_market_bundle(bn_sym)
            except Exception as e:
                log.warning("bundle build failed for %s: %s", bn_sym, e)
                continue
            routed = self.router.route(bundle)
            if routed is None:
                continue
            setup = routed.setup
            context = routed.context

            exec_sym = exec_syms.get(token)
            if not exec_sym:
                log.info("no %s swap symbol for %s -- skip", self.exchange_name, token)
                pat_dict = (routed.reversal_pattern.to_dict() if routed.reversal_pattern
                           else routed.ltr_pattern.to_dict())
                PatternRepo.record(pat_dict, acted_on=False,
                                  skip_reason=f"no_{self.exchange_name}_swap_symbol",
                                  strategy=setup.strategy,
                                  regime_label=context.regime_label,
                                  context=context.to_dict(),
                                  confluence_score=setup.meta.get("confluence_score"))
                continue
            setup.symbol = exec_sym

            # v2 confidence (Beta + Gaussian + logistic blend)
            confidence = self.learner_v2.confidence(setup, context)
            setup.confidence = confidence
            log.info("%s [%s] side=%s init=%.2f%% rev=%.2f%% regime=%s conf=%.2f",
                     setup.symbol, setup.strategy, setup.side,
                     setup.initial_move_pct, setup.reversal_pct,
                     context.regime_label, confidence)

            pat_for_db = (routed.reversal_pattern.to_dict() if routed.reversal_pattern
                         else routed.ltr_pattern.to_dict())
            # When confluence, prefer LTR's confluence_score for DB; else reversal has none.
            confluence_score = None
            if routed.ltr_pattern is not None:
                confluence_score = routed.ltr_pattern.confluence_score

            if confidence < min_conf:
                log.info("skip -- confidence below %.2f", min_conf)
                PatternRepo.record(pat_for_db, confidence=confidence,
                                  acted_on=False, skip_reason="confidence_below_threshold",
                                  strategy=setup.strategy,
                                  regime_label=context.regime_label,
                                  context=context.to_dict(),
                                  confluence_score=confluence_score)
                self._set_cooldown(token)
                continue
            pattern_id = PatternRepo.record(pat_for_db, confidence=confidence,
                                           acted_on=True,
                                           strategy=setup.strategy,
                                           regime_label=context.regime_label,
                                           context=context.to_dict(),
                                           confluence_score=confluence_score)
            self._take_trade(token, setup, pattern_id, context, confluence_score)
            new_setups.append(setup)
        return new_setups

    def _take_trade(self, token: str, setup: TradeSetup, pattern_id: int,
                    context: ContextFeatures | None = None,
                    confluence_score: float | None = None) -> None:
        equity = self.executor.get_balance()
        # Meta-learner adjusts risk per strategy
        strategy_weight = self.meta.weight(setup.strategy)
        base_risk = self.cfg["risk"]["risk_per_trade_pct"]
        effective_risk = base_risk * strategy_weight
        log.info("risk[%s] base=%.3f%% weight=%.2f -> effective=%.3f%%",
                 setup.strategy, base_risk, strategy_weight, effective_risk)
        sizing = size_position(
            setup, equity_usdt=equity,
            risk_per_trade_pct=effective_risk,
            max_leverage=self.cfg["risk"]["max_leverage"],
            confidence=setup.confidence,
        )
        if not sizing.accept:
            log.warning("sizing rejected: %s", sizing.reason)
            PatternRepo.record({"symbol": setup.symbol, "date_gmt7": setup.pattern_date,
                              "side": setup.side}, acted_on=False,
                              skip_reason=f"sizing_rejected:{sizing.reason}")
            return
        try:
            order = self.executor.place_entry(
                setup, sizing,
                use_limit=self.cfg["execution"]["use_limit_orders"],
                limit_offset_bps=self.cfg["execution"]["limit_offset_bps"],
            )
        except Exception as e:
            # Gate.io raises OrderRejectedByExchange for min-size/precision
            log.warning("place_entry rejected for %s: %s", setup.symbol, e)
            PatternRepo.record({"symbol": setup.symbol, "date_gmt7": setup.pattern_date,
                              "side": setup.side}, acted_on=False,
                              skip_reason=f"entry_rejected:{e}")
            return
        filled = self.executor.wait_for_fill(
            order.get("id"), setup.symbol,
            timeout_s=self.cfg["execution"]["order_timeout_seconds"],
        )
        if filled is None:
            log.info("entry did not fill in time -- cancel")
            self.executor.cancel_all_for_symbol(setup.symbol)
            return
        brackets = self.executor.attach_brackets(setup, sizing, entry_order=order)
        trade_db_id = TradeRepo.open_trade(
            pattern_id=pattern_id, setup_dict=setup.as_dict(),
            sizing_dict=sizing.__dict__, is_live=self.is_live,
            exchange_order_id=str(order.get("id", "")),
            regime_label=context.regime_label if context else None,
            context=context.to_dict() if context else None,
            confluence_score=confluence_score,
        )
        self.open_trades[setup.symbol] = {
            "token": token,
            "trade_db_id": trade_db_id,
            "setup": setup.as_dict(),
            "sizing": sizing.__dict__,
            "context": context.to_dict() if context else None,
            "strategy": setup.strategy,
            "entry_order_id": order.get("id"),
            "brackets": {k: v.get("id") if isinstance(v, dict) else v
                         for k, v in brackets.items()},
            "opened_at": datetime.now(timezone.utc).isoformat(),
        }
        self._save(OPEN_TRADES_FILE, self.open_trades)
        self._set_cooldown(token)
        # snapshot equity
        EquityRepo.snapshot(equity=equity,
                          open_positions=len(self.open_trades),
                          note=f"opened {setup.symbol}")

    def check_closures(self) -> None:
        if self.dry_run:
            return
        try:
            positions = self.executor.get_open_positions()
        except Exception as e:
            log.warning("positions fetch error: %s", e)
            return
        open_syms = {p["symbol"] for p in positions if p.get("contracts", 0) > 0}
        to_close = [s for s in self.open_trades if s not in open_syms]
        for sym in to_close:
            t = self.open_trades.pop(sym)
            setup_dict = t["setup"]
            setup = TradeSetup(**{k: v for k, v in setup_dict.items()
                                  if k in TradeSetup.__dataclass_fields__})
            try:
                last_price = float(self.executor.exchange.fetch_ticker(sym)["last"])
            except Exception:
                last_price = setup.entry
            if setup.side == "SHORT":
                r = (setup.entry - last_price) / (setup.sl - setup.entry)
                pct = (setup.entry - last_price) / setup.entry * 100
            else:
                r = (last_price - setup.entry) / (setup.entry - setup.sl)
                pct = (last_price - setup.entry) / setup.entry * 100
            log.info("closed %s [%s] realized_R=%.2f", sym, setup.strategy, r)

            # v1 learner (kept for legacy compatibility)
            self.learner.record_outcome(setup, r)
            self._mirror_learner_state()

            # v2 learner with full context
            ctx_dict = t.get("context") or {}
            ctx_obj = self._rehydrate_context(ctx_dict)
            self.learner_v2.record_outcome(setup, ctx_obj, r)

            # Meta-learner & per-strategy outcome log
            self.meta.record(setup.strategy, r)
            trade_db_id = t.get("trade_db_id")
            try:
                StrategyOutcomeRepo.record(
                    setup.strategy, r, symbol=setup.symbol, side=setup.side,
                    regime_label=ctx_obj.regime_label, confidence=setup.confidence,
                    trade_id=trade_db_id,
                )
            except Exception as e:
                log.warning("strategy outcome log failed: %s", e)

            if trade_db_id:
                TradeRepo.close_trade(trade_db_id, exit_price=last_price,
                                     exit_reason="auto", r_pnl=r, pct_pnl=pct)
            t["closed_r"] = r
            t["closed_at"] = datetime.now(timezone.utc).isoformat()
            self._append_closed(t)
        self._save(OPEN_TRADES_FILE, self.open_trades)

    @staticmethod
    def _rehydrate_context(ctx_dict: dict) -> "ContextFeatures":
        """Rebuild ContextFeatures from the dict we stored at entry time.
        Unknown / missing keys default to 0."""
        valid = {k: ctx_dict.get(k, 0.0) for k in
                 ContextFeatures.__dataclass_fields__ if k != "extras"}
        # cast back to float where applicable
        for k, v in list(valid.items()):
            if k == "regime_label":
                valid[k] = str(v or "unknown")
            else:
                try:
                    valid[k] = float(v)
                except (TypeError, ValueError):
                    valid[k] = 0.0
        return ContextFeatures(**valid)

    def _mirror_learner_state(self) -> None:
        for key, bs in self.learner.state.buckets.items():
            try:
                sym, side, ib, rb = key.split("|")
            except ValueError:
                continue
            LearnerRepo.upsert_bucket(
                bucket_key=key, symbol=sym, side=side,
                init_bucket=ib, rev_bucket=rb,
                alpha=bs.alpha, beta=bs.beta, trades=bs.trades, sum_r=bs.sum_r,
            )

    def _append_closed(self, trade: dict) -> None:
        history = self._load(CLOSED_TRADES_FILE, [])
        history.append(trade)
        self._save(CLOSED_TRADES_FILE, history)

    def run_forever(self) -> None:
        from .keepalive import allow_sleep, prevent_sleep, report_status
        from .licensing import LicenseManager

        interval = self.cfg["execution"]["poll_interval_seconds"]
        # License heartbeat: every 6h. The server tracks last-seen + can
        # revoke the license; this loop honors revocation/expiry mid-run.
        HEARTBEAT_INTERVAL = 6 * 3600
        last_heartbeat = time.time()

        prevent_sleep()
        log.info(report_status())
        log.info("bot running. interval=%ss heartbeat_every=%sh",
                 interval, HEARTBEAT_INTERVAL / 3600)
        AuditRepo.log(self.user_id, "bot_start",
                     {"dry_run": self.dry_run, "is_live": self.is_live,
                      "keepalive": True})
        try:
            while True:
                # --- periodic license heartbeat ------------------------------
                if time.time() - last_heartbeat >= HEARTBEAT_INTERVAL:
                    try:
                        st = LicenseManager.heartbeat()
                        if not st.is_active:
                            log.error("license is no longer active: %s — "
                                      "shutting down to prevent unlicensed trading",
                                      st.reason)
                            AuditRepo.log(self.user_id, "bot_stop_license",
                                          {"reason": st.reason})
                            break
                        log.info("heartbeat OK: tier=%s days_remaining=%s "
                                 "server_reachable=%s",
                                 st.tier, st.days_remaining, st.server_reachable)
                    except Exception as e:
                        # Don't fail the loop on heartbeat errors — the next
                        # cycle will retry. Grace period in status() handles
                        # extended outages.
                        log.warning("heartbeat call failed: %s", e)
                    last_heartbeat = time.time()

                # --- scan + close cycle --------------------------------------
                try:
                    self.check_closures()
                    self.scan_once()
                except KeyboardInterrupt:
                    log.info("interrupted, shutting down")
                    break
                except Exception as e:
                    log.exception("scan loop error: %s", e)
                time.sleep(interval)
        finally:
            allow_sleep()
            AuditRepo.log(self.user_id, "bot_stop")
