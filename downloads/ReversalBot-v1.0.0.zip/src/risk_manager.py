"""Position sizing & leverage.

Rule: risk a fixed % of equity per trade.
  contracts = (equity * risk_pct%) / (SL_distance_per_unit)

Leverage is set to satisfy the notional, capped by max_leverage.
"""
from __future__ import annotations
from dataclasses import dataclass

from .playbook import TradeSetup
from .utils import setup_logger

log = setup_logger("risk")


@dataclass
class SizingResult:
    notional: float
    contracts: float
    leverage: int
    risk_usdt: float
    margin_required: float
    accept: bool
    reason: str = ""


def size_position(
    setup: TradeSetup,
    equity_usdt: float,
    risk_per_trade_pct: float = 0.5,
    max_leverage: int = 10,
    confidence: float | None = None,
) -> SizingResult:
    """Compute contract count from risk per trade.

    confidence: optional 0..1 scaler (from learner). When confidence < 0.5
    position is shrunk; when > 0.5 it can scale UP but never above 1x risk budget.
    """
    risk_usdt = equity_usdt * (risk_per_trade_pct / 100.0)
    if confidence is not None:
        # symmetric scaling: 0.5 -> 1.0x, 0.0 -> 0.0x, 1.0 -> 1.0x (no over-scaling)
        risk_usdt *= min(1.0, max(0.0, 2 * confidence - 0.0))  # 0..1
        # cleaner formula: capped at 1.0
        risk_usdt = min(risk_usdt, equity_usdt * (risk_per_trade_pct / 100.0))

    sl_distance = abs(setup.entry - setup.sl)
    if sl_distance <= 0:
        return SizingResult(0, 0, 1, 0, 0, False, "sl_distance_zero")

    contracts = risk_usdt / sl_distance
    notional = contracts * setup.entry
    leverage = min(max_leverage, max(1, int(notional / max(equity_usdt * 0.10, 1)) + 1))
    margin_required = notional / leverage

    accept = margin_required <= equity_usdt * 0.95
    reason = "" if accept else "insufficient_margin"

    return SizingResult(
        notional=round(notional, 2),
        contracts=round(contracts, 6),
        leverage=leverage,
        risk_usdt=round(risk_usdt, 2),
        margin_required=round(margin_required, 2),
        accept=accept,
        reason=reason,
    )
