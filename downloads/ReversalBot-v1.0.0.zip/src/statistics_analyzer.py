"""Statistical analysis of reversal patterns across symbols.

Outputs:
  - per-symbol summary (count, by-direction, by-month frequency)
  - distribution of initial_move_pct and reversal_pct
  - empirical conditional probabilities (if rally >= X, prob reversal >= Y)
"""
from __future__ import annotations
from pathlib import Path

import numpy as np
import pandas as pd

from .utils import PROJECT_ROOT, setup_logger, ensure_dir

log = setup_logger("stats")
REPORTS_DIR = ensure_dir(PROJECT_ROOT / "reports")


def summarize(patterns_df: pd.DataFrame) -> pd.DataFrame:
    """One row per symbol with aggregate stats."""
    if patterns_df.empty:
        return pd.DataFrame()
    grouped = patterns_df.groupby("symbol")
    rows = []
    for sym, g in grouped:
        shorts = (g["side"] == "SHORT").sum()
        longs = (g["side"] == "LONG").sum()
        rows.append({
            "symbol": sym,
            "total_patterns": len(g),
            "short_setups": int(shorts),
            "long_setups": int(longs),
            "median_initial_move_pct": round(g["initial_move_pct"].median(), 3),
            "median_reversal_pct": round(g["reversal_pct"].median(), 3),
            "p75_reversal_pct": round(g["reversal_pct"].quantile(0.75), 3),
            "max_reversal_pct": round(g["reversal_pct"].max(), 3),
        })
    return pd.DataFrame(rows).sort_values("total_patterns", ascending=False)


def monthly_frequency(patterns_df: pd.DataFrame) -> pd.DataFrame:
    if patterns_df.empty:
        return pd.DataFrame()
    df = patterns_df.copy()
    df["month"] = pd.to_datetime(df["date_gmt7"]).dt.to_period("M").astype(str)
    return df.groupby(["symbol", "month"]).size().unstack(fill_value=0)


def conditional_table(patterns_df: pd.DataFrame,
                     initial_buckets: list[float] | None = None,
                     reversal_buckets: list[float] | None = None) -> pd.DataFrame:
    """P(reversal >= R | initial >= I) -- the bread and butter for trade edge.

    Note: this is computed across ALREADY-FILTERED patterns (those meeting
    the base condition). For unbiased conditional probabilities you must
    compare against the universe of all days, which is done in
    `unconditional_table` below.
    """
    initial_buckets = initial_buckets or [1.05, 1.5, 2.0, 3.0, 5.0]
    reversal_buckets = reversal_buckets or [1.2, 1.5, 2.0, 3.0, 5.0]
    rows = []
    for sym, g in patterns_df.groupby("symbol"):
        total = len(g)
        for i_thr in initial_buckets:
            sub = g[g["initial_move_pct"] >= i_thr]
            n = len(sub)
            if n == 0:
                continue
            for r_thr in reversal_buckets:
                hits = (sub["reversal_pct"] >= r_thr).sum()
                rows.append({
                    "symbol": sym,
                    "initial_move>=": i_thr,
                    "reversal>=": r_thr,
                    "n_qualified": n,
                    "n_reversal_hit": int(hits),
                    "prob": round(hits / n, 3) if n else None,
                    "share_of_all_patterns": round(n / total, 3) if total else None,
                })
    return pd.DataFrame(rows)


def unconditional_base_rate(patterns_df: pd.DataFrame,
                            total_days_per_symbol: dict[str, int]) -> pd.DataFrame:
    """Raw frequency: how often does a pattern occur per symbol per year."""
    rows = []
    for sym, days in total_days_per_symbol.items():
        sub = patterns_df[patterns_df["symbol"] == sym]
        rows.append({
            "symbol": sym,
            "days_observed": days,
            "patterns_total": len(sub),
            "patterns_short": int((sub["side"] == "SHORT").sum()),
            "patterns_long": int((sub["side"] == "LONG").sum()),
            "patterns_per_year": round(len(sub) / max(days, 1) * 365, 2),
        })
    return pd.DataFrame(rows)


def export_reports(patterns_df: pd.DataFrame,
                  total_days_per_symbol: dict[str, int],
                  out_prefix: str = "patterns") -> dict[str, Path]:
    """Write all summary CSVs. Returns dict of names -> paths."""
    paths = {}
    p = REPORTS_DIR / f"{out_prefix}_raw.csv"
    patterns_df.to_csv(p, index=False)
    paths["raw"] = p

    summ = summarize(patterns_df)
    p = REPORTS_DIR / f"{out_prefix}_summary.csv"
    summ.to_csv(p, index=False)
    paths["summary"] = p

    base = unconditional_base_rate(patterns_df, total_days_per_symbol)
    p = REPORTS_DIR / f"{out_prefix}_base_rate.csv"
    base.to_csv(p, index=False)
    paths["base_rate"] = p

    cond = conditional_table(patterns_df)
    p = REPORTS_DIR / f"{out_prefix}_conditional.csv"
    cond.to_csv(p, index=False)
    paths["conditional"] = p

    monthly = monthly_frequency(patterns_df)
    p = REPORTS_DIR / f"{out_prefix}_monthly.csv"
    monthly.to_csv(p)
    paths["monthly"] = p

    log.info("exported reports: %s", list(paths.keys()))
    return paths
