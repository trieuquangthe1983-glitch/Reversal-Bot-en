"""Core: detect intraday reversal patterns within a GMT+7 daily candle.

Pattern definition
==================
For each calendar day in GMT+7:

  SHORT setup (rally-then-drop):
    1. intraday high makes (high - day_open) / day_open * 100 >= initial_move_pct
    2. AFTER that high, price retraces down so that
       (high - subsequent_low) / high * 100 is within [reversal_min_pct, reversal_max_pct]

  LONG setup (drop-then-rally):
    1. intraday low makes (day_open - low) / day_open * 100 >= initial_move_pct
    2. AFTER that low, price rebounds so that
       (subsequent_high - low) / low * 100 is within [reversal_min_pct, reversal_max_pct]

The "trade trigger" is the moment the reversal magnitude first crosses
reversal_min_pct -- that is when the bot would consider entering.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import timedelta
from typing import Optional

import pandas as pd


@dataclass
class ReversalPattern:
    symbol: str
    date_gmt7: str
    side: str                     # "SHORT" or "LONG"
    day_open: float
    day_close: float
    extreme: float                # intraday high (SHORT) or low (LONG)
    extreme_time_utc: pd.Timestamp
    reversal_target: float        # subsequent low (SHORT) or high (LONG)
    reversal_time_utc: pd.Timestamp
    initial_move_pct: float       # how much price moved before reversing
    reversal_pct: float           # magnitude of reversal from extreme
    trigger_price: float          # price at which reversal_min_pct first crossed
    trigger_time_utc: pd.Timestamp

    def to_dict(self) -> dict:
        d = asdict(self)
        d["extreme_time_utc"] = pd.Timestamp(self.extreme_time_utc).isoformat()
        d["reversal_time_utc"] = pd.Timestamp(self.reversal_time_utc).isoformat()
        d["trigger_time_utc"] = pd.Timestamp(self.trigger_time_utc).isoformat()
        return d


def _add_gmt7_date(df: pd.DataFrame, offset_hours: int = 7) -> pd.DataFrame:
    df = df.copy()
    df["gmt7_date"] = (df.index + timedelta(hours=offset_hours)).strftime("%Y-%m-%d")
    return df


def _find_trigger(
    after_extreme: pd.DataFrame,
    extreme_price: float,
    side: str,
    reversal_min_pct: float,
) -> Optional[tuple[pd.Timestamp, float]]:
    """Find first bar after extreme where reversal crosses min threshold.
    Returns (timestamp, trigger_price) or None."""
    if side == "SHORT":
        target = extreme_price * (1 - reversal_min_pct / 100.0)
        # first bar whose low touches the target
        hits = after_extreme[after_extreme["low"] <= target]
    else:
        target = extreme_price * (1 + reversal_min_pct / 100.0)
        hits = after_extreme[after_extreme["high"] >= target]
    if hits.empty:
        return None
    return hits.index[0], target


def detect_patterns(
    df_intraday: pd.DataFrame,
    symbol: str,
    initial_move_pct: float = 1.05,
    reversal_min_pct: float = 1.20,
    reversal_max_pct: float = 6.50,
    tz_offset_hours: int = 7,
    min_bars_per_day: int = 6,
) -> list[ReversalPattern]:
    """Scan a multi-day intraday DataFrame and return all qualifying patterns.

    `df_intraday` must be indexed by UTC datetime and contain
    columns ['open', 'high', 'low', 'close'].
    """
    if df_intraday.empty:
        return []

    df = _add_gmt7_date(df_intraday, tz_offset_hours)
    patterns: list[ReversalPattern] = []

    for date, day in df.groupby("gmt7_date", sort=True):
        if len(day) < min_bars_per_day:
            continue
        day_open = float(day["open"].iloc[0])
        day_close = float(day["close"].iloc[-1])

        # --- SHORT setup: rally then drop ----------------------------
        high_idx = day["high"].idxmax()
        high = float(day.loc[high_idx, "high"])
        rally_pct = (high - day_open) / day_open * 100.0
        if rally_pct >= initial_move_pct:
            after_high = day.loc[high_idx:].iloc[1:]
            if not after_high.empty:
                low_after = float(after_high["low"].min())
                low_idx = after_high["low"].idxmin()
                reversal_pct = (high - low_after) / high * 100.0
                if reversal_min_pct <= reversal_pct <= reversal_max_pct:
                    trig = _find_trigger(after_high, high, "SHORT", reversal_min_pct)
                    if trig is not None:
                        patterns.append(ReversalPattern(
                            symbol=symbol,
                            date_gmt7=date,
                            side="SHORT",
                            day_open=day_open,
                            day_close=day_close,
                            extreme=high,
                            extreme_time_utc=high_idx,
                            reversal_target=low_after,
                            reversal_time_utc=low_idx,
                            initial_move_pct=rally_pct,
                            reversal_pct=reversal_pct,
                            trigger_price=float(trig[1]),
                            trigger_time_utc=trig[0],
                        ))

        # --- LONG setup: drop then rally -----------------------------
        low_idx = day["low"].idxmin()
        low = float(day.loc[low_idx, "low"])
        drop_pct = (day_open - low) / day_open * 100.0
        if drop_pct >= initial_move_pct:
            after_low = day.loc[low_idx:].iloc[1:]
            if not after_low.empty:
                high_after = float(after_low["high"].max())
                hi_idx = after_low["high"].idxmax()
                reversal_pct = (high_after - low) / low * 100.0
                if reversal_min_pct <= reversal_pct <= reversal_max_pct:
                    trig = _find_trigger(after_low, low, "LONG", reversal_min_pct)
                    if trig is not None:
                        patterns.append(ReversalPattern(
                            symbol=symbol,
                            date_gmt7=date,
                            side="LONG",
                            day_open=day_open,
                            day_close=day_close,
                            extreme=low,
                            extreme_time_utc=low_idx,
                            reversal_target=high_after,
                            reversal_time_utc=hi_idx,
                            initial_move_pct=drop_pct,
                            reversal_pct=reversal_pct,
                            trigger_price=float(trig[1]),
                            trigger_time_utc=trig[0],
                        ))

    return patterns


def patterns_to_df(patterns: list[ReversalPattern]) -> pd.DataFrame:
    return pd.DataFrame([p.to_dict() for p in patterns])


# --- Live detection helper ------------------------------------------------
def check_current_day(
    df_today_intraday: pd.DataFrame,
    symbol: str,
    initial_move_pct: float,
    reversal_min_pct: float,
    reversal_max_pct: float,
) -> Optional[ReversalPattern]:
    """Run pattern detector on the partial current day's intraday data.
    Returns the latest qualifying pattern or None.

    Caller is responsible for passing only data from current GMT+7 day.
    """
    if df_today_intraday.empty or len(df_today_intraday) < 2:
        return None
    day_open = float(df_today_intraday["open"].iloc[0])

    # SHORT
    high_idx = df_today_intraday["high"].idxmax()
    high = float(df_today_intraday.loc[high_idx, "high"])
    rally_pct = (high - day_open) / day_open * 100.0
    if rally_pct >= initial_move_pct:
        after = df_today_intraday.loc[high_idx:].iloc[1:]
        if not after.empty:
            cur_low = float(after["low"].min())
            cur_low_idx = after["low"].idxmin()
            rev = (high - cur_low) / high * 100.0
            if reversal_min_pct <= rev <= reversal_max_pct:
                trig_price = high * (1 - reversal_min_pct / 100.0)
                return ReversalPattern(
                    symbol=symbol,
                    date_gmt7=(df_today_intraday.index[0] + timedelta(hours=7)).strftime("%Y-%m-%d"),
                    side="SHORT",
                    day_open=day_open,
                    day_close=float(df_today_intraday["close"].iloc[-1]),
                    extreme=high,
                    extreme_time_utc=high_idx,
                    reversal_target=cur_low,
                    reversal_time_utc=cur_low_idx,
                    initial_move_pct=rally_pct,
                    reversal_pct=rev,
                    trigger_price=trig_price,
                    trigger_time_utc=cur_low_idx,
                )

    # LONG
    low_idx = df_today_intraday["low"].idxmin()
    low = float(df_today_intraday.loc[low_idx, "low"])
    drop_pct = (day_open - low) / day_open * 100.0
    if drop_pct >= initial_move_pct:
        after = df_today_intraday.loc[low_idx:].iloc[1:]
        if not after.empty:
            cur_high = float(after["high"].max())
            cur_high_idx = after["high"].idxmax()
            rev = (cur_high - low) / low * 100.0
            if reversal_min_pct <= rev <= reversal_max_pct:
                trig_price = low * (1 + reversal_min_pct / 100.0)
                return ReversalPattern(
                    symbol=symbol,
                    date_gmt7=(df_today_intraday.index[0] + timedelta(hours=7)).strftime("%Y-%m-%d"),
                    side="LONG",
                    day_open=day_open,
                    day_close=float(df_today_intraday["close"].iloc[-1]),
                    extreme=low,
                    extreme_time_utc=low_idx,
                    reversal_target=cur_high,
                    reversal_time_utc=cur_high_idx,
                    initial_move_pct=drop_pct,
                    reversal_pct=rev,
                    trigger_price=trig_price,
                    trigger_time_utc=cur_high_idx,
                )

    return None
