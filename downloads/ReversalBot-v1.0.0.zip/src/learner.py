"""Adaptive learner: refine entry conditions from real trade outcomes.

Model
-----
For each (symbol, side, initial_move_bucket) we maintain Beta(alpha, beta)
posterior over the trade's probability of being profitable (>0 R).

Bucket key is a discretized version of `initial_move_pct` (because that is
the user-facing knob). For each bucket we keep:

    alpha, beta, trades, last_update_ts, ev_R (running mean R-PnL).

Two outputs:
    confidence(setup) -> 0..1     posterior mean win-prob
    optimal_thresholds()          best initial_move/reversal/SL combo by
                                  Thompson sample over the grid

Decay
-----
Old evidence is decayed each time a new trade lands (alpha,beta) <- ((alpha-1)*d + 1, (beta-1)*d + 1) with d in (0,1].
This makes the learner adapt to regime change.

Persistence
-----------
JSON file in state/learner.json. Robust to bot restarts.
"""
from __future__ import annotations
import json
import math
import random
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any

import numpy as np

from .playbook import TradeSetup
from .utils import PROJECT_ROOT, setup_logger, ensure_dir

log = setup_logger("learner")
STATE_DIR = ensure_dir(PROJECT_ROOT / "state")
STATE_FILE = STATE_DIR / "learner.json"


def bucket_initial_move(pct: float) -> str:
    """Discretize initial_move_pct into named buckets."""
    if pct < 1.2:
        return "lo"
    if pct < 1.6:
        return "mid"
    if pct < 2.5:
        return "hi"
    return "xtrm"


def bucket_reversal(pct: float) -> str:
    if pct < 1.5:
        return "shallow"
    if pct < 2.5:
        return "med"
    if pct < 4.0:
        return "deep"
    return "extreme"


@dataclass
class BucketStats:
    alpha: float = 1.0
    beta: float = 1.0
    trades: int = 0
    sum_r: float = 0.0
    last_ts: float = 0.0

    @property
    def win_prob_mean(self) -> float:
        return self.alpha / (self.alpha + self.beta)

    @property
    def avg_r(self) -> float:
        return self.sum_r / self.trades if self.trades else 0.0


@dataclass
class LearnerState:
    buckets: dict[str, BucketStats] = field(default_factory=dict)
    prior_alpha: float = 1.0
    prior_beta: float = 1.0
    decay_factor: float = 0.985

    def _key(self, symbol: str, side: str, init_bucket: str, rev_bucket: str) -> str:
        return f"{symbol}|{side}|{init_bucket}|{rev_bucket}"

    def get_or_create(self, key: str) -> BucketStats:
        if key not in self.buckets:
            self.buckets[key] = BucketStats(alpha=self.prior_alpha, beta=self.prior_beta)
        return self.buckets[key]


class AdaptiveLearner:
    def __init__(self,
                 prior_alpha: float = 1.0,
                 prior_beta: float = 1.0,
                 decay_factor: float = 0.985):
        self.state = LearnerState(
            prior_alpha=prior_alpha, prior_beta=prior_beta, decay_factor=decay_factor,
        )
        self._load()

    # -- persistence ----------------------------------------------------
    def _load(self) -> None:
        if not STATE_FILE.exists():
            return
        try:
            raw = json.loads(STATE_FILE.read_text())
            self.state.prior_alpha = raw.get("prior_alpha", 1.0)
            self.state.prior_beta = raw.get("prior_beta", 1.0)
            self.state.decay_factor = raw.get("decay_factor", 0.985)
            self.state.buckets = {
                k: BucketStats(**v) for k, v in raw.get("buckets", {}).items()
            }
            log.info("loaded learner state: %d buckets", len(self.state.buckets))
        except Exception as e:
            log.warning("learner state load failed (%s) -- starting fresh", e)

    def save(self) -> None:
        try:
            STATE_FILE.write_text(json.dumps({
                "prior_alpha": self.state.prior_alpha,
                "prior_beta": self.state.prior_beta,
                "decay_factor": self.state.decay_factor,
                "buckets": {k: asdict(v) for k, v in self.state.buckets.items()},
            }, indent=2))
        except Exception as e:
            log.error("learner save failed: %s", e)

    # -- core API -------------------------------------------------------
    def confidence(self, setup: TradeSetup) -> float:
        ib = bucket_initial_move(setup.initial_move_pct)
        rb = bucket_reversal(setup.reversal_pct)
        key = self.state._key(setup.symbol, setup.side, ib, rb)
        bs = self.state.get_or_create(key)
        if bs.trades < 5:
            # not enough evidence, return prior
            return self.state.prior_alpha / (self.state.prior_alpha + self.state.prior_beta)
        return bs.win_prob_mean

    def record_outcome(self,
                       setup: TradeSetup,
                       r_pnl: float) -> None:
        """Update the bucket. r_pnl > 0 counted as success."""
        ib = bucket_initial_move(setup.initial_move_pct)
        rb = bucket_reversal(setup.reversal_pct)
        key = self.state._key(setup.symbol, setup.side, ib, rb)
        bs = self.state.get_or_create(key)
        # decay (apply to "excess over prior")
        d = self.state.decay_factor
        bs.alpha = (bs.alpha - self.state.prior_alpha) * d + self.state.prior_alpha
        bs.beta = (bs.beta - self.state.prior_beta) * d + self.state.prior_beta
        if r_pnl > 0:
            bs.alpha += 1.0
        else:
            bs.beta += 1.0
        bs.trades += 1
        bs.sum_r += float(r_pnl)
        import time as _t
        bs.last_ts = _t.time()
        log.info("learner update %s -> alpha=%.2f beta=%.2f trades=%d avg_R=%.3f",
                 key, bs.alpha, bs.beta, bs.trades, bs.avg_r)
        self.save()

    def thompson_sample(self, key: str) -> float:
        bs = self.state.get_or_create(key)
        # numpy random beta
        return float(np.random.beta(max(bs.alpha, 1e-3), max(bs.beta, 1e-3)))

    # -- threshold tuning ----------------------------------------------
    def best_thresholds(self,
                        symbol: str,
                        side: str,
                        initial_grid: list[float],
                        reversal_grid: list[float],
                        min_trades: int = 10) -> dict[str, Any]:
        """Among buckets with enough data, recommend a primary (init, reversal)
        combo by Thompson sample of win_prob * (1 + avg_R)."""
        best = None
        best_score = -1.0
        details = []
        for ib_name in ["lo", "mid", "hi", "xtrm"]:
            for rb_name in ["shallow", "med", "deep", "extreme"]:
                k = self.state._key(symbol, side, ib_name, rb_name)
                bs = self.state.buckets.get(k)
                if not bs or bs.trades < min_trades:
                    continue
                sample = self.thompson_sample(k)
                score = sample * (1.0 + max(bs.avg_r, -0.5))
                details.append({
                    "init_bucket": ib_name, "rev_bucket": rb_name,
                    "trades": bs.trades, "avg_r": round(bs.avg_r, 3),
                    "win_prob_mean": round(bs.win_prob_mean, 3),
                    "thompson_sample": round(sample, 3),
                    "score": round(score, 3),
                })
                if score > best_score:
                    best_score = score
                    best = (ib_name, rb_name, bs)
        if best is None:
            return {"recommendation": None, "details": details}
        ib_name, rb_name, bs = best
        return {
            "recommendation": {
                "initial_move_bucket": ib_name,
                "reversal_bucket": rb_name,
                "trades": bs.trades,
                "win_prob_mean": round(bs.win_prob_mean, 3),
                "avg_r": round(bs.avg_r, 3),
                "score": round(best_score, 3),
            },
            "details": details,
        }
