"""Trade simulator.

For each detected pattern, simulate the trade that the bot would have placed:
  Entry: at the trigger price (reversal_min_pct retrace from extreme)
  SL:    extreme +/- sl_buffer_pct (above high for SHORT, below low for LONG)
  TP:    R-multiples of risk (1R, 2R, 3R)
  Exit policy: split_tp | first_tp | eod_close | trailing

Returns a DataFrame of trades with PnL in R-multiples and percent.
"""
from __future__ import annotations
from dataclasses import dataclass
from datetime import timedelta
from typing import Optional

import numpy as np
import pandas as pd

from .pattern_detector import ReversalPattern
from .utils import setup_logger

log = setup_logger("backtester")


@dataclass
class BTConfig:
    fee_pct: float = 0.05
    slippage_pct: float = 0.03
    sl_buffer_pct: float = 0.30
    tp_r_multiples: tuple[float, ...] = (1.0, 2.0, 3.0)
    exit_policy: str = "split_tp"
    split_tp_weights: tuple[float, ...] = (0.5, 0.3, 0.2)


def _trade_pnl(
    side: str,
    entry: float,
    sl: float,
    intraday_after_entry: pd.DataFrame,
    cfg: BTConfig,
) -> dict:
    """Simulate one trade. intraday_after_entry contains bars STRICTLY AFTER
    entry timestamp (sorted by time)."""
    if intraday_after_entry.empty:
        return {"outcome": "no_data", "r_pnl": 0.0, "pct_pnl": 0.0}

    if side == "SHORT":
        risk = sl - entry            # positive
        tp_prices = [entry - r * risk for r in cfg.tp_r_multiples]
        for _, bar in intraday_after_entry.iterrows():
            # check SL first (conservative if both touched in same bar)
            if bar["high"] >= sl:
                fee = entry * cfg.fee_pct / 100 + sl * cfg.fee_pct / 100
                pct = -(sl - entry) / entry * 100 - cfg.slippage_pct - cfg.fee_pct * 2
                return {"outcome": "sl", "r_pnl": -1.0, "pct_pnl": round(pct, 4),
                        "exit_price": sl}
            for k, tp in enumerate(tp_prices):
                if bar["low"] <= tp:
                    if cfg.exit_policy == "first_tp":
                        pct = (entry - tp) / entry * 100 - cfg.slippage_pct - cfg.fee_pct * 2
                        return {"outcome": f"tp{k+1}", "r_pnl": cfg.tp_r_multiples[k],
                                "pct_pnl": round(pct, 4), "exit_price": tp}
        # EOD - exit at last close
        last_close = float(intraday_after_entry["close"].iloc[-1])
        r = (entry - last_close) / risk if risk > 0 else 0
        pct = (entry - last_close) / entry * 100 - cfg.slippage_pct - cfg.fee_pct * 2
        return {"outcome": "eod", "r_pnl": round(r, 3), "pct_pnl": round(pct, 4),
                "exit_price": last_close}

    else:  # LONG
        risk = entry - sl            # positive
        tp_prices = [entry + r * risk for r in cfg.tp_r_multiples]
        for _, bar in intraday_after_entry.iterrows():
            if bar["low"] <= sl:
                pct = -(entry - sl) / entry * 100 - cfg.slippage_pct - cfg.fee_pct * 2
                return {"outcome": "sl", "r_pnl": -1.0, "pct_pnl": round(pct, 4),
                        "exit_price": sl}
            for k, tp in enumerate(tp_prices):
                if bar["high"] >= tp:
                    if cfg.exit_policy == "first_tp":
                        pct = (tp - entry) / entry * 100 - cfg.slippage_pct - cfg.fee_pct * 2
                        return {"outcome": f"tp{k+1}", "r_pnl": cfg.tp_r_multiples[k],
                                "pct_pnl": round(pct, 4), "exit_price": tp}
        last_close = float(intraday_after_entry["close"].iloc[-1])
        r = (last_close - entry) / risk if risk > 0 else 0
        pct = (last_close - entry) / entry * 100 - cfg.slippage_pct - cfg.fee_pct * 2
        return {"outcome": "eod", "r_pnl": round(r, 3), "pct_pnl": round(pct, 4),
                "exit_price": last_close}


def _split_tp_pnl(side: str, entry: float, sl: float,
                  intraday_after_entry: pd.DataFrame, cfg: BTConfig) -> dict:
    """split_tp: weighted exit across TP1/TP2/TP3 with trailing tail."""
    if intraday_after_entry.empty:
        return {"outcome": "no_data", "r_pnl": 0.0, "pct_pnl": 0.0}

    weights = list(cfg.split_tp_weights)
    if len(weights) < len(cfg.tp_r_multiples):
        weights += [0.0] * (len(cfg.tp_r_multiples) - len(weights))
    weights = weights[: len(cfg.tp_r_multiples)]

    if side == "SHORT":
        risk = sl - entry
        tps = [entry - r * risk for r in cfg.tp_r_multiples]
        hit_flags = [False] * len(tps)
        r_realized = 0.0
        for _, bar in intraday_after_entry.iterrows():
            if bar["high"] >= sl:
                # SL: lose the un-realized portion (1R per remaining weight)
                remaining = 1.0 - sum(w for w, h in zip(weights, hit_flags) if h)
                r_realized -= remaining
                pct = r_realized * (sl - entry) / entry * 100 - cfg.slippage_pct - cfg.fee_pct * 2
                return {"outcome": "sl_after_partial", "r_pnl": round(r_realized, 3),
                        "pct_pnl": round(pct, 4), "exit_price": sl}
            for k, tp in enumerate(tps):
                if not hit_flags[k] and bar["low"] <= tp:
                    r_realized += weights[k] * cfg.tp_r_multiples[k]
                    hit_flags[k] = True
        # ran out of bars
        if all(hit_flags):
            outcome = "all_tp"
        elif any(hit_flags):
            outcome = "partial_tp_eod"
        else:
            outcome = "eod"
        # remaining tail closed at last close
        remaining = 1.0 - sum(w for w, h in zip(weights, hit_flags) if h)
        last_close = float(intraday_after_entry["close"].iloc[-1])
        tail_r = (entry - last_close) / risk if risk > 0 else 0
        r_realized += remaining * tail_r
        pct = r_realized * (sl - entry) / entry * 100 - cfg.slippage_pct - cfg.fee_pct * 2
        return {"outcome": outcome, "r_pnl": round(r_realized, 3),
                "pct_pnl": round(pct, 4), "exit_price": last_close}

    else:  # LONG mirrors above
        risk = entry - sl
        tps = [entry + r * risk for r in cfg.tp_r_multiples]
        hit_flags = [False] * len(tps)
        r_realized = 0.0
        for _, bar in intraday_after_entry.iterrows():
            if bar["low"] <= sl:
                remaining = 1.0 - sum(w for w, h in zip(weights, hit_flags) if h)
                r_realized -= remaining
                pct = r_realized * (entry - sl) / entry * 100 - cfg.slippage_pct - cfg.fee_pct * 2
                return {"outcome": "sl_after_partial", "r_pnl": round(r_realized, 3),
                        "pct_pnl": round(pct, 4), "exit_price": sl}
            for k, tp in enumerate(tps):
                if not hit_flags[k] and bar["high"] >= tp:
                    r_realized += weights[k] * cfg.tp_r_multiples[k]
                    hit_flags[k] = True
        if all(hit_flags):
            outcome = "all_tp"
        elif any(hit_flags):
            outcome = "partial_tp_eod"
        else:
            outcome = "eod"
        remaining = 1.0 - sum(w for w, h in zip(weights, hit_flags) if h)
        last_close = float(intraday_after_entry["close"].iloc[-1])
        tail_r = (last_close - entry) / risk if risk > 0 else 0
        r_realized += remaining * tail_r
        pct = r_realized * (entry - sl) / entry * 100 - cfg.slippage_pct - cfg.fee_pct * 2
        return {"outcome": outcome, "r_pnl": round(r_realized, 3),
                "pct_pnl": round(pct, 4), "exit_price": last_close}


def backtest(
    patterns: list[ReversalPattern],
    intraday_by_symbol: dict[str, pd.DataFrame],
    cfg: BTConfig,
    tz_offset_hours: int = 7,
) -> pd.DataFrame:
    """Simulate every pattern. `intraday_by_symbol` maps symbol -> full 1h DF."""
    results = []
    for p in patterns:
        df = intraday_by_symbol.get(p.symbol)
        if df is None or df.empty:
            continue
        # bars strictly after trigger, within the same GMT+7 day
        trig_ts = pd.Timestamp(p.trigger_time_utc)
        day_end_utc = (pd.Timestamp(p.date_gmt7) - pd.Timedelta(hours=tz_offset_hours)
                       + pd.Timedelta(days=1))
        post = df.loc[(df.index > trig_ts) & (df.index < day_end_utc)]
        entry = p.trigger_price
        if p.side == "SHORT":
            sl = p.extreme * (1 + cfg.sl_buffer_pct / 100.0)
        else:
            sl = p.extreme * (1 - cfg.sl_buffer_pct / 100.0)

        if cfg.exit_policy == "split_tp":
            res = _split_tp_pnl(p.side, entry, sl, post, cfg)
        else:
            res = _trade_pnl(p.side, entry, sl, post, cfg)

        results.append({
            "symbol": p.symbol,
            "date_gmt7": p.date_gmt7,
            "side": p.side,
            "initial_move_pct": round(p.initial_move_pct, 3),
            "reversal_pct": round(p.reversal_pct, 3),
            "entry": entry,
            "sl": sl,
            "outcome": res["outcome"],
            "r_pnl": res["r_pnl"],
            "pct_pnl": res["pct_pnl"],
            "exit_price": res.get("exit_price"),
        })
    return pd.DataFrame(results)


def performance_summary(trades: pd.DataFrame) -> pd.DataFrame:
    """Per-symbol performance breakdown."""
    if trades.empty:
        return pd.DataFrame()
    rows = []
    for sym, g in trades.groupby("symbol"):
        n = len(g)
        wins = (g["r_pnl"] > 0).sum()
        losses = (g["r_pnl"] < 0).sum()
        avg_r = g["r_pnl"].mean()
        win_rate = wins / n if n else 0
        gross_profit = g.loc[g["r_pnl"] > 0, "r_pnl"].sum()
        gross_loss = -g.loc[g["r_pnl"] < 0, "r_pnl"].sum()
        pf = gross_profit / gross_loss if gross_loss > 0 else float("inf")
        rows.append({
            "symbol": sym,
            "trades": n,
            "wins": int(wins),
            "losses": int(losses),
            "win_rate": round(win_rate, 3),
            "avg_r_pnl": round(avg_r, 3),
            "expectancy_R": round(avg_r, 3),
            "total_R": round(g["r_pnl"].sum(), 2),
            "total_pct": round(g["pct_pnl"].sum(), 2),
            "profit_factor": round(pf, 2),
            "max_drawdown_R": round(_max_dd(g["r_pnl"]), 2),
        })
    return pd.DataFrame(rows).sort_values("expectancy_R", ascending=False)


def _max_dd(r_series: pd.Series) -> float:
    eq = r_series.cumsum()
    peak = eq.cummax()
    dd = eq - peak
    return float(dd.min()) if not dd.empty else 0.0
