"""License manager — server-backed orchestration.

Flow
----
Buying:
   client UI -> manager.verify_payment_and_issue_code(tx, tier)
              -> server /verify-payment  (BSC verify + sign token)
              -> return token to UI

Activating:
   client UI -> manager.activate_code(token)
              -> verify Ed25519 signature LOCALLY (defense in depth)
              -> server /activate (registers + marks activated)
              -> store license row in local DB so we can answer status()
                 offline

Heartbeat (called by bot startup + every N hours):
   manager.heartbeat()
   -> server /heartbeat
   -> if reachable + ok: update last_ok_at
   -> if reachable + revoked/expired: hard-stop the bot
   -> if NOT reachable: allow up to GRACE_DAYS from last_ok_at; after that
      hard-stop

Status (called by UI + bot startup):
   manager.status()
   -> reads local DB license row + applies grace period for offline mode
   -> returns LicenseStatus dict
"""
from __future__ import annotations
import os
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Optional

from ..db.repositories import (LicenseRepo, PaymentProofRepo,
                              ActivationAttemptRepo, AuditRepo)
from . import client as license_client
from .client import LicenseServerError
from .codes import (DecodedToken, LicenseCodeError, peek_token,
                   verify_token)
from .fingerprint import machine_id as get_machine_id
from .tiers import TIERS, TierName


OFFLINE_GRACE_DAYS = int(os.getenv("LICENSE_OFFLINE_GRACE_DAYS", "7"))
RATE_LIMIT_FAILURES_PER_HOUR = 5
RATE_LIMIT_WINDOW_MINUTES = 60


@dataclass
class LicenseStatus:
    is_active: bool
    tier: Optional[str]
    expires_at: Optional[str]
    days_remaining: Optional[int]
    is_lifetime: bool
    machine_id: str
    server_reachable: Optional[bool] = None   # set after heartbeat
    last_heartbeat_at: Optional[str] = None
    grace_days_remaining: Optional[int] = None
    reason: str = ""

    def to_dict(self) -> dict:
        return {
            "is_active": self.is_active, "tier": self.tier,
            "expires_at": self.expires_at,
            "days_remaining": self.days_remaining,
            "is_lifetime": self.is_lifetime,
            "machine_id": self.machine_id,
            "server_reachable": self.server_reachable,
            "last_heartbeat_at": self.last_heartbeat_at,
            "grace_days_remaining": self.grace_days_remaining,
            "reason": self.reason,
        }


class LicenseRateLimitError(RuntimeError):
    pass


class LicenseManager:

    # ---------------------------------------------------------------------
    # status — answers "is this machine licensed right now?"
    # ---------------------------------------------------------------------
    @staticmethod
    def status(machine_id: Optional[str] = None) -> LicenseStatus:
        mid = machine_id or get_machine_id()
        row = LicenseRepo.get_active_for_machine(mid)
        if not row:
            return LicenseStatus(
                is_active=False, tier=None, expires_at=None,
                days_remaining=None, is_lifetime=False, machine_id=mid,
                reason="no active license — buy one to unlock the bot",
            )

        # Re-verify the stored token signature in case the file was tampered
        token_str = row.get("notes") or ""
        if not token_str:
            return LicenseStatus(
                is_active=False, tier=row["tier"], expires_at=row["expires_at"],
                days_remaining=None, is_lifetime=row["expires_at"] is None,
                machine_id=mid,
                reason="license row missing token (data corruption)",
            )
        try:
            t = verify_token(token_str, expected_machine_id=mid)
        except LicenseCodeError as e:
            return LicenseStatus(
                is_active=False, tier=row["tier"],
                expires_at=row["expires_at"], days_remaining=None,
                is_lifetime=row["expires_at"] is None,
                machine_id=mid, reason=f"token verify failed: {e}",
            )

        return LicenseStatus(
            is_active=True, tier=t.tier,
            expires_at=row["expires_at"],
            days_remaining=t.days_remaining(),
            is_lifetime=t.is_lifetime,
            machine_id=mid,
        )

    # ---------------------------------------------------------------------
    # verify payment via server (mint token)
    # ---------------------------------------------------------------------
    @staticmethod
    def verify_payment_and_issue_code(tx_hash: str, requested_tier: TierName,
                                      machine_id: Optional[str] = None,
                                      ip: Optional[str] = None,
                                      network: str = "bsc") -> dict:
        mid = machine_id or get_machine_id()
        if ip:
            fails = ActivationAttemptRepo.count_recent_failures(
                ip, minutes=RATE_LIMIT_WINDOW_MINUTES)
            if fails >= RATE_LIMIT_FAILURES_PER_HOUR:
                ActivationAttemptRepo.record(
                    ip=ip, machine_id=mid, code_prefix=None, tx_hash=tx_hash,
                    success=False,
                    error_reason=f"rate_limited_local:{fails}")
                raise LicenseRateLimitError(
                    "too many failed attempts; wait an hour.")

        try:
            r = license_client.verify_payment(
                tx_hash=tx_hash.strip(),
                tier=requested_tier,
                machine_id=mid,
                network=network,
            )
        except LicenseServerError as e:
            ActivationAttemptRepo.record(
                ip=ip, machine_id=mid, code_prefix=None, tx_hash=tx_hash,
                success=False, error_reason=f"server:{e}")
            raise

        # Audit only; the server stores the canonical record
        ActivationAttemptRepo.record(
            ip=ip, machine_id=mid, code_prefix=r.token, tx_hash=tx_hash,
            success=True, error_reason="")
        AuditRepo.log(
            user_id=None, event_type="license_code_issued",
            details={"tier": r.tier, "tx_hash": tx_hash, "machine_id": mid,
                    "amount_usdt": r.amount_usdt,
                    "license_id": r.license_id},
        )
        return {
            "code": r.token,           # kept the key name 'code' for UI compat
            "tier": r.tier,
            "machine_id": mid,
            "payment": {
                "tx_hash": tx_hash,
                "amount_usdt": r.amount_usdt,
                "confirmations": r.confirmations,
            },
        }

    # ---------------------------------------------------------------------
    # activate — verify locally + register with server + store locally
    # ---------------------------------------------------------------------
    @staticmethod
    def activate_code(code: str, machine_id: Optional[str] = None,
                     user_id: Optional[int] = None,
                     ip: Optional[str] = None) -> LicenseStatus:
        mid = machine_id or get_machine_id()
        if ip:
            fails = ActivationAttemptRepo.count_recent_failures(ip)
            if fails >= RATE_LIMIT_FAILURES_PER_HOUR:
                raise LicenseRateLimitError("too many failed attempts.")

        # Defence in depth: verify signature locally first
        try:
            t = verify_token(code, expected_machine_id=mid)
        except LicenseCodeError as e:
            ActivationAttemptRepo.record(
                ip=ip, machine_id=mid, code_prefix=code, tx_hash=None,
                success=False, error_reason=str(e))
            raise

        # Already activated on this machine? Return existing status
        existing = LicenseRepo.get_active_for_machine(mid)
        if existing and (existing.get("notes") or "") == code:
            return LicenseManager.status(mid)

        # Tell the server (registers + marks activated server-side)
        try:
            ar = license_client.activate(code, mid)
        except LicenseServerError as e:
            ActivationAttemptRepo.record(
                ip=ip, machine_id=mid, code_prefix=code, tx_hash=None,
                success=False, error_reason=f"server_activate_failed:{e}")
            raise

        # Persist to local DB
        license_id = LicenseRepo.insert(
            code=code,
            tier=ar.tier, machine_id=mid,
            payment_tx_hash=None,
            expires_at=ar.expires_at,
            user_id=user_id,
            notes=code,   # store full token here so we can re-verify in status()
        )

        ActivationAttemptRepo.record(
            ip=ip, machine_id=mid, code_prefix=code, tx_hash=None,
            success=True, error_reason="")
        AuditRepo.log(
            user_id=user_id, event_type="license_activated",
            details={"tier": ar.tier, "machine_id": mid,
                    "expires_at": ar.expires_at, "license_id": license_id,
                    "server_license_id": ar.license_id},
        )
        return LicenseManager.status(mid)

    # ---------------------------------------------------------------------
    # heartbeat — periodic server check with offline grace period
    # ---------------------------------------------------------------------
    @staticmethod
    def heartbeat(machine_id: Optional[str] = None) -> LicenseStatus:
        """Call the server's /heartbeat. Updates the local LicenseStatus
        with `server_reachable` and `last_heartbeat_at` fields. Handles
        offline grace period."""
        mid = machine_id or get_machine_id()
        st = LicenseManager.status(mid)
        if not st.is_active:
            st.reason = st.reason or "no active license on this machine"
            return st

        # Get the stored token (= row.notes)
        row = LicenseRepo.get_active_for_machine(mid)
        token = (row.get("notes") or "") if row else ""
        if not token:
            st.is_active = False
            st.reason = "no stored token"
            return st

        try:
            hb = license_client.heartbeat(token)
        except LicenseServerError as e:
            # Server unreachable -> check grace period
            st.server_reachable = False
            if row and row.get("activated_at"):
                last = datetime.fromisoformat(row["activated_at"])
                age = datetime.now(timezone.utc) - last
                grace_left = OFFLINE_GRACE_DAYS - age.days
                st.grace_days_remaining = max(0, grace_left)
                if grace_left <= 0:
                    st.is_active = False
                    st.reason = (f"license server unreachable for >"
                                 f"{OFFLINE_GRACE_DAYS} days; activate "
                                 f"network to re-validate")
                else:
                    st.reason = (f"server unreachable but offline grace: "
                                 f"{grace_left} days remaining")
            return st

        # Server responded
        st.server_reachable = True
        st.last_heartbeat_at = datetime.now(timezone.utc).isoformat(timespec="seconds")

        if hb.revoked:
            LicenseRepo.revoke(row["id"], hb.reason or "revoked by server")
            st.is_active = False
            st.reason = f"license revoked: {hb.reason}"
            AuditRepo.log(None, "license_revoked_by_server",
                          {"machine_id": mid, "reason": hb.reason})
            return st

        if hb.expired:
            st.is_active = False
            st.reason = "license has expired"
            return st

        st.days_remaining = hb.days_remaining
        st.is_lifetime = hb.is_lifetime
        return st

    # ---------------------------------------------------------------------
    # peek / pricing / revoke
    # ---------------------------------------------------------------------
    @staticmethod
    def peek(code: str) -> dict:
        return peek_token(code)

    @staticmethod
    def pricing() -> dict:
        """Server-fed pricing (preferred) with fallback to local TIERS."""
        try:
            return license_client.pricing()
        except LicenseServerError:
            from .tiers import TIERS
            from .blockchain import (PAYMENT_WALLET_ADDRESS,
                                    USDT_BEP20_CONTRACT, MIN_CONFIRMATIONS)
            return {
                "tiers": [{
                    "name": t.name, "price_usdt": t.price_usdt,
                    "duration_days": t.duration_days,
                    "discount_pct": t.discount_pct,
                    "description": t.description, "is_trial": t.is_trial,
                    "is_lifetime": t.duration_days is None,
                } for t in TIERS.values()],
                "payment": {
                    "network": "BSC (BEP20)", "token": "USDT",
                    "wallet": PAYMENT_WALLET_ADDRESS,
                    "usdt_contract": USDT_BEP20_CONTRACT,
                    "min_confirmations": MIN_CONFIRMATIONS,
                },
                "support_email": "dht.io.vn@gmail.com",
                "server_offline": True,
            }

    @staticmethod
    def revoke(license_id: int, reason: str = "manual") -> None:
        """Local revoke only — for syncing with server's revoke."""
        LicenseRepo.revoke(license_id, reason)
        AuditRepo.log(None, "license_revoked_local",
                     {"license_id": license_id, "reason": reason})
