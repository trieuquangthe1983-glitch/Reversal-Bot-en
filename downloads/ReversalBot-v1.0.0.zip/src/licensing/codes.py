"""Ed25519 license-token VERIFY-ONLY (client side).

This module replaces the previous HMAC implementation. The bot ships with
the seller's PUBLIC KEY embedded below — anyone can read it but nobody
can sign a new token without the private key (which stays on the
license server).

To customise for your deployment:
  1. On your laptop/server, run:
        python scripts/generate_master_keys.py   (in the license-server repo)
  2. Copy the contents of state/master_public.pem into PUBLIC_KEY_PEM below.
  3. Rebuild & ship the bot. The matching private key never leaves the
     license server.
"""
from __future__ import annotations
import base64
import json
import os
import time
from dataclasses import dataclass
from typing import Optional

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey


# =============================================================================
# EMBEDDED PUBLIC KEY
# =============================================================================
# REPLACE THIS BEFORE COMMERCIAL RELEASE. Run scripts/generate_master_keys.py
# in the license-server repo, then paste the contents of master_public.pem
# below. The default value here is a placeholder that will refuse to verify
# any real production token (it's a development-only key).
#
# An env var LICENSE_PUBLIC_KEY_PEM can override at runtime for testing.
# =============================================================================
PUBLIC_KEY_PEM = """\
-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEAaqzEB8J3TiMbOobc3bOlB46qQDHWAOfU7gISfHL9ZcE=
-----END PUBLIC KEY-----
"""


def _public_key() -> Ed25519PublicKey:
    """Resolve the public key — env var override takes precedence."""
    pem = os.getenv("LICENSE_PUBLIC_KEY_PEM") or PUBLIC_KEY_PEM
    return serialization.load_pem_public_key(pem.encode("utf-8"))


class LicenseCodeError(ValueError):
    """Raised on any verification failure."""


@dataclass
class DecodedToken:
    """A successfully verified license token."""
    tier: str
    machine_id: str
    issued_at: int
    expires_at: int       # 0 = lifetime
    license_id: int
    nonce: str
    raw_token: str

    @property
    def is_lifetime(self) -> bool:
        return self.expires_at == 0

    @property
    def is_expired(self) -> bool:
        return (not self.is_lifetime) and self.expires_at < int(time.time())

    def days_remaining(self) -> Optional[int]:
        if self.is_lifetime:
            return None
        return max(0, (self.expires_at - int(time.time())) // 86400)


# ---------------------------------------------------------------------------
# Encoding helpers (must match the server's crypto.py exactly)
# ---------------------------------------------------------------------------
def _b64u_decode(s: str) -> bytes:
    pad = (-len(s)) % 4
    return base64.urlsafe_b64decode(s + ("=" * pad))


def verify_token(token: str, expected_machine_id: str | None = None) -> DecodedToken:
    """Verify the server's Ed25519 signature on a license token.

    Args:
        token: the "payload.signature" string from the server
        expected_machine_id: if given, must match the token's bound machine

    Raises:
        LicenseCodeError on any signature/decode/binding failure
    """
    if "." not in token:
        raise LicenseCodeError("token missing signature separator '.'")
    payload_b64, sig_b64 = token.split(".", 1)
    try:
        payload_bytes = _b64u_decode(payload_b64)
        sig = _b64u_decode(sig_b64)
    except Exception as e:
        raise LicenseCodeError(f"base64 decode failed: {e}")

    pk = _public_key()
    try:
        pk.verify(sig, payload_bytes)
    except InvalidSignature:
        raise LicenseCodeError("invalid signature")

    try:
        d = json.loads(payload_bytes)
    except json.JSONDecodeError as e:
        raise LicenseCodeError(f"payload not JSON: {e}")

    if d.get("version") != 1:
        raise LicenseCodeError(f"unsupported token version: {d.get('version')}")
    for field in ("tier", "machine_id", "issued_at", "expires_at",
                  "license_id", "nonce"):
        if field not in d:
            raise LicenseCodeError(f"token missing field: {field}")

    decoded = DecodedToken(
        tier=d["tier"], machine_id=d["machine_id"],
        issued_at=d["issued_at"], expires_at=d["expires_at"],
        license_id=d["license_id"], nonce=d["nonce"],
        raw_token=token,
    )

    if decoded.is_expired:
        raise LicenseCodeError("license has expired")

    if expected_machine_id is not None:
        if decoded.machine_id.lower() != expected_machine_id[:24].lower():
            raise LicenseCodeError("license is bound to a different machine")

    return decoded


def peek_token(token: str) -> dict:
    """Decode payload WITHOUT verifying signature — for UI preview only."""
    try:
        payload_b64 = token.split(".", 1)[0]
        return json.loads(_b64u_decode(payload_b64))
    except Exception as e:
        return {"error": str(e)}


# ---------------------------------------------------------------------------
# Legacy aliases (kept for one minor version of backward compat)
# ---------------------------------------------------------------------------
verify_code = verify_token   # old name
peek_code = peek_token


def generate_code(*args, **kwargs):
    """Removed in v2: tokens are minted by the license server, not locally.

    Use src.licensing.client.verify_payment(...) which returns a
    server-signed token.
    """
    raise RuntimeError(
        "generate_code is no longer available client-side. "
        "Tokens are minted by the license server — call "
        "src.licensing.client.verify_payment() instead."
    )
