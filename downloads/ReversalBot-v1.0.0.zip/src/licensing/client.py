"""HTTP client for the license server.

The bot talks to the seller's license server for all sensitive operations:

    verify_payment(tx_hash, tier, machine_id)  -> token (signed by server)
    activate(token, machine_id)                -> license_status
    heartbeat(token)                           -> is_active + days_remaining
    pricing()                                  -> tier list (cached locally)

Configuration via env vars:
    LICENSE_SERVER_URL    default https://license.your-domain.com
    LICENSE_OFFLINE_GRACE_DAYS  default 7  -- if server unreachable, the
                                              bot keeps running for N days
                                              from last successful heartbeat
"""
from __future__ import annotations
import os
from dataclasses import dataclass
from typing import Optional

import requests


DEFAULT_SERVER_URL = os.getenv("LICENSE_SERVER_URL",
                               "https://reversal-bot-license.fly.dev")
DEFAULT_TIMEOUT = float(os.getenv("LICENSE_SERVER_TIMEOUT", "10"))


class LicenseServerError(RuntimeError):
    """Raised when the server returns an error or is unreachable."""
    def __init__(self, message: str, status_code: int | None = None,
                 reachable: bool = True):
        super().__init__(message)
        self.status_code = status_code
        self.reachable = reachable    # False if we couldn't connect at all


@dataclass
class ServerVerifyResult:
    token: str
    license_id: int
    tier: str
    machine_id: str
    expires_at: Optional[str]
    amount_usdt: float
    confirmations: int


@dataclass
class ServerActivateResult:
    license_id: int
    tier: str
    is_lifetime: bool
    expires_at: Optional[str]
    days_remaining: Optional[int]
    machine_id: str


@dataclass
class ServerHeartbeatResult:
    is_active: bool
    revoked: bool
    expired: bool
    tier: Optional[str]
    is_lifetime: bool
    expires_at: Optional[str]
    days_remaining: Optional[int]
    reason: Optional[str]


def _post(path: str, payload: dict, url: str | None = None,
          timeout: float | None = None) -> dict:
    base = url or DEFAULT_SERVER_URL
    full = base.rstrip("/") + path
    try:
        r = requests.post(full, json=payload,
                          timeout=timeout or DEFAULT_TIMEOUT)
    except requests.RequestException as e:
        raise LicenseServerError(f"cannot reach license server: {e}",
                                 reachable=False)
    if r.status_code >= 500:
        raise LicenseServerError(
            f"license server error ({r.status_code}): {r.text[:200]}",
            status_code=r.status_code)
    try:
        body = r.json()
    except Exception:
        raise LicenseServerError(
            f"license server returned non-JSON ({r.status_code})",
            status_code=r.status_code)
    if r.status_code >= 400:
        raise LicenseServerError(body.get("detail", "server rejected request"),
                                 status_code=r.status_code)
    return body


def _get(path: str, url: str | None = None,
         timeout: float | None = None) -> dict:
    base = url or DEFAULT_SERVER_URL
    full = base.rstrip("/") + path
    try:
        r = requests.get(full, timeout=timeout or DEFAULT_TIMEOUT)
    except requests.RequestException as e:
        raise LicenseServerError(f"cannot reach license server: {e}",
                                 reachable=False)
    if r.status_code >= 400:
        raise LicenseServerError(f"GET {path} -> {r.status_code}",
                                 status_code=r.status_code)
    return r.json()


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------
def pricing(server_url: str | None = None) -> dict:
    """Public tier info + payment wallet. No auth required."""
    return _get("/pricing", url=server_url)


def server_public_key(server_url: str | None = None) -> str:
    return _get("/public-key", url=server_url)["public_key_pem"]


def verify_payment(tx_hash: str, tier: str, machine_id: str,
                   network: str = "bsc",
                   customer_email: str | None = None,
                   server_url: str | None = None) -> ServerVerifyResult:
    j = _post("/verify-payment", {
        "tx_hash": tx_hash, "tier": tier, "machine_id": machine_id,
        "network": network,
        "customer_email": customer_email,
    }, url=server_url)
    return ServerVerifyResult(
        token=j["token"], license_id=j["license_id"], tier=j["tier"],
        machine_id=j["machine_id"], expires_at=j.get("expires_at"),
        amount_usdt=j["payment"]["amount_usdt"],
        confirmations=j["payment"]["confirmations"],
    )


def activate(token: str, machine_id: str,
             server_url: str | None = None) -> ServerActivateResult:
    j = _post("/activate", {"token": token, "machine_id": machine_id},
              url=server_url)
    return ServerActivateResult(
        license_id=j["license_id"], tier=j["tier"],
        is_lifetime=j["is_lifetime"], expires_at=j.get("expires_at"),
        days_remaining=j.get("days_remaining"),
        machine_id=j["machine_id"],
    )


def heartbeat(token: str,
              server_url: str | None = None) -> ServerHeartbeatResult:
    j = _post("/heartbeat", {"token": token}, url=server_url)
    return ServerHeartbeatResult(
        is_active=bool(j.get("is_active")),
        revoked=bool(j.get("revoked", False)),
        expired=bool(j.get("expired", False)),
        tier=j.get("tier"),
        is_lifetime=bool(j.get("is_lifetime", False)),
        expires_at=j.get("expires_at"),
        days_remaining=j.get("days_remaining"),
        reason=j.get("reason"),
    )
