"""Machine fingerprint: stable per-machine ID for license binding.

Why this hash?
  We need an ID that is:
    * Stable across reboots (so re-activation isn't required every time)
    * Distinct across machines (so codes can't be shared)
    * Not require admin rights to compute (CPU serial would, MAC doesn't)

We hash: lower(MAC of first non-loopback iface) | platform.node() | platform.machine()
Then sha256 -> truncated 24 chars.

Caveats (we tell the customer up front):
  * Reformatting the OS may change platform.node() -> need a license reset
  * Replacing the NIC will change the MAC -> need a license reset
  * VMs that randomize MAC at each boot will get bumped -> not supported
"""
from __future__ import annotations
import hashlib
import platform
import uuid


def _primary_mac() -> str:
    """Return the MAC address of any interface as 12 lowercase hex chars.

    uuid.getnode() returns 48 random bits if it can't find a stable MAC,
    so we test it: if the multicast bit is set, the value is synthetic and
    we fall back to the machine node name instead.
    """
    node = uuid.getnode()
    # Bit 40 (0x010000000000) set means uuid synthesized a random MAC.
    if node & (1 << 40):
        return "synthetic"
    return f"{node:012x}"


def machine_id() -> str:
    """Stable 24-character machine identifier (hex)."""
    parts = [
        _primary_mac(),
        platform.node().lower(),
        platform.machine().lower(),
    ]
    blob = "|".join(parts).encode("utf-8")
    return hashlib.sha256(blob).hexdigest()[:24]


def machine_fingerprint_blob() -> dict:
    """Human-readable breakdown — shown in the activation UI so users can
    verify (and email support if they need a transfer)."""
    return {
        "machine_id": machine_id(),
        "mac_hash": hashlib.sha256(_primary_mac().encode()).hexdigest()[:8],
        "node": platform.node(),
        "system": platform.system(),
        "release": platform.release(),
        "machine": platform.machine(),
        "python": platform.python_version(),
    }
