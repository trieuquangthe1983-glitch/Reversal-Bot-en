"""License tier definitions: price (USDT-BEP20) + duration.

Pricing math
------------
Base monthly: 39 USDT
- Quarterly: 39 * 3 * 0.95 = 111.15 -> rounded to 111
- Annual:    39 * 12 * 0.85 = 397.80 -> rounded to 397

Trial is intentionally NON-recurring: 29 USDT / 30 days, one-shot per
machine to discourage abuse. Lifetime = 569 USDT, ~14.6 months breakeven
vs monthly which is aggressive and converts well.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Literal

TierName = Literal["trial", "monthly", "quarterly", "annual", "lifetime"]


@dataclass(frozen=True)
class Tier:
    name: TierName
    price_usdt: float           # Exact amount expected on BEP20 USDT transfer
    duration_days: int | None   # None = unlimited (lifetime)
    discount_pct: float         # For display only
    description: str
    base_label: str             # UI label
    is_trial: bool = False

    @property
    def display_price(self) -> str:
        return f"{int(self.price_usdt) if self.price_usdt == int(self.price_usdt) else self.price_usdt} USDT"

    @property
    def per_month_equiv(self) -> float | None:
        """Equivalent monthly cost — useful for "save $X/month" UI hints."""
        if self.duration_days is None:
            return None
        months = self.duration_days / 30.0
        return round(self.price_usdt / months, 2) if months > 0 else None


TIERS: dict[TierName, Tier] = {
    "trial": Tier(
        name="trial",
        price_usdt=29.0,
        duration_days=30,
        discount_pct=0.0,
        base_label="Trial",
        description="30-day trial. One-shot per machine. All features unlocked.",
        is_trial=True,
    ),
    "monthly": Tier(
        name="monthly",
        price_usdt=39.0,
        duration_days=30,
        discount_pct=0.0,
        base_label="Monthly",
        description="Pay-as-you-go, cancel anytime by simply not renewing.",
    ),
    "quarterly": Tier(
        name="quarterly",
        price_usdt=111.0,    # 39*3*0.95 = 111.15
        duration_days=90,
        discount_pct=5.0,
        base_label="Quarterly",
        description="3 months, 5% off vs monthly.",
    ),
    "annual": Tier(
        name="annual",
        price_usdt=397.0,    # 39*12*0.85 = 397.80
        duration_days=365,
        discount_pct=15.0,
        base_label="Annual",
        description="12 months, 15% off vs monthly. Best value before lifetime.",
    ),
    "lifetime": Tier(
        name="lifetime",
        price_usdt=569.0,
        duration_days=None,
        discount_pct=0.0,
        base_label="Lifetime",
        description="One-time payment, all future updates included.",
    ),
}


def tier_info(name: TierName) -> Tier:
    if name not in TIERS:
        raise ValueError(f"unknown tier: {name}")
    return TIERS[name]


def match_tier_by_amount(amount_usdt: float, tolerance: float = 0.05) -> Tier | None:
    """Given a payment amount, return the closest matching tier.

    Tight tolerance (5 cents): buyers cover network fees in the native
    token (BNB on BSC, TRX on Tron), so the USDT transferred should equal
    the tier price exactly.
    """
    for t in TIERS.values():
        if abs(amount_usdt - t.price_usdt) <= tolerance:
            return t
    return None
