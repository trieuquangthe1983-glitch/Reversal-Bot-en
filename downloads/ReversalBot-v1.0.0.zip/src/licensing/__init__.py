"""License management subsystem.

Modules
-------
tiers        Pricing + duration definitions for all license tiers.
fingerprint  Machine ID (stable hash of MAC + platform).
codes        HMAC-signed activation codes encoding (tier, expiry, machine_id).
blockchain   BSC BEP20 USDT payment verification (public RPC, no API key).
manager      DB-backed orchestration: verify_payment -> issue_code -> activate.

Security model
--------------
* Self-contained: bot has a HMAC signing key. Codes are verified locally.
  This is first-line defense (good enough for $29-$569 product).
* Hybrid: when LICENSE_SERVER_URL env var is set, the bot ALSO calls the
  server to corroborate activation. This catches code-sharing across users
  even if the local secret leaks.
* Machine binding: 1 license = 1 machine. Each activation hashes (MAC +
  platform) and stores it in the license row. Re-activation on a new
  machine requires emailing support (dht.io.vn@gmail.com) for a reset.
* Anti-fraud: rate-limited activation attempts, tx_hash uniqueness, audit
  log, hard expiry check at every bot scan loop.
"""
from .tiers import TIERS, TierName, tier_info
from .fingerprint import machine_id, machine_fingerprint_blob
from .codes import verify_token, peek_token, LicenseCodeError
from .blockchain import PaymentVerifyError       # kept for back-compat
from .client import LicenseServerError
from .manager import LicenseManager, LicenseStatus

__all__ = [
    "TIERS", "TierName", "tier_info",
    "machine_id", "machine_fingerprint_blob",
    "verify_token", "peek_token", "LicenseCodeError",
    "PaymentVerifyError", "LicenseServerError",
    "LicenseManager", "LicenseStatus",
]
