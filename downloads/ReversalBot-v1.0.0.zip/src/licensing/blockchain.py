"""BSC (BNB Smart Chain) BEP20 USDT payment verification.

Strategy
--------
We use the public BSC RPC (no API key, free) to look up a transaction by
hash and decode its USDT BEP20 transfer event. No external library
required — just stdlib + requests.

To verify a payment:
  1. Caller submits a tx_hash (and which tier they paid for).
  2. We fetch the tx receipt from BSC.
  3. We parse the `Transfer(address,address,uint256)` log emitted by the
     USDT BEP20 contract.
  4. We assert:
        - the To address == our wallet
        - the contract address == USDT BEP20 contract
        - the amount (decimals=18 for USDT-BEP20) matches the tier price
        - the tx has >= MIN_CONFIRMATIONS block confirmations
  5. Done — caller can now mint an activation code.

Failure modes we explicitly handle:
  * RPC down -> retry once, then raise PaymentVerifyError("rpc unavailable")
  * tx still pending -> raise PaymentVerifyError("not enough confirmations")
  * to address mismatch / token mismatch -> raise with detail
  * amount mismatch -> raise with detail (we are intentionally tight here)
"""
from __future__ import annotations
import json
import os
import time
from dataclasses import dataclass
from typing import Optional

import requests

from .tiers import Tier, TIERS, match_tier_by_amount


# Tether USD on BSC (BEP20). Verified at:
# https://bscscan.com/token/0x55d398326f99059ff775485246999027b3197955
USDT_BEP20_CONTRACT = "0x55d398326f99059fF775485246999027B3197955".lower()

# USDT-BEP20 uses 18 decimals (note: ETH USDT uses 6, but BSC version uses 18).
USDT_DECIMALS = 18

# keccak256("Transfer(address,address,uint256)") = ddf252ad...
TRANSFER_EVENT_TOPIC = "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef"

# Our payment wallet (configurable for dev, hard default in prod)
PAYMENT_WALLET_ADDRESS = os.getenv(
    "LICENSE_PAYMENT_WALLET",
    "0xFdE5bE00bA5db63a93abf7922ee831dB62257550",
).lower()

# Public BSC RPC endpoints (round-robin if one fails)
DEFAULT_RPCS = [
    "https://bsc-dataseed.binance.org/",
    "https://bsc-dataseed1.defibit.io/",
    "https://bsc-dataseed1.ninicoin.io/",
]

MIN_CONFIRMATIONS = 12   # ~36 seconds on BSC (3s block time)


class PaymentVerifyError(RuntimeError):
    """Raised on any blockchain verification failure."""


@dataclass
class PaymentProof:
    tx_hash: str
    from_address: str
    to_address: str
    amount_usdt: float
    block_number: int
    confirmations: int
    matched_tier: Optional[str]   # tier name or None if amount didn't match
    raw_receipt: dict             # for audit log


def _rpc_call(method: str, params: list, rpcs: list[str] | None = None,
              timeout: float = 8.0) -> dict:
    """Call the JSON-RPC endpoint. Tries each RPC in order until one works."""
    rpcs = rpcs or DEFAULT_RPCS
    last_err: Exception | None = None
    for url in rpcs:
        try:
            r = requests.post(url, timeout=timeout, json={
                "jsonrpc": "2.0", "id": 1, "method": method, "params": params,
            })
            if r.status_code != 200:
                last_err = RuntimeError(f"{url} returned {r.status_code}")
                continue
            j = r.json()
            if "error" in j:
                last_err = RuntimeError(f"{url} rpc error: {j['error']}")
                continue
            return j["result"]
        except (requests.RequestException, json.JSONDecodeError) as e:
            last_err = e
            continue
    raise PaymentVerifyError(f"all BSC RPCs failed: {last_err}")


def _hex_to_int(s: str) -> int:
    if not s or s == "0x":
        return 0
    return int(s, 16)


def _addr_pad(addr: str) -> str:
    """Right-pad addresses to compare with topic-encoded ones."""
    a = addr.lower().replace("0x", "")
    return "0x" + a.rjust(64, "0")


def fetch_transaction_proof(tx_hash: str,
                            rpcs: list[str] | None = None,
                            now_block: Optional[int] = None) -> PaymentProof:
    """Fetch + parse a BSC transaction. Raises PaymentVerifyError on any
    integrity problem. Does NOT enforce tier-price matching — that's the
    caller's job (so they can show "we received X USDT" if the amount
    didn't quite match).
    """
    if not tx_hash.startswith("0x") or len(tx_hash) != 66:
        raise PaymentVerifyError(f"invalid tx_hash format: {tx_hash!r}")

    receipt = _rpc_call("eth_getTransactionReceipt", [tx_hash], rpcs=rpcs)
    if receipt is None:
        raise PaymentVerifyError(
            "transaction not found on BSC (still pending? double-check the hash)")
    if _hex_to_int(receipt.get("status", "0x0")) != 1:
        raise PaymentVerifyError("transaction failed on-chain (status=0)")

    # Confirmations
    block_no = _hex_to_int(receipt["blockNumber"])
    if now_block is None:
        now_block = _hex_to_int(_rpc_call("eth_blockNumber", [], rpcs=rpcs))
    confirmations = max(0, now_block - block_no)
    if confirmations < MIN_CONFIRMATIONS:
        raise PaymentVerifyError(
            f"only {confirmations} confirmations (need {MIN_CONFIRMATIONS}). "
            f"Try again in ~{(MIN_CONFIRMATIONS - confirmations) * 3} seconds.")

    # Find the USDT BEP20 Transfer log to our wallet
    our_wallet_padded = _addr_pad(PAYMENT_WALLET_ADDRESS)
    transfer_log = None
    for log in receipt.get("logs", []):
        if log["address"].lower() != USDT_BEP20_CONTRACT:
            continue
        topics = log.get("topics", [])
        if not topics or topics[0].lower() != TRANSFER_EVENT_TOPIC:
            continue
        if len(topics) < 3:
            continue
        # topics[1] = from (padded), topics[2] = to (padded)
        if topics[2].lower() != our_wallet_padded:
            continue
        transfer_log = log
        break

    if transfer_log is None:
        raise PaymentVerifyError(
            f"no USDT-BEP20 transfer to {PAYMENT_WALLET_ADDRESS} in this tx. "
            f"Did you send USDT (not BNB) and to the correct address?")

    raw_amount = _hex_to_int(transfer_log["data"])
    amount_usdt = raw_amount / (10 ** USDT_DECIMALS)
    from_addr = "0x" + transfer_log["topics"][1][-40:].lower()
    to_addr = "0x" + transfer_log["topics"][2][-40:].lower()

    matched = match_tier_by_amount(amount_usdt)
    matched_name = matched.name if matched else None

    return PaymentProof(
        tx_hash=tx_hash,
        from_address=from_addr,
        to_address=to_addr,
        amount_usdt=round(amount_usdt, 6),
        block_number=block_no,
        confirmations=confirmations,
        matched_tier=matched_name,
        raw_receipt=receipt,
    )


def verify_bsc_payment(tx_hash: str, expected_tier: Optional[str] = None,
                      rpcs: list[str] | None = None) -> PaymentProof:
    """High-level verifier. If `expected_tier` is given, the amount MUST
    match that tier's price; else we accept any tier match.

    Returns the PaymentProof on success. Raises PaymentVerifyError on
    every failure mode.
    """
    proof = fetch_transaction_proof(tx_hash, rpcs=rpcs)

    if proof.matched_tier is None:
        nearest = min(
            TIERS.values(),
            key=lambda t: abs(t.price_usdt - proof.amount_usdt),
        )
        raise PaymentVerifyError(
            f"amount {proof.amount_usdt} USDT does not match any tier. "
            f"Closest is {nearest.name} at {nearest.price_usdt} USDT. "
            f"If you sent the right amount, contact dht.io.vn@gmail.com.")

    if expected_tier and proof.matched_tier != expected_tier:
        raise PaymentVerifyError(
            f"you requested {expected_tier} ({TIERS[expected_tier].price_usdt} USDT) "
            f"but the transaction sent {proof.amount_usdt} USDT which matches "
            f"the {proof.matched_tier} tier. Activate that tier instead, or "
            f"email support to top up.")

    return proof
