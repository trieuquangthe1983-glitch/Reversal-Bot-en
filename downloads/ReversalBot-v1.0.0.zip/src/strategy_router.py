"""Strategy router.

Runs the reversal and LTR detectors against the same market data, then
decides what (if anything) to trade. Rules:

  1. Each symbol gets AT MOST one position. If both strategies fire on the
     same symbol+side, they MERGE into a 'confluence' setup (tighter SL,
     wider TP, larger size).
  2. If they fire on OPPOSITE sides — ignore both. The market is too
     ambiguous; let it cool off (the symbol-level cooldown will gate this).
  3. If only one fires — trade it standalone.

The router does NOT touch the exchange. It produces `TradeSetup` objects
the bot loop owns the execution of.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Optional

import pandas as pd

from .pattern_detector import check_current_day, ReversalPattern
from .ltr_detector import check_ltr, LTRPattern
from .playbook import (TradeSetup, build_setup, build_ltr_setup,
                       combine_setups)
from .context import build_context, ContextFeatures, cvd_divergence_score
from .regime import Regime
from .utils import setup_logger

log = setup_logger("router")


@dataclass
class RoutedSetup:
    setup: TradeSetup
    context: ContextFeatures
    # raw patterns kept for DB recording
    reversal_pattern: Optional[ReversalPattern] = None
    ltr_pattern: Optional[LTRPattern] = None


@dataclass
class MarketBundle:
    """Per-symbol data delivered to the router. The bot loop assembles this.

    All fields are optional — router degrades gracefully when data is missing,
    but LTR will refuse to fire without funding/OI/CVD.
    """
    symbol: str
    today_intraday_df: pd.DataFrame                     # for reversal detector
    htf_df: Optional[pd.DataFrame] = None               # 4h, for LTR swings
    ltf_df: Optional[pd.DataFrame] = None               # 1h or 15m, for LTR rejection
    funding_now: Optional[float] = None
    funding_history: Optional[pd.DataFrame] = None
    oi_history: Optional[pd.DataFrame] = None
    cvd_df: Optional[pd.DataFrame] = None
    regime: Optional[Regime] = None


class StrategyRouter:

    def __init__(self, cfg: dict):
        self.cfg = cfg
        self._reversal_cfg = cfg.get("pattern", {})
        self._ltr_cfg = cfg.get("ltr", {}) or {}
        self._bt_cfg = cfg.get("backtest", {})

    # -- public ---------------------------------------------------------
    def route(self, bundle: MarketBundle) -> Optional[RoutedSetup]:
        rev_pat = self._try_reversal(bundle)
        ltr_pat = self._try_ltr(bundle)

        if rev_pat and ltr_pat:
            if rev_pat.side != ltr_pat.side:
                log.info("%s: reversal & LTR conflict (rev=%s ltr=%s) -> skip",
                         bundle.symbol, rev_pat.side, ltr_pat.side)
                return None
            return self._build_confluence(bundle, rev_pat, ltr_pat)
        elif rev_pat:
            return self._build_reversal(bundle, rev_pat)
        elif ltr_pat:
            return self._build_ltr(bundle, ltr_pat)
        return None

    # -- detectors ------------------------------------------------------
    def _try_reversal(self, bundle: MarketBundle) -> Optional[ReversalPattern]:
        if bundle.today_intraday_df is None or len(bundle.today_intraday_df) < 2:
            return None
        return check_current_day(
            bundle.today_intraday_df,
            symbol=bundle.symbol,
            initial_move_pct=self._reversal_cfg.get("initial_move_pct", 1.05),
            reversal_min_pct=self._reversal_cfg.get("reversal_min_pct", 1.20),
            reversal_max_pct=self._reversal_cfg.get("reversal_max_pct", 6.50),
        )

    def _try_ltr(self, bundle: MarketBundle) -> Optional[LTRPattern]:
        if not self._ltr_cfg.get("enabled", True):
            return None
        if bundle.htf_df is None or bundle.ltf_df is None:
            return None
        # LTR demands at least funding & OI. CVD is degradable to 0.
        if bundle.funding_history is None or bundle.oi_history is None:
            return None

        from .context import funding_zscore, oi_change_pct
        fz, _ = funding_zscore(bundle.funding_history, bundle.funding_now)
        oi_chg = oi_change_pct(bundle.oi_history,
                               bars=self._ltr_cfg.get("oi_lookback_bars", 6))

        cvd_short = cvd_divergence_score(bundle.cvd_df, "SHORT") if bundle.cvd_df is not None else 0.0
        cvd_long = cvd_divergence_score(bundle.cvd_df, "LONG") if bundle.cvd_df is not None else 0.0

        return check_ltr(
            symbol=bundle.symbol,
            htf_df=bundle.htf_df,
            ltf_df=bundle.ltf_df,
            funding_rate=bundle.funding_now,
            funding_zscore=fz,
            oi_change_pct=oi_chg,
            cvd_score_short=cvd_short,
            cvd_score_long=cvd_long,
            htf_lookback=self._ltr_cfg.get("htf_lookback_bars", 30),
            pivot_window=self._ltr_cfg.get("pivot_window", 3),
            min_wick_ratio=self._ltr_cfg.get("min_wick_ratio", 0.5),
            min_confluence=self._ltr_cfg.get("min_confluence", 0.45),
            retrace_to_entry=self._ltr_cfg.get("retrace_to_entry", 0.50),
            sweep_recency_bars=self._ltr_cfg.get("sweep_recency_bars", 5),
        )

    # -- builders -------------------------------------------------------
    def _build_reversal(self, bundle: MarketBundle, pat: ReversalPattern) -> RoutedSetup:
        setup = build_setup(
            pat,
            sl_buffer_pct=self._bt_cfg.get("sl_buffer_pct", 0.30),
            tp_r_multiples=tuple(self._bt_cfg.get("tp_r_multiples", [1.0, 2.0, 3.0])),
        )
        ctx = self._context_for(bundle, setup)
        return RoutedSetup(setup=setup, context=ctx, reversal_pattern=pat)

    def _build_ltr(self, bundle: MarketBundle, pat: LTRPattern) -> RoutedSetup:
        setup = build_ltr_setup(
            pat,
            sl_buffer_pct=self._ltr_cfg.get("sl_buffer_pct", 0.15),
            tp_r_multiples=tuple(self._ltr_cfg.get("tp_r_multiples", [1.5, 3.0, 5.0])),
        )
        ctx = self._context_for(bundle, setup)
        return RoutedSetup(setup=setup, context=ctx, ltr_pattern=pat)

    def _build_confluence(self, bundle: MarketBundle,
                          rev_pat: ReversalPattern, ltr_pat: LTRPattern) -> RoutedSetup:
        rev_setup = build_setup(
            rev_pat,
            sl_buffer_pct=self._bt_cfg.get("sl_buffer_pct", 0.30),
            tp_r_multiples=tuple(self._bt_cfg.get("tp_r_multiples", [1.0, 2.0, 3.0])),
        )
        ltr_setup = build_ltr_setup(
            ltr_pat,
            sl_buffer_pct=self._ltr_cfg.get("sl_buffer_pct", 0.15),
            tp_r_multiples=tuple(self._ltr_cfg.get("tp_r_multiples", [1.5, 3.0, 5.0])),
        )
        merged = combine_setups(rev_setup, ltr_setup)
        ctx = self._context_for(bundle, merged)
        log.info("%s: CONFLUENCE %s rev_init=%.2f%% ltr_conf=%.2f",
                 bundle.symbol, merged.side, rev_setup.initial_move_pct,
                 ltr_pat.confluence_score)
        return RoutedSetup(setup=merged, context=ctx,
                           reversal_pattern=rev_pat, ltr_pattern=ltr_pat)

    # -- context --------------------------------------------------------
    def _context_for(self, bundle: MarketBundle, setup: TradeSetup) -> ContextFeatures:
        return build_context(
            side=setup.side,
            init_pct=setup.initial_move_pct,
            rev_pct=setup.reversal_pct,
            sl_distance_pct=setup.risk_pct,
            intraday_df=bundle.today_intraday_df,
            regime=bundle.regime,
            funding_now=bundle.funding_now,
            funding_history=bundle.funding_history,
            oi_history=bundle.oi_history,
            cvd_df=bundle.cvd_df,
        )
