"""Macro regime classifier.

Classifies the current BTC environment along two axes:
  - trend:       up | down | chop   (20D vs 50D SMA + slope)
  - volatility:  low | mid | high   (20D realized vol vs its 365D percentile)

The combined label (e.g. "up_low", "chop_high") is what the learner uses as
a context bucket; the numeric signals (trend_signal in {-1, 0, +1} and
vol_zscore) feed the logistic-regression contextual bandit.

Why BTC, not per-symbol?
------------------------
Crypto correlations spike during stress. The dominant regime is set by BTC.
Trading SOL as if it were in its own regime when BTC just broke down is how
LONG setups die. Keep the regime *macro*, let per-symbol structure live in
the detector layer.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Optional

import numpy as np
import pandas as pd


TREND_LABELS = ("down", "chop", "up")
VOL_LABELS = ("low", "mid", "high")


@dataclass
class Regime:
    trend: str                # "up" | "down" | "chop"
    volatility: str           # "low" | "mid" | "high"
    trend_signal: int         # -1, 0, +1
    vol_zscore: float         # current 20D vol z-score vs 365D rolling
    label: str                # e.g. "up_low"  (used as bucket key)

    def to_dict(self) -> dict:
        return {
            "trend": self.trend, "volatility": self.volatility,
            "trend_signal": self.trend_signal,
            "vol_zscore": round(self.vol_zscore, 3),
            "label": self.label,
        }


def _realized_vol(close: pd.Series, window: int) -> pd.Series:
    """Annualized realized vol from daily log returns."""
    logret = np.log(close / close.shift(1))
    return logret.rolling(window).std() * np.sqrt(365.0)


def classify(btc_daily: pd.DataFrame,
             sma_fast: int = 20,
             sma_slow: int = 50,
             slope_lookback: int = 5,
             vol_window: int = 20,
             vol_lookback: int = 365,
             chop_threshold_pct: float = 1.0) -> Optional[Regime]:
    """Classify the regime as of the last bar in `btc_daily`.

    `btc_daily` must be a DataFrame with at least a 'close' column, indexed
    chronologically. Returns None if there isn't enough history.
    """
    if btc_daily is None or btc_daily.empty:
        return None
    close = btc_daily["close"]
    if len(close) < max(sma_slow, vol_window) + slope_lookback + 1:
        return None

    fast = close.rolling(sma_fast).mean()
    slow = close.rolling(sma_slow).mean()
    last_fast = fast.iloc[-1]
    last_slow = slow.iloc[-1]
    last_close = close.iloc[-1]

    # Trend: fast vs slow + slope of fast
    spread_pct = (last_fast - last_slow) / last_slow * 100.0
    slope = (fast.iloc[-1] - fast.iloc[-1 - slope_lookback]) / fast.iloc[-1 - slope_lookback] * 100.0

    if spread_pct > chop_threshold_pct and slope > 0:
        trend = "up"
        trend_signal = 1
    elif spread_pct < -chop_threshold_pct and slope < 0:
        trend = "down"
        trend_signal = -1
    else:
        trend = "chop"
        trend_signal = 0

    # Volatility: current 20D vs distribution of last 365D windows
    rv = _realized_vol(close, vol_window)
    rv_now = float(rv.iloc[-1]) if not np.isnan(rv.iloc[-1]) else 0.0
    hist = rv.iloc[-(vol_lookback + 1):-1].dropna()
    if len(hist) < 30:
        vol = "mid"
        vol_z = 0.0
    else:
        mu, sd = float(hist.mean()), float(hist.std() or 1e-9)
        vol_z = (rv_now - mu) / sd
        if vol_z < -0.5:
            vol = "low"
        elif vol_z > 0.5:
            vol = "high"
        else:
            vol = "mid"

    return Regime(
        trend=trend, volatility=vol,
        trend_signal=trend_signal, vol_zscore=vol_z,
        label=f"{trend}_{vol}",
    )


def confluence_with_setup_side(regime: Regime, side: str) -> float:
    """How well does the regime favor this side?
       up + LONG  -> +1   (with the trend)
       up + SHORT -> -1   (counter-trend, harder)
       chop + anything -> 0  (neutral; mean-reversion shines here)
    Returns a [-1, +1] signal used as a feature for the learner.
    """
    if regime is None:
        return 0.0
    if regime.trend == "chop":
        return 0.0
    if regime.trend == "up":
        return 1.0 if side == "LONG" else -1.0
    return 1.0 if side == "SHORT" else -1.0
