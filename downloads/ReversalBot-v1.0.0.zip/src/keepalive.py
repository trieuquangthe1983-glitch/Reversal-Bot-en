"""Prevent Windows from sleeping while the bot is running.

Uses the Win32 API `SetThreadExecutionState` — same mechanism that video
players, downloads, and games use to keep the machine awake.

Usage:
    from src.keepalive import prevent_sleep, allow_sleep
    prevent_sleep()           # call once at startup
    try:
        run_bot()
    finally:
        allow_sleep()         # revert when stopping

Notes
-----
- Linux/Mac: no-op (no equivalent universal API; cron+inhibit on Linux).
- Windows: only prevents *system* sleep, NOT *display* sleep (the screen
  can still turn off, which is fine).
- The flag is per-thread. As long as the main thread of the bot stays
  alive, sleep is prevented. When the process exits, Windows automatically
  reverts (no leaked state).
- This does NOT override an explicit user "Sleep" from the Start menu —
  the user can still force sleep manually. It only prevents *idle* sleep.
- Also does NOT survive a forced shutdown or hibernate. Use the NSSM
  service approach (scripts/install_service.ps1) for survival across
  reboots / logout.
"""
from __future__ import annotations
import ctypes
import sys
import threading

# Windows SetThreadExecutionState flags
ES_CONTINUOUS         = 0x80000000
ES_SYSTEM_REQUIRED    = 0x00000001
ES_AWAYMODE_REQUIRED  = 0x00000040
ES_DISPLAY_REQUIRED   = 0x00000002


_state_lock = threading.Lock()
_is_active = False


def is_windows() -> bool:
    return sys.platform == "win32"


def prevent_sleep(keep_display_on: bool = False) -> bool:
    """Tell the OS to keep the system awake.

    Returns True if the call succeeded (or no-op on non-Windows).
    Idempotent — safe to call multiple times.
    """
    global _is_active
    if not is_windows():
        return True  # no-op
    with _state_lock:
        flags = ES_CONTINUOUS | ES_SYSTEM_REQUIRED | ES_AWAYMODE_REQUIRED
        if keep_display_on:
            flags |= ES_DISPLAY_REQUIRED
        prev = ctypes.windll.kernel32.SetThreadExecutionState(flags)
        ok = prev != 0
        _is_active = ok
        return ok


def allow_sleep() -> bool:
    """Revert: let the OS sleep normally again."""
    global _is_active
    if not is_windows():
        return True
    with _state_lock:
        prev = ctypes.windll.kernel32.SetThreadExecutionState(ES_CONTINUOUS)
        _is_active = False
        return prev != 0


def is_active() -> bool:
    return _is_active


def report_status() -> str:
    """Human-readable one-liner for logs."""
    if not is_windows():
        return "keepalive: skipped (not Windows)"
    if _is_active:
        return "keepalive: ACTIVE — system sleep prevented while bot runs"
    return "keepalive: inactive"


# Context manager for short-lived scoped use
class KeepAwake:
    """`with KeepAwake(): ...` — auto revert on exit."""
    def __init__(self, keep_display_on: bool = False):
        self.keep_display_on = keep_display_on

    def __enter__(self):
        prevent_sleep(self.keep_display_on)
        return self

    def __exit__(self, exc_type, exc, tb):
        allow_sleep()
        return False
