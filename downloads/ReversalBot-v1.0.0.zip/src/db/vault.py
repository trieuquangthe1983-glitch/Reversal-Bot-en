"""Vault: encrypt/decrypt API credentials.

Design
------
For each user we store:
  - vault_salt:  16 random bytes (in users table)
  - vault_check: Fernet-encrypted constant string (used to verify the password
                 is correct before we let the bot pull keys)

To use the vault, the user provides the *vault password*. From it we derive:
    key = PBKDF2-HMAC-SHA256(password, salt, iterations=310_000, length=32)

The key is wrapped into a Fernet object. The Fernet object lives in memory only.

API credentials are stored as JSON {"api_key", "secret", "passphrase"} encrypted
with that Fernet token. On every access we decrypt in memory and return a dict.

We NEVER write the decrypted credentials back to disk.

If you forget the vault password: there is NO recovery. By design.
"""
from __future__ import annotations
import base64
import json
import os
from dataclasses import dataclass

from cryptography.fernet import Fernet, InvalidToken
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

PBKDF2_ITERATIONS = 310_000          # OWASP 2023 minimum
VAULT_CHECK_PLAINTEXT = b"reversal-bot::vault-check::v1"


def new_salt() -> bytes:
    return os.urandom(16)


def derive_key(password: str, salt: bytes) -> bytes:
    """PBKDF2 -> 32-byte key suitable for Fernet."""
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=PBKDF2_ITERATIONS,
    )
    raw = kdf.derive(password.encode("utf-8"))
    return base64.urlsafe_b64encode(raw)


@dataclass
class VaultSession:
    """In-memory holder of a derived Fernet key for the session.

    NEVER persist this. Treat the .fernet attribute as a secret.
    """
    user_id: int
    fernet: Fernet

    @classmethod
    def unlock(cls, user_id: int, password: str, salt: bytes,
              check_blob: bytes) -> "VaultSession":
        """Try to unlock. Raises ValueError if password is wrong."""
        key = derive_key(password, salt)
        f = Fernet(key)
        try:
            decrypted = f.decrypt(check_blob)
        except InvalidToken as e:
            raise ValueError("wrong vault password") from e
        if decrypted != VAULT_CHECK_PLAINTEXT:
            raise ValueError("vault check mismatch")
        return cls(user_id=user_id, fernet=f)

    def encrypt_credentials(self, creds: dict) -> bytes:
        """Encrypt a credentials dict (api_key, secret, passphrase, ...)."""
        payload = json.dumps(creds, separators=(",", ":")).encode("utf-8")
        return self.fernet.encrypt(payload)

    def decrypt_credentials(self, blob: bytes) -> dict:
        try:
            payload = self.fernet.decrypt(blob)
        except InvalidToken as e:
            raise ValueError("could not decrypt credentials") from e
        return json.loads(payload.decode("utf-8"))


def create_vault_check_blob(password: str, salt: bytes) -> bytes:
    """Generate the encrypted check value for a NEW user."""
    key = derive_key(password, salt)
    f = Fernet(key)
    return f.encrypt(VAULT_CHECK_PLAINTEXT)


def mask_api_key(api_key: str, head: int = 4, tail: int = 4) -> str:
    """For display only: 'd788****6302e3'."""
    if not api_key or len(api_key) <= head + tail:
        return "****"
    return f"{api_key[:head]}{'*' * (len(api_key) - head - tail)}{api_key[-tail:]}"
