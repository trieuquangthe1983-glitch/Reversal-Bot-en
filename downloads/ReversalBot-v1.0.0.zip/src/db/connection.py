"""SQLite connection manager + schema initialization."""
from __future__ import annotations
import os
import sqlite3
import threading
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

from ..utils import PROJECT_ROOT, ensure_dir, setup_logger

log = setup_logger("db")

STATE_DIR = ensure_dir(PROJECT_ROOT / "state")
DB_PATH = Path(os.getenv("BOT_DB_PATH", str(STATE_DIR / "bot.db")))
SCHEMA_PATH = Path(__file__).parent / "schema.sql"

_local = threading.local()


def _connect() -> sqlite3.Connection:
    # timeout=30 → SQLite waits up to 30s for a lock instead of immediately
    # raising "database is locked". Important when multiple processes (bot
    # + web + scripts) hit the same WAL file on Windows.
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH, detect_types=sqlite3.PARSE_DECLTYPES,
                           isolation_level=None,              # autocommit; explicit txn via BEGIN
                           timeout=30.0,
                           check_same_thread=True)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    conn.execute("PRAGMA busy_timeout = 30000")   # 30s, same as timeout
    return conn


def get_db() -> sqlite3.Connection:
    """Thread-local connection (sqlite3 connections aren't multi-thread safe by default).

    On fresh installs the state/ dir may not exist yet — `_connect()` now
    auto-creates it before opening the file, so this is safe to call as the
    very first DB operation on a new machine.
    """
    conn = getattr(_local, "conn", None)
    if conn is None:
        if not DB_PATH.exists():
            init_db()
        conn = _connect()
        _local.conn = conn
    return conn


def _migrate_to_v3(conn: sqlite3.Connection) -> None:
    """Additive migrations for DBs created at schema v2.

    Safe to run repeatedly: each column-add is wrapped in try/except so
    re-running on an already-migrated DB is a no-op.
    """
    # watchlist.gateio_symbol
    try:
        conn.execute("ALTER TABLE watchlist ADD COLUMN gateio_symbol TEXT")
        log.info("migrated watchlist: +gateio_symbol")
    except sqlite3.OperationalError:
        pass  # column already exists


def _migrate_to_v4(conn: sqlite3.Connection) -> None:
    """Additive migrations for LTR + contextual learner.

    Adds strategy/regime/context columns to pattern_detections and trades,
    and creates the strategy_outcomes table if missing.
    """
    for stmt, label in [
        ("ALTER TABLE pattern_detections ADD COLUMN strategy TEXT DEFAULT 'reversal'",
         "patterns: +strategy"),
        ("ALTER TABLE pattern_detections ADD COLUMN regime_label TEXT",
         "patterns: +regime_label"),
        ("ALTER TABLE pattern_detections ADD COLUMN context_json TEXT",
         "patterns: +context_json"),
        ("ALTER TABLE pattern_detections ADD COLUMN confluence_score REAL",
         "patterns: +confluence_score"),
        ("ALTER TABLE trades ADD COLUMN strategy TEXT DEFAULT 'reversal'",
         "trades: +strategy"),
        ("ALTER TABLE trades ADD COLUMN regime_label TEXT",
         "trades: +regime_label"),
        ("ALTER TABLE trades ADD COLUMN context_json TEXT",
         "trades: +context_json"),
        ("ALTER TABLE trades ADD COLUMN confluence_score REAL",
         "trades: +confluence_score"),
    ]:
        try:
            conn.execute(stmt)
            log.info("migrated %s", label)
        except sqlite3.OperationalError:
            pass  # column already exists


def _migrate_to_v5(conn: sqlite3.Connection) -> None:
    """Additive migration for licensing tables.

    Licensing tables (licenses, payment_proofs, activation_attempts) are
    all CREATE TABLE IF NOT EXISTS so the executescript() above handles
    them on fresh DBs. This migrator exists for symmetry and future
    schema changes (ALTER TABLE column adds).
    """
    # placeholder for future column adds, e.g.:
    # try:
    #     conn.execute("ALTER TABLE licenses ADD COLUMN feature_flags TEXT")
    # except sqlite3.OperationalError:
    #     pass
    return None


def init_db() -> None:
    """Create schema if DB doesn't exist. Idempotent.

    Also seeds the watchlist from config.yaml on FIRST init (when empty).
    Runs additive migrations on every call so old DBs pick up new columns.
    """
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = _connect()
    try:
        with open(SCHEMA_PATH, "r", encoding="utf-8") as f:
            conn.executescript(f.read())
        # Additive migrations for old DBs that pre-date new columns
        _migrate_to_v3(conn)
        _migrate_to_v4(conn)
        _migrate_to_v5(conn)
        # secure file perms on POSIX
        if os.name == "posix":
            try:
                os.chmod(DB_PATH, 0o600)
            except OSError:
                pass

        # Seed watchlist from config.yaml on first init
        cur = conn.execute("SELECT COUNT(*) AS n FROM watchlist").fetchone()
        if cur["n"] == 0:
            try:
                from ..utils import load_config
                from datetime import datetime, timezone
                cfg = load_config()
                bn = cfg.get("universe", {}).get("binance_symbols", {})
                okx = cfg.get("universe", {}).get("okx_symbols", {})
                gate = cfg.get("universe", {}).get("gateio_symbols", {})
                now = datetime.now(timezone.utc).isoformat(timespec="seconds")
                for token, bn_sym in bn.items():
                    conn.execute(
                        "INSERT OR IGNORE INTO watchlist (token, binance_symbol, "
                        "okx_symbol, gateio_symbol, enabled, created_at) "
                        "VALUES (?, ?, ?, ?, 1, ?)",
                        (token, bn_sym, okx.get(token), gate.get(token), now),
                    )
                log.info("seeded watchlist with %d tokens from config.yaml", len(bn))
            except Exception as e:
                log.warning("watchlist seed skipped: %s", e)

        log.info("DB initialized at %s", DB_PATH)
    finally:
        conn.close()


@contextmanager
def transaction() -> Iterator[sqlite3.Connection]:
    """Explicit transaction. Rolls back on exception."""
    conn = get_db()
    conn.execute("BEGIN")
    try:
        yield conn
        conn.execute("COMMIT")
    except Exception:
        conn.execute("ROLLBACK")
        raise


def close_thread_connection() -> None:
    conn = getattr(_local, "conn", None)
    if conn is not None:
        conn.close()
        _local.conn = None
