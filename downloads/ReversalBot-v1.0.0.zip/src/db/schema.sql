-- =========================================================================
-- Crypto Reversal Bot - SQLite Schema (v1)
-- =========================================================================
-- All tables use plain TEXT/INTEGER/REAL/BLOB. Datetimes are ISO-8601 TEXT.
-- JSON-encoded fields use TEXT.
-- =========================================================================

PRAGMA foreign_keys = ON;
PRAGMA journal_mode = WAL;

-- ----- Schema versioning -------------------------------------------------
CREATE TABLE IF NOT EXISTS schema_version (
    version INTEGER PRIMARY KEY,
    applied_at TEXT NOT NULL
);

-- ----- Users (login) -----------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash BLOB NOT NULL,           -- bcrypt
    vault_salt BLOB NOT NULL,              -- 16 bytes, used by KDF for vault key
    vault_check BLOB,                      -- Fernet-encrypted constant for password verification
    role TEXT NOT NULL DEFAULT 'user',
    created_at TEXT NOT NULL,
    last_login_at TEXT,
    failed_login_count INTEGER NOT NULL DEFAULT 0,
    locked_until TEXT
);

-- ----- API keys (encrypted at rest) --------------------------------------
CREATE TABLE IF NOT EXISTS api_keys (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    label TEXT NOT NULL,                   -- "okx-live-main", "bybit-spot"
    exchange TEXT NOT NULL,                -- okx, binance, bybit, ...
    is_testnet INTEGER NOT NULL DEFAULT 0,
    is_live_enabled INTEGER NOT NULL DEFAULT 0,
    encrypted_blob BLOB NOT NULL,          -- Fernet token. Plain = json{api_key,secret,passphrase}
    api_key_masked TEXT,                   -- "d788****6302e3" for display only
    created_at TEXT NOT NULL,
    last_used_at TEXT,
    UNIQUE(user_id, label)
);

-- ----- Parameters (versioned overrides for config.yaml) ------------------
CREATE TABLE IF NOT EXISTS parameters (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    namespace TEXT NOT NULL,               -- pattern | backtest | risk | learner | execution
    key TEXT NOT NULL,
    value_json TEXT NOT NULL,
    description TEXT,
    set_by_user_id INTEGER REFERENCES users(id),
    set_at TEXT NOT NULL,
    active INTEGER NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_params_active ON parameters(namespace, key, active);
CREATE INDEX IF NOT EXISTS idx_params_history ON parameters(namespace, key, set_at);

-- ----- Pattern detections -----------------------------------------------
CREATE TABLE IF NOT EXISTS pattern_detections (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    symbol TEXT NOT NULL,
    date_gmt7 TEXT NOT NULL,
    side TEXT NOT NULL,                    -- LONG | SHORT
    day_open REAL,
    day_close REAL,
    extreme REAL,
    extreme_time_utc TEXT,
    initial_move_pct REAL,
    reversal_pct REAL,
    trigger_price REAL,
    trigger_time_utc TEXT,
    confidence REAL,
    acted_on INTEGER NOT NULL DEFAULT 0,
    skip_reason TEXT,
    created_at TEXT NOT NULL,
    -- v4: strategy attribution and context
    strategy TEXT DEFAULT 'reversal',     -- reversal | ltr | confluence
    regime_label TEXT,                     -- e.g. up_low, chop_high
    context_json TEXT,                     -- full ContextFeatures dict
    confluence_score REAL                  -- LTR/confluence quality 0..1
);
CREATE INDEX IF NOT EXISTS idx_patterns_sym_date ON pattern_detections(symbol, date_gmt7);
CREATE INDEX IF NOT EXISTS idx_patterns_acted ON pattern_detections(acted_on, created_at);

-- ----- Trades ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS trades (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    pattern_id INTEGER REFERENCES pattern_detections(id),
    symbol TEXT NOT NULL,
    side TEXT NOT NULL,
    entry_price REAL,
    sl_price REAL,
    tp1_price REAL,
    tp2_price REAL,
    tp3_price REAL,
    contracts REAL,
    leverage INTEGER,
    risk_usdt REAL,
    notional REAL,
    confidence REAL,
    initial_move_pct REAL,
    reversal_pct REAL,
    opened_at TEXT NOT NULL,
    closed_at TEXT,
    exit_price REAL,
    exit_reason TEXT,                       -- tp1, tp2, tp3, sl, eod, manual, error
    r_pnl REAL,
    pct_pnl REAL,
    usdt_pnl REAL,
    fees_paid REAL,
    is_live INTEGER NOT NULL DEFAULT 0,    -- 0=dry_run, 1=real testnet, 2=mainnet
    status TEXT NOT NULL DEFAULT 'open',   -- open | closed | cancelled
    exchange_order_id TEXT,
    raw_response_json TEXT,
    -- v4: strategy attribution and context
    strategy TEXT DEFAULT 'reversal',     -- reversal | ltr | confluence
    regime_label TEXT,                     -- e.g. up_low, chop_high
    context_json TEXT,                     -- snapshot of ContextFeatures at entry
    confluence_score REAL                  -- LTR/confluence quality 0..1
);
CREATE INDEX IF NOT EXISTS idx_trades_status ON trades(status);
CREATE INDEX IF NOT EXISTS idx_trades_symbol ON trades(symbol);
CREATE INDEX IF NOT EXISTS idx_trades_opened ON trades(opened_at);

-- ----- Learner buckets (mirror of state/learner.json, for SQL queries) ---
CREATE TABLE IF NOT EXISTS learner_buckets (
    bucket_key TEXT PRIMARY KEY,           -- symbol|side|init_bucket|rev_bucket
    symbol TEXT,
    side TEXT,
    init_bucket TEXT,
    rev_bucket TEXT,
    alpha REAL,
    beta REAL,
    trades INTEGER,
    sum_r REAL,
    win_prob_mean REAL,
    avg_r REAL,
    last_updated TEXT
);

-- ----- Tuning runs (grid search / walk-forward etc.) ---------------------
CREATE TABLE IF NOT EXISTS tuning_runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    started_at TEXT NOT NULL,
    completed_at TEXT,
    strategy TEXT NOT NULL,                -- grid_search, walk_forward, thompson_optimal
    config_json TEXT,
    best_params_json TEXT,
    best_score REAL,
    n_combinations INTEGER,
    notes TEXT
);

-- ----- Equity curve -----------------------------------------------------
CREATE TABLE IF NOT EXISTS equity_snapshots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts TEXT NOT NULL,
    equity_usdt REAL,
    free_usdt REAL,
    open_positions_count INTEGER,
    margin_used REAL,
    note TEXT
);
CREATE INDEX IF NOT EXISTS idx_equity_ts ON equity_snapshots(ts);

-- ----- Watchlist (token universe, editable from UI) ---------------------
CREATE TABLE IF NOT EXISTS watchlist (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    token TEXT NOT NULL UNIQUE,                    -- friendly name: BTC, ETH, ...
    binance_symbol TEXT NOT NULL,                  -- BTC/USDT (for historical data)
    okx_symbol TEXT,                               -- BTC-USDT-SWAP (for execution)
    gateio_symbol TEXT,                            -- BTC/USDT:USDT (for Gate.io futures)
    enabled INTEGER NOT NULL DEFAULT 1,
    max_position_size_usdt REAL,                   -- optional per-symbol cap
    cooldown_hours_override REAL,                  -- optional per-symbol cooldown override
    notes TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_watchlist_enabled ON watchlist(enabled);

-- ----- Portfolio snapshots (logged on every /api/portfolio fetch) --------
CREATE TABLE IF NOT EXISTS portfolio_snapshots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts TEXT NOT NULL,
    user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
    key_id INTEGER REFERENCES api_keys(id) ON DELETE SET NULL,
    exchange TEXT NOT NULL,
    is_testnet INTEGER NOT NULL DEFAULT 0,
    free_usdt REAL,
    used_usdt REAL,
    total_usdt REAL,
    total_equity_usdt REAL,                        -- total + unrealized
    unrealized_pnl REAL,
    open_positions_count INTEGER,
    holdings_json TEXT,                            -- full holdings array JSON
    positions_json TEXT,                           -- full positions array JSON
    source TEXT NOT NULL DEFAULT 'manual',         -- manual (refresh button) | bot | cron
    note TEXT
);
CREATE INDEX IF NOT EXISTS idx_portfolio_ts ON portfolio_snapshots(ts);
CREATE INDEX IF NOT EXISTS idx_portfolio_user ON portfolio_snapshots(user_id, ts);
CREATE INDEX IF NOT EXISTS idx_portfolio_key ON portfolio_snapshots(key_id, ts);

-- ----- Audit log --------------------------------------------------------
CREATE TABLE IF NOT EXISTS audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts TEXT NOT NULL,
    user_id INTEGER REFERENCES users(id),
    event_type TEXT NOT NULL,              -- login, login_fail, key_add, key_access, param_change, key_delete, user_delete
    event_details TEXT,                    -- JSON or text
    ip_address TEXT,
    success INTEGER NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_audit_ts ON audit_log(ts);
CREATE INDEX IF NOT EXISTS idx_audit_event ON audit_log(event_type, ts);

-- ----- Sessions (CLI / future web UI) -----------------------------------
CREATE TABLE IF NOT EXISTS sessions (
    token TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TEXT NOT NULL,
    expires_at TEXT NOT NULL,
    last_seen_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_sessions_exp ON sessions(expires_at);

-- ----- Strategy outcomes (rolling stats for meta-learner) ---------------
CREATE TABLE IF NOT EXISTS strategy_outcomes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts TEXT NOT NULL,
    strategy TEXT NOT NULL,
    symbol TEXT,
    side TEXT,
    regime_label TEXT,
    r_pnl REAL,
    confidence REAL,
    trade_id INTEGER REFERENCES trades(id)
);
CREATE INDEX IF NOT EXISTS idx_strat_out_strat ON strategy_outcomes(strategy, ts);

-- ----- Licensing: licenses ----------------------------------------------
CREATE TABLE IF NOT EXISTS licenses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    code TEXT UNIQUE NOT NULL,             -- activation code (formatted with dashes)
    tier TEXT NOT NULL,                    -- trial | monthly | quarterly | annual | lifetime
    machine_id TEXT NOT NULL,              -- bound machine fingerprint
    user_id INTEGER REFERENCES users(id),  -- optional: who activated it
    payment_tx_hash TEXT,                  -- BSC tx that paid for this code
    issued_at TEXT NOT NULL,
    activated_at TEXT,                     -- NULL until activate_code() called
    expires_at TEXT,                       -- NULL = lifetime
    revoked_at TEXT,                       -- support can revoke (e.g. refund)
    revoke_reason TEXT,
    notes TEXT
);
CREATE INDEX IF NOT EXISTS idx_licenses_machine ON licenses(machine_id);
CREATE INDEX IF NOT EXISTS idx_licenses_tx ON licenses(payment_tx_hash);
CREATE INDEX IF NOT EXISTS idx_licenses_active ON licenses(activated_at, expires_at);

-- ----- Licensing: payment_proofs (1 tx = 1 row, prevents reuse) ---------
CREATE TABLE IF NOT EXISTS payment_proofs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    tx_hash TEXT UNIQUE NOT NULL,          -- BSC tx hash, lowercase 0x...
    from_address TEXT,                     -- buyer's wallet
    to_address TEXT,                       -- our wallet
    amount_usdt REAL,
    matched_tier TEXT,
    block_number INTEGER,
    confirmations INTEGER,
    verified_at TEXT NOT NULL,
    consumed_by_license_id INTEGER REFERENCES licenses(id),
    raw_receipt_json TEXT
);
CREATE INDEX IF NOT EXISTS idx_proofs_tier ON payment_proofs(matched_tier);

-- ----- Licensing: activation_attempts (anti-fraud rate limit) -----------
CREATE TABLE IF NOT EXISTS activation_attempts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts TEXT NOT NULL,
    ip_address TEXT,
    machine_id TEXT,
    code_prefix TEXT,                      -- only first 4 chars - never log full code
    tx_hash TEXT,
    success INTEGER NOT NULL DEFAULT 0,
    error_reason TEXT
);
CREATE INDEX IF NOT EXISTS idx_act_attempts_ts ON activation_attempts(ts);
CREATE INDEX IF NOT EXISTS idx_act_attempts_ip ON activation_attempts(ip_address, ts);

-- ----- Seed schema version ---------------------------------------------
INSERT OR IGNORE INTO schema_version (version, applied_at) VALUES (5, datetime('now'));
