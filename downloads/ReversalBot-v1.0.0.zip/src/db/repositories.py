"""CRUD repositories for each table.

Repos return plain dicts (sqlite3.Row converted) to keep types simple.
"""
from __future__ import annotations
import json
import sqlite3
from datetime import datetime, timezone
from typing import Any, Optional

from . import auth, vault
from .connection import get_db, transaction


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _row(r: sqlite3.Row | None) -> dict | None:
    return dict(r) if r else None


# =========================================================================
# Users
# =========================================================================
class UserRepo:

    @staticmethod
    def create(username: str, password: str, role: str = "user") -> dict:
        """Create a user. The same `password` is used for login AND vault by default.
        If you want them separate, pass a different vault_password to set_vault_password().
        """
        ok, msg = auth.validate_password_strength(password)
        if not ok:
            raise ValueError(f"password rejected: {msg}")
        pw_hash = auth.hash_password(password)
        salt = vault.new_salt()
        check_blob = vault.create_vault_check_blob(password, salt)
        with transaction() as conn:
            conn.execute(
                "INSERT INTO users (username, password_hash, vault_salt, vault_check, role, created_at) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (username, pw_hash, salt, check_blob, role, _now()),
            )
            uid = conn.execute("SELECT last_insert_rowid() AS id").fetchone()["id"]
        AuditRepo.log(uid, "user_create", {"username": username, "role": role})
        return UserRepo.get_by_id(uid)

    @staticmethod
    def get_by_username(username: str) -> dict | None:
        r = get_db().execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
        return _row(r)

    @staticmethod
    def get_by_id(uid: int) -> dict | None:
        r = get_db().execute("SELECT * FROM users WHERE id = ?", (uid,)).fetchone()
        return _row(r)

    @staticmethod
    def list_all() -> list[dict]:
        rows = get_db().execute(
            "SELECT id, username, role, created_at, last_login_at, failed_login_count, locked_until "
            "FROM users ORDER BY id"
        ).fetchall()
        return [dict(r) for r in rows]

    @staticmethod
    def authenticate(username: str, password: str) -> dict:
        """Verify login password (NOT the vault). Returns user row on success.
        Raises ValueError on bad creds or lockout."""
        user = UserRepo.get_by_username(username)
        if not user:
            AuditRepo.log(None, "login_fail",
                          {"username": username, "reason": "no_such_user"}, success=False)
            raise ValueError("invalid credentials")
        if user["locked_until"]:
            locked_until = datetime.fromisoformat(user["locked_until"])
            if locked_until > datetime.now(timezone.utc):
                AuditRepo.log(user["id"], "login_fail",
                              {"reason": "locked", "until": user["locked_until"]}, success=False)
                raise ValueError(f"account locked until {user['locked_until']}")
        if not auth.verify_password(password, user["password_hash"]):
            new_count = user["failed_login_count"] + 1
            lockout = auth.compute_lockout(new_count)
            with transaction() as conn:
                conn.execute(
                    "UPDATE users SET failed_login_count = ?, locked_until = ? WHERE id = ?",
                    (new_count, lockout.isoformat() if lockout else None, user["id"]),
                )
            AuditRepo.log(user["id"], "login_fail",
                          {"failed_count": new_count}, success=False)
            raise ValueError("invalid credentials")
        # success
        with transaction() as conn:
            conn.execute(
                "UPDATE users SET last_login_at = ?, failed_login_count = 0, locked_until = NULL "
                "WHERE id = ?", (_now(), user["id"]),
            )
        AuditRepo.log(user["id"], "login", {"username": username})
        return UserRepo.get_by_id(user["id"])

    @staticmethod
    def unlock_vault(username: str, vault_password: str) -> vault.VaultSession:
        user = UserRepo.get_by_username(username)
        if not user:
            raise ValueError("no such user")
        try:
            sess = vault.VaultSession.unlock(
                user_id=user["id"],
                password=vault_password,
                salt=user["vault_salt"],
                check_blob=user["vault_check"],
            )
        except ValueError:
            AuditRepo.log(user["id"], "vault_unlock_fail", success=False)
            raise
        AuditRepo.log(user["id"], "vault_unlock")
        return sess

    @staticmethod
    def delete(user_id: int) -> None:
        with transaction() as conn:
            conn.execute("DELETE FROM users WHERE id = ?", (user_id,))
        AuditRepo.log(user_id, "user_delete")

    # -- password changes ----------------------------------------------
    @staticmethod
    def change_password(user_id: int, old_password: str, new_password: str) -> None:
        """Change LOGIN password only. Vault keys are NOT affected."""
        user = UserRepo.get_by_id(user_id)
        if not user:
            raise ValueError("user not found")
        if not auth.verify_password(old_password, user["password_hash"]):
            AuditRepo.log(user_id, "password_change_fail",
                         {"reason": "old_password_incorrect"}, success=False)
            raise ValueError("old password incorrect")
        ok, msg = auth.validate_password_strength(new_password)
        if not ok:
            raise ValueError(f"new password rejected: {msg}")
        new_hash = auth.hash_password(new_password)
        with transaction() as conn:
            conn.execute("UPDATE users SET password_hash = ? WHERE id = ?",
                        (new_hash, user_id))
        AuditRepo.log(user_id, "password_change")

    @staticmethod
    def change_vault_password(user_id: int, old_vault_password: str,
                              new_vault_password: str) -> int:
        """Change VAULT password. Re-encrypts every API key atomically.

        Returns: number of keys rotated.
        """
        user = UserRepo.get_by_id(user_id)
        if not user:
            raise ValueError("user not found")
        # Verify old vault password by unlocking
        try:
            old_sess = vault.VaultSession.unlock(
                user_id=user_id, password=old_vault_password,
                salt=user["vault_salt"], check_blob=user["vault_check"],
            )
        except ValueError:
            AuditRepo.log(user_id, "vault_password_change_fail",
                         {"reason": "old_password_incorrect"}, success=False)
            raise ValueError("old vault password incorrect")

        ok, msg = auth.validate_password_strength(new_vault_password)
        if not ok:
            raise ValueError(f"new vault password rejected: {msg}")

        # Derive new vault session
        new_salt = vault.new_salt()
        new_check = vault.create_vault_check_blob(new_vault_password, new_salt)
        new_sess = vault.VaultSession.unlock(
            user_id=user_id, password=new_vault_password,
            salt=new_salt, check_blob=new_check,
        )

        # Read encrypted blobs
        rows = get_db().execute(
            "SELECT id, encrypted_blob FROM api_keys WHERE user_id = ?",
            (user_id,),
        ).fetchall()

        # Atomically: update user salt/check + re-encrypt every key
        with transaction() as conn:
            conn.execute(
                "UPDATE users SET vault_salt = ?, vault_check = ? WHERE id = ?",
                (new_salt, new_check, user_id),
            )
            for row in rows:
                try:
                    old_creds = old_sess.decrypt_credentials(row["encrypted_blob"])
                except ValueError as e:
                    raise RuntimeError(
                        f"key {row['id']} decryption failed -- ABORTING rotation. "
                        f"DB is rolled back. Error: {e}"
                    )
                new_blob = new_sess.encrypt_credentials(old_creds)
                conn.execute(
                    "UPDATE api_keys SET encrypted_blob = ? WHERE id = ?",
                    (new_blob, row["id"]),
                )

        AuditRepo.log(user_id, "vault_password_change",
                     {"n_keys_rotated": len(rows)})
        return len(rows)


# =========================================================================
# API Keys (encrypted)
# =========================================================================
class ApiKeyRepo:

    @staticmethod
    def add(user_id: int, label: str, exchange: str,
            api_key: str, secret: str, passphrase: str = "",
            is_testnet: bool = True, is_live_enabled: bool = False,
            vault_sess: vault.VaultSession | None = None) -> dict:
        if vault_sess is None or vault_sess.user_id != user_id:
            raise ValueError("vault session required and must belong to the user")
        blob = vault_sess.encrypt_credentials({
            "api_key": api_key,
            "secret": secret,
            "passphrase": passphrase,
        })
        masked = vault.mask_api_key(api_key)
        with transaction() as conn:
            conn.execute(
                "INSERT INTO api_keys (user_id, label, exchange, is_testnet, is_live_enabled, "
                "encrypted_blob, api_key_masked, created_at) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (user_id, label, exchange, int(is_testnet), int(is_live_enabled),
                 blob, masked, _now()),
            )
            kid = conn.execute("SELECT last_insert_rowid() AS id").fetchone()["id"]
        AuditRepo.log(user_id, "key_add",
                      {"label": label, "exchange": exchange, "testnet": is_testnet,
                       "live_enabled": is_live_enabled, "masked": masked})
        return ApiKeyRepo.get(kid)

    @staticmethod
    def get(key_id: int) -> dict | None:
        r = get_db().execute("SELECT * FROM api_keys WHERE id = ?", (key_id,)).fetchone()
        return _row(r)

    @staticmethod
    def get_by_label(user_id: int, label: str) -> dict | None:
        r = get_db().execute(
            "SELECT * FROM api_keys WHERE user_id = ? AND label = ?",
            (user_id, label),
        ).fetchone()
        return _row(r)

    @staticmethod
    def list_for_user(user_id: int) -> list[dict]:
        rows = get_db().execute(
            "SELECT id, label, exchange, is_testnet, is_live_enabled, api_key_masked, "
            "created_at, last_used_at FROM api_keys WHERE user_id = ? ORDER BY id",
            (user_id,),
        ).fetchall()
        return [dict(r) for r in rows]

    @staticmethod
    def get_decrypted(key_id: int, vault_sess: vault.VaultSession) -> dict:
        """Returns plaintext credentials. Caller is responsible for not leaking."""
        row = ApiKeyRepo.get(key_id)
        if not row:
            raise ValueError("no such key")
        if row["user_id"] != vault_sess.user_id:
            raise ValueError("key belongs to a different user")
        creds = vault_sess.decrypt_credentials(row["encrypted_blob"])
        with transaction() as conn:
            conn.execute("UPDATE api_keys SET last_used_at = ? WHERE id = ?",
                         (_now(), key_id))
        AuditRepo.log(vault_sess.user_id, "key_access",
                      {"key_id": key_id, "label": row["label"]})
        return creds

    @staticmethod
    def enable_live(key_id: int, user_id: int, confirm_token: str) -> None:
        """Two-step enable: requires an explicit confirm token."""
        if confirm_token != "I_UNDERSTAND_REAL_MONEY":
            raise ValueError("live trading not enabled: confirmation token mismatch")
        with transaction() as conn:
            conn.execute("UPDATE api_keys SET is_live_enabled = 1 WHERE id = ? AND user_id = ?",
                         (key_id, user_id))
        AuditRepo.log(user_id, "key_enable_live", {"key_id": key_id})

    @staticmethod
    def delete(key_id: int, user_id: int) -> None:
        with transaction() as conn:
            conn.execute("DELETE FROM api_keys WHERE id = ? AND user_id = ?",
                         (key_id, user_id))
        AuditRepo.log(user_id, "key_delete", {"key_id": key_id})


# =========================================================================
# Parameters
# =========================================================================
class ParameterRepo:

    @staticmethod
    def set(namespace: str, key: str, value: Any, user_id: int | None = None,
            description: str = "") -> dict:
        """Insert new active row; mark old rows inactive (full history kept)."""
        value_json = json.dumps(value)
        with transaction() as conn:
            conn.execute(
                "UPDATE parameters SET active = 0 WHERE namespace = ? AND key = ? AND active = 1",
                (namespace, key),
            )
            conn.execute(
                "INSERT INTO parameters (namespace, key, value_json, description, set_by_user_id, "
                "set_at, active) VALUES (?, ?, ?, ?, ?, ?, 1)",
                (namespace, key, value_json, description, user_id, _now()),
            )
        AuditRepo.log(user_id, "param_change",
                      {"namespace": namespace, "key": key, "value": value})
        return ParameterRepo.get(namespace, key)

    @staticmethod
    def get(namespace: str, key: str) -> dict | None:
        r = get_db().execute(
            "SELECT * FROM parameters WHERE namespace = ? AND key = ? AND active = 1 "
            "ORDER BY id DESC LIMIT 1", (namespace, key),
        ).fetchone()
        if not r:
            return None
        d = dict(r)
        d["value"] = json.loads(d.pop("value_json"))
        return d

    @staticmethod
    def get_value(namespace: str, key: str, default: Any = None) -> Any:
        row = ParameterRepo.get(namespace, key)
        return row["value"] if row else default

    @staticmethod
    def all_active() -> dict[str, dict[str, Any]]:
        """Returns {namespace: {key: value}}."""
        rows = get_db().execute(
            "SELECT namespace, key, value_json FROM parameters WHERE active = 1 "
            "ORDER BY namespace, key"
        ).fetchall()
        out: dict[str, dict[str, Any]] = {}
        for r in rows:
            out.setdefault(r["namespace"], {})[r["key"]] = json.loads(r["value_json"])
        return out

    @staticmethod
    def history(namespace: str, key: str, limit: int = 20) -> list[dict]:
        rows = get_db().execute(
            "SELECT * FROM parameters WHERE namespace = ? AND key = ? "
            "ORDER BY set_at DESC LIMIT ?", (namespace, key, limit),
        ).fetchall()
        return [{**dict(r), "value": json.loads(r["value_json"])} for r in rows]


# =========================================================================
# Patterns
# =========================================================================
class PatternRepo:

    @staticmethod
    def record(pattern_dict: dict, confidence: float | None = None,
              acted_on: bool = False, skip_reason: str | None = None,
              strategy: str = "reversal", regime_label: str | None = None,
              context: dict | None = None,
              confluence_score: float | None = None) -> int:
        with transaction() as conn:
            conn.execute(
                "INSERT INTO pattern_detections (symbol, date_gmt7, side, day_open, day_close, "
                "extreme, extreme_time_utc, initial_move_pct, reversal_pct, trigger_price, "
                "trigger_time_utc, confidence, acted_on, skip_reason, created_at, "
                "strategy, regime_label, context_json, confluence_score) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    pattern_dict["symbol"], pattern_dict["date_gmt7"], pattern_dict["side"],
                    pattern_dict.get("day_open"), pattern_dict.get("day_close"),
                    pattern_dict.get("extreme") or pattern_dict.get("sweep_extreme"),
                    pattern_dict.get("extreme_time_utc") or pattern_dict.get("sweep_time_utc"),
                    pattern_dict.get("initial_move_pct"), pattern_dict.get("reversal_pct"),
                    pattern_dict.get("trigger_price"), pattern_dict.get("trigger_time_utc"),
                    confidence, int(bool(acted_on)), skip_reason, _now(),
                    strategy, regime_label,
                    json.dumps(context) if context else None,
                    confluence_score,
                ),
            )
            return conn.execute("SELECT last_insert_rowid() AS id").fetchone()["id"]

    @staticmethod
    def recent(limit: int = 100) -> list[dict]:
        rows = get_db().execute(
            "SELECT * FROM pattern_detections ORDER BY created_at DESC LIMIT ?", (limit,),
        ).fetchall()
        return [dict(r) for r in rows]


# =========================================================================
# Trades
# =========================================================================
class TradeRepo:

    @staticmethod
    def open_trade(pattern_id: int, setup_dict: dict, sizing_dict: dict,
                   is_live: int = 0, exchange_order_id: str | None = None,
                   regime_label: str | None = None,
                   context: dict | None = None,
                   confluence_score: float | None = None) -> int:
        with transaction() as conn:
            conn.execute(
                "INSERT INTO trades (pattern_id, symbol, side, entry_price, sl_price, "
                "tp1_price, tp2_price, tp3_price, contracts, leverage, risk_usdt, notional, "
                "confidence, initial_move_pct, reversal_pct, opened_at, is_live, status, "
                "exchange_order_id, strategy, regime_label, context_json, confluence_score) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'open', ?, ?, ?, ?, ?)",
                (
                    pattern_id, setup_dict["symbol"], setup_dict["side"],
                    setup_dict["entry"], setup_dict["sl"],
                    setup_dict["tp1"], setup_dict["tp2"], setup_dict["tp3"],
                    sizing_dict.get("contracts"), sizing_dict.get("leverage"),
                    sizing_dict.get("risk_usdt"), sizing_dict.get("notional"),
                    setup_dict.get("confidence"),
                    setup_dict.get("initial_move_pct"), setup_dict.get("reversal_pct"),
                    _now(), is_live, exchange_order_id,
                    setup_dict.get("strategy", "reversal"),
                    regime_label,
                    json.dumps(context) if context else None,
                    confluence_score,
                ),
            )
            return conn.execute("SELECT last_insert_rowid() AS id").fetchone()["id"]

    @staticmethod
    def close_trade(trade_id: int, exit_price: float, exit_reason: str,
                    r_pnl: float, pct_pnl: float, usdt_pnl: float = 0.0,
                    fees_paid: float = 0.0) -> None:
        with transaction() as conn:
            conn.execute(
                "UPDATE trades SET closed_at = ?, exit_price = ?, exit_reason = ?, "
                "r_pnl = ?, pct_pnl = ?, usdt_pnl = ?, fees_paid = ?, status = 'closed' "
                "WHERE id = ?",
                (_now(), exit_price, exit_reason, r_pnl, pct_pnl, usdt_pnl,
                 fees_paid, trade_id),
            )

    @staticmethod
    def open_positions() -> list[dict]:
        rows = get_db().execute(
            "SELECT * FROM trades WHERE status = 'open' ORDER BY opened_at"
        ).fetchall()
        return [dict(r) for r in rows]

    @staticmethod
    def recent_closed(limit: int = 50) -> list[dict]:
        rows = get_db().execute(
            "SELECT * FROM trades WHERE status = 'closed' ORDER BY closed_at DESC LIMIT ?",
            (limit,),
        ).fetchall()
        return [dict(r) for r in rows]

    @staticmethod
    def summary_by_symbol() -> list[dict]:
        rows = get_db().execute(
            "SELECT symbol, COUNT(*) AS n, "
            "SUM(CASE WHEN r_pnl > 0 THEN 1 ELSE 0 END) AS wins, "
            "ROUND(AVG(r_pnl), 3) AS avg_r, ROUND(SUM(r_pnl), 2) AS total_r, "
            "ROUND(SUM(usdt_pnl), 2) AS total_usdt "
            "FROM trades WHERE status = 'closed' GROUP BY symbol ORDER BY total_r DESC"
        ).fetchall()
        return [dict(r) for r in rows]


# =========================================================================
# Learner mirror
# =========================================================================
class LearnerRepo:

    @staticmethod
    def upsert_bucket(bucket_key: str, symbol: str, side: str,
                      init_bucket: str, rev_bucket: str,
                      alpha: float, beta: float, trades: int, sum_r: float) -> None:
        with transaction() as conn:
            conn.execute(
                "INSERT INTO learner_buckets (bucket_key, symbol, side, init_bucket, "
                "rev_bucket, alpha, beta, trades, sum_r, win_prob_mean, avg_r, last_updated) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) "
                "ON CONFLICT(bucket_key) DO UPDATE SET "
                "alpha = excluded.alpha, beta = excluded.beta, trades = excluded.trades, "
                "sum_r = excluded.sum_r, win_prob_mean = excluded.win_prob_mean, "
                "avg_r = excluded.avg_r, last_updated = excluded.last_updated",
                (
                    bucket_key, symbol, side, init_bucket, rev_bucket,
                    alpha, beta, trades, sum_r,
                    alpha / (alpha + beta) if (alpha + beta) > 0 else 0,
                    sum_r / trades if trades > 0 else 0,
                    _now(),
                ),
            )

    @staticmethod
    def list_buckets() -> list[dict]:
        rows = get_db().execute(
            "SELECT * FROM learner_buckets ORDER BY trades DESC"
        ).fetchall()
        return [dict(r) for r in rows]


# =========================================================================
# Strategy outcomes (per-trade attribution for meta-learner)
# =========================================================================
class StrategyOutcomeRepo:

    @staticmethod
    def record(strategy: str, r_pnl: float, *, symbol: str | None = None,
               side: str | None = None, regime_label: str | None = None,
               confidence: float | None = None,
               trade_id: int | None = None) -> None:
        with transaction() as conn:
            conn.execute(
                "INSERT INTO strategy_outcomes (ts, strategy, symbol, side, "
                "regime_label, r_pnl, confidence, trade_id) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (_now(), strategy, symbol, side, regime_label,
                 float(r_pnl), confidence, trade_id),
            )

    @staticmethod
    def recent_by_strategy(strategy: str, limit: int = 100) -> list[dict]:
        rows = get_db().execute(
            "SELECT * FROM strategy_outcomes WHERE strategy = ? "
            "ORDER BY ts DESC LIMIT ?", (strategy, limit),
        ).fetchall()
        return [dict(r) for r in rows]

    @staticmethod
    def summary() -> list[dict]:
        rows = get_db().execute(
            "SELECT strategy, COUNT(*) AS n, "
            "SUM(CASE WHEN r_pnl > 0 THEN 1 ELSE 0 END) AS wins, "
            "ROUND(AVG(r_pnl), 3) AS avg_r, ROUND(SUM(r_pnl), 2) AS total_r "
            "FROM strategy_outcomes GROUP BY strategy ORDER BY total_r DESC"
        ).fetchall()
        return [dict(r) for r in rows]


# =========================================================================
# Equity snapshots
# =========================================================================
class EquityRepo:

    @staticmethod
    def snapshot(equity: float, free: float = 0.0, open_positions: int = 0,
                 margin_used: float = 0.0, note: str = "") -> None:
        with transaction() as conn:
            conn.execute(
                "INSERT INTO equity_snapshots (ts, equity_usdt, free_usdt, "
                "open_positions_count, margin_used, note) VALUES (?, ?, ?, ?, ?, ?)",
                (_now(), equity, free, open_positions, margin_used, note),
            )

    @staticmethod
    def recent(limit: int = 200) -> list[dict]:
        rows = get_db().execute(
            "SELECT * FROM equity_snapshots ORDER BY ts DESC LIMIT ?", (limit,),
        ).fetchall()
        return [dict(r) for r in rows]


# =========================================================================
# Portfolio snapshots (logged on every /api/portfolio fetch)
# =========================================================================
class PortfolioSnapshotRepo:

    @staticmethod
    def record(user_id: int | None, key_id: int | None, exchange: str,
               is_testnet: bool, free_usdt: float, used_usdt: float,
               total_usdt: float, total_equity_usdt: float,
               unrealized_pnl: float, open_positions_count: int,
               holdings: list, positions: list,
               source: str = "manual", note: str = "") -> int:
        with transaction() as conn:
            conn.execute(
                "INSERT INTO portfolio_snapshots (ts, user_id, key_id, exchange, "
                "is_testnet, free_usdt, used_usdt, total_usdt, total_equity_usdt, "
                "unrealized_pnl, open_positions_count, holdings_json, positions_json, "
                "source, note) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (_now(), user_id, key_id, exchange, int(bool(is_testnet)),
                 free_usdt, used_usdt, total_usdt, total_equity_usdt,
                 unrealized_pnl, open_positions_count,
                 json.dumps(holdings), json.dumps(positions), source, note),
            )
            return conn.execute("SELECT last_insert_rowid() AS id").fetchone()["id"]

    @staticmethod
    def recent(user_id: int | None = None, key_id: int | None = None,
               limit: int = 100) -> list[dict]:
        sql = "SELECT * FROM portfolio_snapshots"
        clauses = []
        params: list = []
        if user_id is not None:
            clauses.append("user_id = ?"); params.append(user_id)
        if key_id is not None:
            clauses.append("key_id = ?"); params.append(key_id)
        if clauses:
            sql += " WHERE " + " AND ".join(clauses)
        sql += " ORDER BY ts DESC LIMIT ?"
        params.append(limit)
        rows = get_db().execute(sql, params).fetchall()
        out = []
        for r in rows:
            d = dict(r)
            # Don't expand holdings_json/positions_json by default -- caller
            # asks for it via /detail if needed. Keep list view lightweight.
            d.pop("holdings_json", None)
            d.pop("positions_json", None)
            out.append(d)
        return out

    @staticmethod
    def get(snapshot_id: int) -> dict | None:
        r = get_db().execute(
            "SELECT * FROM portfolio_snapshots WHERE id = ?", (snapshot_id,),
        ).fetchone()
        if not r:
            return None
        d = dict(r)
        d["holdings"] = json.loads(d.pop("holdings_json") or "[]")
        d["positions"] = json.loads(d.pop("positions_json") or "[]")
        return d

    @staticmethod
    def summary(user_id: int | None = None, limit: int = 1000) -> dict:
        """Aggregate stats for the Portfolio tab header."""
        sql = "SELECT COUNT(*) AS n, MIN(ts) AS first_ts, MAX(ts) AS last_ts " \
              "FROM portfolio_snapshots"
        params: list = []
        if user_id is not None:
            sql += " WHERE user_id = ?"; params.append(user_id)
        r = get_db().execute(sql, params).fetchone()
        return dict(r) if r else {"n": 0, "first_ts": None, "last_ts": None}


# =========================================================================
# Tuning runs
# =========================================================================
class TuningRepo:

    @staticmethod
    def start(strategy: str, config: dict) -> int:
        with transaction() as conn:
            conn.execute(
                "INSERT INTO tuning_runs (started_at, strategy, config_json) VALUES (?, ?, ?)",
                (_now(), strategy, json.dumps(config)),
            )
            return conn.execute("SELECT last_insert_rowid() AS id").fetchone()["id"]

    @staticmethod
    def finish(run_id: int, best_params: dict, best_score: float,
               n_combinations: int, notes: str = "") -> None:
        with transaction() as conn:
            conn.execute(
                "UPDATE tuning_runs SET completed_at = ?, best_params_json = ?, "
                "best_score = ?, n_combinations = ?, notes = ? WHERE id = ?",
                (_now(), json.dumps(best_params), best_score, n_combinations, notes, run_id),
            )

    @staticmethod
    def recent(limit: int = 10) -> list[dict]:
        rows = get_db().execute(
            "SELECT * FROM tuning_runs ORDER BY started_at DESC LIMIT ?", (limit,),
        ).fetchall()
        return [{**dict(r),
                "config": json.loads(r["config_json"] or "null"),
                "best_params": json.loads(r["best_params_json"] or "null")}
                for r in rows]


# =========================================================================
# Watchlist (token universe)
# =========================================================================
class WatchlistRepo:

    @staticmethod
    def list_all(enabled_only: bool = False) -> list[dict]:
        sql = "SELECT * FROM watchlist"
        if enabled_only:
            sql += " WHERE enabled = 1"
        sql += " ORDER BY token"
        rows = get_db().execute(sql).fetchall()
        return [dict(r) for r in rows]

    @staticmethod
    def get(watchlist_id: int) -> dict | None:
        r = get_db().execute("SELECT * FROM watchlist WHERE id = ?", (watchlist_id,)).fetchone()
        return _row(r)

    @staticmethod
    def get_by_token(token: str) -> dict | None:
        r = get_db().execute("SELECT * FROM watchlist WHERE token = ?",
                            (token.upper(),)).fetchone()
        return _row(r)

    @staticmethod
    def add(token: str, binance_symbol: str, okx_symbol: str | None = None,
            gateio_symbol: str | None = None,
            enabled: bool = True, max_position_size_usdt: float | None = None,
            cooldown_hours_override: float | None = None, notes: str = "",
            user_id: int | None = None) -> dict:
        token = token.upper().strip()
        if not token or not binance_symbol:
            raise ValueError("token and binance_symbol are required")
        existing = WatchlistRepo.get_by_token(token)
        if existing:
            raise ValueError(f"token '{token}' already exists")
        with transaction() as conn:
            conn.execute(
                "INSERT INTO watchlist (token, binance_symbol, okx_symbol, gateio_symbol, "
                "enabled, max_position_size_usdt, cooldown_hours_override, notes, created_at) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (token, binance_symbol, okx_symbol, gateio_symbol, int(enabled),
                 max_position_size_usdt, cooldown_hours_override, notes, _now()),
            )
            wid = conn.execute("SELECT last_insert_rowid() AS id").fetchone()["id"]
        AuditRepo.log(user_id, "watchlist_add",
                     {"token": token, "binance": binance_symbol,
                      "okx": okx_symbol, "gateio": gateio_symbol})
        return WatchlistRepo.get(wid)

    @staticmethod
    def update(watchlist_id: int, fields: dict, user_id: int | None = None) -> dict:
        allowed = {"binance_symbol", "okx_symbol", "gateio_symbol", "enabled", "notes",
                  "max_position_size_usdt", "cooldown_hours_override"}
        updates = {k: v for k, v in fields.items() if k in allowed}
        if not updates:
            raise ValueError("no valid fields to update")
        # Bool coercion
        if "enabled" in updates:
            updates["enabled"] = int(bool(updates["enabled"]))
        set_clause = ", ".join(f"{k} = ?" for k in updates)
        params = list(updates.values()) + [_now(), watchlist_id]
        with transaction() as conn:
            conn.execute(
                f"UPDATE watchlist SET {set_clause}, updated_at = ? WHERE id = ?",
                params,
            )
        AuditRepo.log(user_id, "watchlist_update",
                     {"id": watchlist_id, "fields": updates})
        return WatchlistRepo.get(watchlist_id)

    @staticmethod
    def toggle(watchlist_id: int, user_id: int | None = None) -> dict:
        r = WatchlistRepo.get(watchlist_id)
        if not r:
            raise ValueError("watchlist row not found")
        return WatchlistRepo.update(watchlist_id, {"enabled": not r["enabled"]},
                                   user_id=user_id)

    @staticmethod
    def delete(watchlist_id: int, user_id: int | None = None) -> None:
        r = WatchlistRepo.get(watchlist_id)
        if not r:
            raise ValueError("watchlist row not found")
        with transaction() as conn:
            conn.execute("DELETE FROM watchlist WHERE id = ?", (watchlist_id,))
        AuditRepo.log(user_id, "watchlist_delete",
                     {"id": watchlist_id, "token": r["token"]})

    @staticmethod
    def get_active_universe() -> tuple[dict, dict]:
        """For the bot: returns (binance_map, okx_map) of enabled tokens only.

        Same shape as config.yaml's universe.binance_symbols / okx_symbols.
        """
        rows = WatchlistRepo.list_all(enabled_only=True)
        binance = {r["token"]: r["binance_symbol"] for r in rows if r["binance_symbol"]}
        okx = {r["token"]: r["okx_symbol"] for r in rows if r["okx_symbol"]}
        return binance, okx

    @staticmethod
    def get_active_universe_for(exchange: str) -> tuple[dict, dict]:
        """Returns (binance_map, exec_map) where exec_map is the column matching
        the given exchange name. Falls back to OKX if exchange is unknown."""
        rows = WatchlistRepo.list_all(enabled_only=True)
        binance = {r["token"]: r["binance_symbol"] for r in rows if r["binance_symbol"]}
        col = {"gateio": "gateio_symbol", "gate": "gateio_symbol",
               "okx": "okx_symbol"}.get((exchange or "").lower(), "okx_symbol")
        exec_map = {r["token"]: r.get(col) for r in rows if r.get(col)}
        return binance, exec_map


# =========================================================================
# Audit log
# =========================================================================
class AuditRepo:

    @staticmethod
    def log(user_id: int | None, event_type: str, details: dict | str | None = None,
            success: bool = True, ip_address: str | None = None) -> None:
        det = json.dumps(details) if isinstance(details, dict) else (details or "")
        try:
            with transaction() as conn:
                conn.execute(
                    "INSERT INTO audit_log (ts, user_id, event_type, event_details, "
                    "ip_address, success) VALUES (?, ?, ?, ?, ?, ?)",
                    (_now(), user_id, event_type, det, ip_address, int(success)),
                )
        except sqlite3.Error:
            # never let audit failure crash a trade
            pass

    @staticmethod
    def recent(limit: int = 100, event_type: str | None = None) -> list[dict]:
        if event_type:
            rows = get_db().execute(
                "SELECT * FROM audit_log WHERE event_type = ? ORDER BY ts DESC LIMIT ?",
                (event_type, limit),
            ).fetchall()
        else:
            rows = get_db().execute(
                "SELECT * FROM audit_log ORDER BY ts DESC LIMIT ?", (limit,),
            ).fetchall()
        return [dict(r) for r in rows]


# =========================================================================
# Session repo (for CLI persistent login)
# =========================================================================
class SessionRepo:

    @staticmethod
    def create(user_id: int) -> str:
        token = auth.new_session_token()
        exp = auth.session_expiry()
        with transaction() as conn:
            conn.execute(
                "INSERT INTO sessions (token, user_id, created_at, expires_at, last_seen_at) "
                "VALUES (?, ?, ?, ?, ?)",
                (token, user_id, _now(), exp.isoformat(), _now()),
            )
        return token

    @staticmethod
    def get_user_id(token: str) -> int | None:
        """Returns user_id if the session is valid, else None.

        Sliding TTL: on every successful hit we extend `expires_at` to
        now + SESSION_TTL_HOURS. The DB stays the authoritative source of
        truth; idle-timeout = SESSION_TTL_HOURS from last activity, not
        from initial login.
        """
        r = get_db().execute(
            "SELECT user_id, expires_at FROM sessions WHERE token = ?", (token,),
        ).fetchone()
        if not r:
            return None
        if datetime.fromisoformat(r["expires_at"]) < datetime.now(timezone.utc):
            SessionRepo.revoke(token)
            return None
        # Slide: extend expires_at + bump last_seen_at atomically
        new_exp = auth.session_expiry().isoformat()
        with transaction() as conn:
            conn.execute(
                "UPDATE sessions SET last_seen_at = ?, expires_at = ? WHERE token = ?",
                (_now(), new_exp, token),
            )
        return r["user_id"]

    @staticmethod
    def revoke(token: str) -> None:
        with transaction() as conn:
            conn.execute("DELETE FROM sessions WHERE token = ?", (token,))

    @staticmethod
    def cleanup_expired() -> int:
        """Garbage-collect rows whose expires_at is in the past. Returns count."""
        with transaction() as conn:
            cur = conn.execute(
                "DELETE FROM sessions WHERE expires_at < ?",
                (_now(),),
            )
            return cur.rowcount or 0


# =========================================================================
# Licensing
# =========================================================================
class LicenseRepo:
    """CRUD for the licenses table.

    A license row is created at activate-time (after a code is verified).
    Trial code generation also reserves a row so the same machine can't
    re-claim trial.
    """

    @staticmethod
    def get_by_code(code: str) -> dict | None:
        r = get_db().execute(
            "SELECT * FROM licenses WHERE code = ?", (code,),
        ).fetchone()
        return _row(r)

    @staticmethod
    def get_active_for_machine(machine_id: str) -> dict | None:
        """The non-revoked, non-expired license currently bound to this machine."""
        r = get_db().execute(
            "SELECT * FROM licenses WHERE machine_id = ? AND revoked_at IS NULL "
            "AND (expires_at IS NULL OR expires_at > ?) "
            "ORDER BY activated_at DESC LIMIT 1",
            (machine_id, _now()),
        ).fetchone()
        return _row(r)

    @staticmethod
    def has_used_trial(machine_id: str) -> bool:
        r = get_db().execute(
            "SELECT 1 FROM licenses WHERE machine_id = ? AND tier = 'trial' LIMIT 1",
            (machine_id,),
        ).fetchone()
        return r is not None

    @staticmethod
    def insert(code: str, tier: str, machine_id: str,
               payment_tx_hash: str | None, expires_at: str | None,
               user_id: int | None = None, notes: str = "") -> int:
        with transaction() as conn:
            conn.execute(
                "INSERT INTO licenses (code, tier, machine_id, user_id, "
                "payment_tx_hash, issued_at, activated_at, expires_at, notes) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (code, tier, machine_id, user_id, payment_tx_hash,
                 _now(), _now(), expires_at, notes),
            )
            return conn.execute("SELECT last_insert_rowid() AS id").fetchone()["id"]

    @staticmethod
    def revoke(license_id: int, reason: str) -> None:
        with transaction() as conn:
            conn.execute(
                "UPDATE licenses SET revoked_at = ?, revoke_reason = ? WHERE id = ?",
                (_now(), reason, license_id),
            )

    @staticmethod
    def list_all(limit: int = 100) -> list[dict]:
        rows = get_db().execute(
            "SELECT id, code, tier, machine_id, payment_tx_hash, issued_at, "
            "activated_at, expires_at, revoked_at FROM licenses "
            "ORDER BY id DESC LIMIT ?", (limit,),
        ).fetchall()
        return [dict(r) for r in rows]


class PaymentProofRepo:
    """CRUD for payment_proofs (1 tx = 1 row, prevents reuse)."""

    @staticmethod
    def get_by_tx(tx_hash: str) -> dict | None:
        r = get_db().execute(
            "SELECT * FROM payment_proofs WHERE tx_hash = ?",
            (tx_hash.lower(),),
        ).fetchone()
        return _row(r)

    @staticmethod
    def record(tx_hash: str, from_address: str, to_address: str,
               amount_usdt: float, matched_tier: str | None,
               block_number: int, confirmations: int,
               raw_receipt: dict | None = None) -> int:
        with transaction() as conn:
            conn.execute(
                "INSERT INTO payment_proofs (tx_hash, from_address, to_address, "
                "amount_usdt, matched_tier, block_number, confirmations, "
                "verified_at, raw_receipt_json) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (tx_hash.lower(), from_address.lower(), to_address.lower(),
                 amount_usdt, matched_tier, block_number, confirmations,
                 _now(), json.dumps(raw_receipt or {})),
            )
            return conn.execute("SELECT last_insert_rowid() AS id").fetchone()["id"]

    @staticmethod
    def mark_consumed(tx_hash: str, license_id: int) -> None:
        with transaction() as conn:
            conn.execute(
                "UPDATE payment_proofs SET consumed_by_license_id = ? "
                "WHERE tx_hash = ?",
                (license_id, tx_hash.lower()),
            )


class ActivationAttemptRepo:
    """Rate-limit + audit for license activation attempts.

    Never stores the FULL code (just first 4 chars) to avoid leaking a
    valid code via DB browse or log scrape.
    """

    @staticmethod
    def record(ip: str | None, machine_id: str | None,
               code_prefix: str | None, tx_hash: str | None,
               success: bool, error_reason: str = "") -> int:
        with transaction() as conn:
            conn.execute(
                "INSERT INTO activation_attempts (ts, ip_address, machine_id, "
                "code_prefix, tx_hash, success, error_reason) "
                "VALUES (?, ?, ?, ?, ?, ?, ?)",
                (_now(), ip, machine_id, (code_prefix or "")[:4],
                 tx_hash, int(bool(success)), error_reason),
            )
            return conn.execute("SELECT last_insert_rowid() AS id").fetchone()["id"]

    @staticmethod
    def count_recent_failures(ip: str, minutes: int = 60) -> int:
        """How many failed attempts from this IP in the last `minutes` minutes?"""
        from datetime import datetime, timedelta, timezone
        cutoff = (datetime.now(timezone.utc) - timedelta(minutes=minutes)).isoformat()
        r = get_db().execute(
            "SELECT COUNT(*) AS n FROM activation_attempts "
            "WHERE ip_address = ? AND success = 0 AND ts >= ?",
            (ip, cutoff),
        ).fetchone()
        return int(r["n"]) if r else 0
