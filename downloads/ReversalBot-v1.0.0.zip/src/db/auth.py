"""Authentication: password hashing (bcrypt) + session tokens."""
from __future__ import annotations
import re
import secrets
from dataclasses import dataclass
from datetime import datetime, timezone, timedelta
from typing import Optional

import bcrypt

# --- password policy ------------------------------------------------------
MIN_PASSWORD_LEN = 12
_HAS_UPPER = re.compile(r"[A-Z]")
_HAS_LOWER = re.compile(r"[a-z]")
_HAS_DIGIT = re.compile(r"\d")
_HAS_SYMBOL = re.compile(r"[^A-Za-z0-9]")


def validate_password_strength(pw: str) -> tuple[bool, str]:
    if len(pw) < MIN_PASSWORD_LEN:
        return False, f"password must be at least {MIN_PASSWORD_LEN} characters"
    classes = sum(bool(p.search(pw)) for p in (_HAS_UPPER, _HAS_LOWER, _HAS_DIGIT, _HAS_SYMBOL))
    if classes < 3:
        return False, "password must contain at least 3 of: uppercase, lowercase, digit, symbol"
    return True, "ok"


def hash_password(pw: str, rounds: int = 12) -> bytes:
    """bcrypt hash. Returns bytes (store as BLOB)."""
    return bcrypt.hashpw(pw.encode("utf-8"), bcrypt.gensalt(rounds=rounds))


def verify_password(pw: str, hashed: bytes) -> bool:
    """Constant-time verification."""
    try:
        return bcrypt.checkpw(pw.encode("utf-8"), hashed)
    except (ValueError, TypeError):
        return False


# --- session tokens -------------------------------------------------------
SESSION_TTL_HOURS = 8


@dataclass
class Session:
    token: str
    user_id: int
    created_at: datetime
    expires_at: datetime


def new_session_token() -> str:
    """URL-safe 256-bit random token."""
    return secrets.token_urlsafe(32)


def session_expiry(ttl_hours: int = SESSION_TTL_HOURS) -> datetime:
    return datetime.now(timezone.utc) + timedelta(hours=ttl_hours)


# --- account lockout ------------------------------------------------------
MAX_FAILED_LOGINS = 5
LOCKOUT_MINUTES = 15


def compute_lockout(failed_count: int) -> Optional[datetime]:
    if failed_count >= MAX_FAILED_LOGINS:
        return datetime.now(timezone.utc) + timedelta(minutes=LOCKOUT_MINUTES)
    return None
