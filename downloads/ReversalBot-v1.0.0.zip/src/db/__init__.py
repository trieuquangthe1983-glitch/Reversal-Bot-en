"""Database package: SQLite-backed persistence for the bot.

Modules:
  connection      sqlite3 connection manager + schema bootstrap
  auth            bcrypt password hashing, session tokens
  vault           Fernet encryption for API keys (PBKDF2-derived key)
  repositories    CRUD for every table
"""
from .connection import get_db, init_db, DB_PATH
from .repositories import (
    UserRepo, ApiKeyRepo, ParameterRepo, PatternRepo,
    TradeRepo, LearnerRepo, AuditRepo, EquityRepo, TuningRepo,
    WatchlistRepo, PortfolioSnapshotRepo, StrategyOutcomeRepo,
    LicenseRepo, PaymentProofRepo, ActivationAttemptRepo,
)

__all__ = [
    "get_db", "init_db", "DB_PATH",
    "UserRepo", "ApiKeyRepo", "ParameterRepo", "PatternRepo",
    "TradeRepo", "LearnerRepo", "AuditRepo", "EquityRepo", "TuningRepo",
    "WatchlistRepo", "PortfolioSnapshotRepo", "StrategyOutcomeRepo",
    "LicenseRepo", "PaymentProofRepo", "ActivationAttemptRepo",
]
