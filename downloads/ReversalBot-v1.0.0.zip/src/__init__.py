"""Crypto reversal-pattern detection and trading bot."""
__version__ = "0.1.0"
