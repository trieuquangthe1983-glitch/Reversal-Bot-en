"""Adaptive learner v2 — three layers, cooperative.

L1  Beta-Bernoulli per coarse bucket.
    Bucket key adds STRATEGY + REGIME on top of the v1 (symbol|side|init|rev):
        strategy|symbol|side|regime|init_bucket|rev_bucket
    Why: regime is the single most important latent variable in crypto.
    Pure init/rev buckets bleed across regimes and dilute signal.

L2  Online Gaussian estimate of E[R] per bucket.
    Beta tells us "how often we win"; Gaussian tells us "by how much".
    Score = win_prob * (1 + E[R]).  This stops the learner from blessing
    high-winrate setups with poor R distributions.

L3  Online logistic regression on the full context feature vector.
    Per-strategy weights (each strategy gets its own model — confluence is
    rare enough that we backfill from "reversal" weights as a warm start).
    Trains with one SGD step per closed trade. No nightly retrain needed.

Confidence output is a weighted blend of all three, gated by sample size:
    - <5 trades in bucket:           use prior 0.5
    - 5..30 trades in bucket:        rely mostly on Beta + Gaussian
    - 30+ trades total per strategy: blend in L3 logistic
"""
from __future__ import annotations
import json
import math
import time
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Optional

import numpy as np

from .context import ContextFeatures, FEATURE_ORDER
from .playbook import TradeSetup
from .utils import PROJECT_ROOT, setup_logger, ensure_dir

log = setup_logger("learner_v2")
STATE_DIR = ensure_dir(PROJECT_ROOT / "state")
STATE_FILE = STATE_DIR / "learner_v2.json"


# ---------------------------------------------------------------------------
# Buckets
# ---------------------------------------------------------------------------
def bucket_initial_move(pct: float) -> str:
    if pct < 1.2:
        return "lo"
    if pct < 1.6:
        return "mid"
    if pct < 2.5:
        return "hi"
    return "xtrm"


def bucket_reversal(pct: float) -> str:
    if pct < 1.5:
        return "shallow"
    if pct < 2.5:
        return "med"
    if pct < 4.0:
        return "deep"
    return "extreme"


@dataclass
class BucketStats:
    # L1 Beta
    alpha: float = 1.0
    beta: float = 1.0
    # L2 Gaussian on R (running mean & variance via decayed Welford)
    r_mean: float = 0.0
    r_var: float = 1.0
    trades: int = 0
    sum_r: float = 0.0
    last_ts: float = 0.0

    @property
    def win_prob_mean(self) -> float:
        return self.alpha / (self.alpha + self.beta)

    @property
    def avg_r(self) -> float:
        return self.sum_r / self.trades if self.trades else 0.0


@dataclass
class LogisticModel:
    """Online L2-regularized logistic regression. One per strategy."""
    weights: list[float] = field(default_factory=lambda: [0.0] * len(FEATURE_ORDER))
    bias: float = 0.0
    n_updates: int = 0
    lr: float = 0.05
    l2: float = 1e-4

    def predict_proba(self, x: np.ndarray) -> float:
        z = float(np.dot(np.asarray(self.weights), x) + self.bias)
        # clamp z to avoid overflow
        z = max(-30.0, min(30.0, z))
        return 1.0 / (1.0 + math.exp(-z))

    def update(self, x: np.ndarray, y: int) -> None:
        """One SGD step. y in {0, 1}."""
        p = self.predict_proba(x)
        err = p - float(y)
        w = np.asarray(self.weights)
        new_w = w - self.lr * (err * x + self.l2 * w)
        self.weights = new_w.tolist()
        self.bias -= self.lr * err
        self.n_updates += 1


# ---------------------------------------------------------------------------
# Learner state
# ---------------------------------------------------------------------------
@dataclass
class LearnerV2State:
    buckets: dict[str, BucketStats] = field(default_factory=dict)
    logistic_models: dict[str, LogisticModel] = field(default_factory=dict)  # per strategy
    prior_alpha: float = 1.0
    prior_beta: float = 1.0
    decay_factor: float = 0.985

    def bucket_key(self, *, strategy: str, symbol: str, side: str,
                   regime: str, init_bucket: str, rev_bucket: str) -> str:
        return f"{strategy}|{symbol}|{side}|{regime}|{init_bucket}|{rev_bucket}"

    def get_or_create_bucket(self, key: str) -> BucketStats:
        if key not in self.buckets:
            self.buckets[key] = BucketStats(
                alpha=self.prior_alpha, beta=self.prior_beta,
            )
        return self.buckets[key]

    def get_or_create_model(self, strategy: str) -> LogisticModel:
        if strategy not in self.logistic_models:
            # Warm-start "confluence" from "reversal" if available
            if strategy == "confluence" and "reversal" in self.logistic_models:
                src = self.logistic_models["reversal"]
                self.logistic_models[strategy] = LogisticModel(
                    weights=list(src.weights), bias=src.bias,
                    n_updates=0, lr=src.lr, l2=src.l2,
                )
            else:
                self.logistic_models[strategy] = LogisticModel()
        return self.logistic_models[strategy]


# ---------------------------------------------------------------------------
# Adaptive learner v2
# ---------------------------------------------------------------------------
class AdaptiveLearnerV2:

    def __init__(self,
                 prior_alpha: float = 1.0,
                 prior_beta: float = 1.0,
                 decay_factor: float = 0.985,
                 min_trades_for_bucket: int = 5,
                 min_trades_for_logistic: int = 30):
        self.state = LearnerV2State(
            prior_alpha=prior_alpha, prior_beta=prior_beta,
            decay_factor=decay_factor,
        )
        self.min_trades_for_bucket = min_trades_for_bucket
        self.min_trades_for_logistic = min_trades_for_logistic
        self._load()
        # per-strategy total counters for gating logistic
        self._strategy_counts: dict[str, int] = {}

    # -- persistence ----------------------------------------------------
    def _load(self) -> None:
        if not STATE_FILE.exists():
            return
        try:
            raw = json.loads(STATE_FILE.read_text())
            self.state.prior_alpha = raw.get("prior_alpha", 1.0)
            self.state.prior_beta = raw.get("prior_beta", 1.0)
            self.state.decay_factor = raw.get("decay_factor", 0.985)
            self.state.buckets = {k: BucketStats(**v)
                                  for k, v in raw.get("buckets", {}).items()}
            self.state.logistic_models = {
                s: LogisticModel(**v)
                for s, v in raw.get("logistic_models", {}).items()
            }
            self._strategy_counts = raw.get("strategy_counts", {})
            log.info("loaded v2 state: %d buckets, %d logistic models",
                     len(self.state.buckets), len(self.state.logistic_models))
        except Exception as e:
            log.warning("v2 state load failed (%s) -- starting fresh", e)

    def save(self) -> None:
        try:
            STATE_FILE.write_text(json.dumps({
                "prior_alpha": self.state.prior_alpha,
                "prior_beta": self.state.prior_beta,
                "decay_factor": self.state.decay_factor,
                "buckets": {k: asdict(v) for k, v in self.state.buckets.items()},
                "logistic_models": {s: asdict(m)
                                    for s, m in self.state.logistic_models.items()},
                "strategy_counts": self._strategy_counts,
            }, indent=2))
        except Exception as e:
            log.error("v2 save failed: %s", e)

    # -- core API -------------------------------------------------------
    def confidence(self, setup: TradeSetup, context: ContextFeatures) -> float:
        """Blend Beta + Gaussian + logistic into a single 0..1 confidence."""
        key = self.state.bucket_key(
            strategy=setup.strategy, symbol=setup.symbol, side=setup.side,
            regime=context.regime_label,
            init_bucket=bucket_initial_move(setup.initial_move_pct),
            rev_bucket=bucket_reversal(setup.reversal_pct),
        )
        bs = self.state.get_or_create_bucket(key)

        # Beta posterior (L1)
        beta_p = bs.win_prob_mean if bs.trades >= self.min_trades_for_bucket else 0.5
        # Gaussian E[R] tilt (L2): map E[R] to [0, 1] via sigmoid-ish
        if bs.trades >= self.min_trades_for_bucket:
            r_score = 1.0 / (1.0 + math.exp(-bs.r_mean))   # E[R]=0 -> 0.5, +1 -> 0.73
        else:
            r_score = 0.5
        # Logistic on full context (L3)
        n_strat = self._strategy_counts.get(setup.strategy, 0)
        if n_strat >= self.min_trades_for_logistic:
            model = self.state.get_or_create_model(setup.strategy)
            log_p = model.predict_proba(context.to_vector())
            blend = 0.40 * beta_p + 0.25 * r_score + 0.35 * log_p
        else:
            blend = 0.55 * beta_p + 0.45 * r_score
        return float(min(1.0, max(0.0, blend)))

    def record_outcome(self, setup: TradeSetup, context: ContextFeatures,
                       r_pnl: float) -> None:
        key = self.state.bucket_key(
            strategy=setup.strategy, symbol=setup.symbol, side=setup.side,
            regime=context.regime_label,
            init_bucket=bucket_initial_move(setup.initial_move_pct),
            rev_bucket=bucket_reversal(setup.reversal_pct),
        )
        bs = self.state.get_or_create_bucket(key)

        # Decay (apply to "excess over prior") for L1
        d = self.state.decay_factor
        bs.alpha = (bs.alpha - self.state.prior_alpha) * d + self.state.prior_alpha
        bs.beta = (bs.beta - self.state.prior_beta) * d + self.state.prior_beta
        if r_pnl > 0:
            bs.alpha += 1.0
        else:
            bs.beta += 1.0

        # L2: decayed Welford-like update on R
        n = bs.trades
        # decay prior moments first
        bs.r_mean *= d
        bs.r_var *= d
        if n == 0:
            bs.r_mean = float(r_pnl)
            bs.r_var = 1.0
        else:
            new_mean = bs.r_mean + (r_pnl - bs.r_mean) / (n + 1)
            bs.r_var = bs.r_var + (r_pnl - bs.r_mean) * (r_pnl - new_mean)
            bs.r_mean = new_mean

        bs.trades += 1
        bs.sum_r += float(r_pnl)
        bs.last_ts = time.time()

        # L3: logistic SGD on the context vector
        model = self.state.get_or_create_model(setup.strategy)
        x = context.to_vector()
        y = 1 if r_pnl > 0 else 0
        model.update(x, y)
        self._strategy_counts[setup.strategy] = self._strategy_counts.get(setup.strategy, 0) + 1

        log.info("v2 update %s -> alpha=%.2f beta=%.2f trades=%d r_mean=%.3f "
                 "log_n=%d", key, bs.alpha, bs.beta, bs.trades, bs.r_mean,
                 model.n_updates)
        self.save()

    # -- introspection --------------------------------------------------
    def bucket_stats(self, setup: TradeSetup, context: ContextFeatures) -> dict:
        key = self.state.bucket_key(
            strategy=setup.strategy, symbol=setup.symbol, side=setup.side,
            regime=context.regime_label,
            init_bucket=bucket_initial_move(setup.initial_move_pct),
            rev_bucket=bucket_reversal(setup.reversal_pct),
        )
        bs = self.state.get_or_create_bucket(key)
        return {
            "key": key,
            "alpha": bs.alpha, "beta": bs.beta, "trades": bs.trades,
            "win_prob_mean": bs.win_prob_mean,
            "r_mean": bs.r_mean, "r_var": bs.r_var,
            "avg_r": bs.avg_r,
        }
