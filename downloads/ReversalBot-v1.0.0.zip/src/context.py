"""Context feature builder for the contextual-bandit learner (L3).

Takes the raw data for one symbol at decision time and produces a flat
feature vector that L3 (logistic regression) can consume.

Features intentionally span three *independent* axes:
  1. setup geometry      init_pct, rev_pct, atr_pct, sl_distance_pct
  2. macro regime        btc_trend_signal, vol_zscore, regime_confluence
  3. positioning/flow    funding_zscore, oi_change_pct, cvd_div_score
  4. seasonality         hour_of_day_utc (sin/cos), day_of_week (sin/cos)

The output is both a dict (for logging/DB) and an ordered numpy vector
(for the model). Feature order is FIXED by `FEATURE_ORDER` — never reorder
without re-training the learner.
"""
from __future__ import annotations
import math
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional

import numpy as np
import pandas as pd

from .regime import Regime, confluence_with_setup_side


FEATURE_ORDER: tuple[str, ...] = (
    "init_pct",
    "rev_pct",
    "atr_pct",
    "sl_distance_pct",
    "btc_trend_signal",
    "vol_zscore",
    "regime_confluence",
    "funding_zscore",
    "oi_change_pct",
    "cvd_div_score",
    "hour_sin",
    "hour_cos",
    "dow_sin",
    "dow_cos",
)


@dataclass
class ContextFeatures:
    init_pct: float = 0.0
    rev_pct: float = 0.0
    atr_pct: float = 0.0
    sl_distance_pct: float = 0.0
    btc_trend_signal: float = 0.0
    vol_zscore: float = 0.0
    regime_confluence: float = 0.0
    funding_zscore: float = 0.0
    oi_change_pct: float = 0.0
    cvd_div_score: float = 0.0
    hour_sin: float = 0.0
    hour_cos: float = 0.0
    dow_sin: float = 0.0
    dow_cos: float = 0.0
    # Non-feature metadata for DB
    regime_label: str = "unknown"
    funding_rate_now: float = 0.0
    extras: dict = field(default_factory=dict)

    def to_vector(self) -> np.ndarray:
        return np.array([getattr(self, k) for k in FEATURE_ORDER], dtype=float)

    def to_dict(self) -> dict:
        return {
            **{k: round(getattr(self, k), 4) for k in FEATURE_ORDER},
            "regime_label": self.regime_label,
            "funding_rate_now": round(self.funding_rate_now, 6),
            **self.extras,
        }


def atr_pct(df_intraday: pd.DataFrame, period: int = 14) -> float:
    """ATR(period) as % of latest close. Wilder-ish (rolling mean of TR)."""
    if df_intraday is None or len(df_intraday) < period + 1:
        return 0.0
    high = df_intraday["high"]
    low = df_intraday["low"]
    close = df_intraday["close"]
    prev_close = close.shift(1)
    tr = pd.concat([(high - low),
                    (high - prev_close).abs(),
                    (low - prev_close).abs()], axis=1).max(axis=1)
    atr = tr.rolling(period).mean().iloc[-1]
    last = float(close.iloc[-1])
    if last <= 0 or pd.isna(atr):
        return 0.0
    return float(atr) / last * 100.0


def funding_zscore(funding_history: pd.DataFrame,
                  current_rate: Optional[float] = None) -> tuple[float, float]:
    """Returns (zscore, current_rate). zscore is over the rolling history."""
    if funding_history is None or funding_history.empty:
        return 0.0, float(current_rate or 0.0)
    rates = funding_history["funding_rate"].astype(float)
    cur = float(current_rate) if current_rate is not None else float(rates.iloc[-1])
    mu, sd = float(rates.mean()), float(rates.std() or 1e-9)
    return (cur - mu) / sd, cur


def oi_change_pct(oi_history: pd.DataFrame, bars: int = 6) -> float:
    """OI % change over the last `bars` periods (default 30m at 5m bars)."""
    if oi_history is None or oi_history.empty or len(oi_history) < bars + 1:
        return 0.0
    cur = float(oi_history["oi"].iloc[-1])
    ref = float(oi_history["oi"].iloc[-bars - 1])
    if ref <= 0:
        return 0.0
    return (cur - ref) / ref * 100.0


def cvd_divergence_score(cvd_df: pd.DataFrame, side: str,
                         lookback: int = 30) -> float:
    """Detect price-vs-CVD divergence over the lookback window.

    Direction:
      SHORT setup (price topped) -> bearish divergence is BULLISH for our short:
        price made HIGHER high, CVD did NOT.
        score = +1 if strong, 0 if none.
      LONG setup (price bottomed) -> bullish divergence is GOOD:
        price made LOWER low, CVD did NOT.

    Implementation: compare slope of price vs slope of CVD in the window,
    normalized. Returns a value in roughly [-1, +1].
    """
    if cvd_df is None or len(cvd_df) < lookback:
        return 0.0
    window = cvd_df.iloc[-lookback:]
    px_first, px_last = float(window["close"].iloc[0]), float(window["close"].iloc[-1])
    cvd_first, cvd_last = float(window["cvd"].iloc[0]), float(window["cvd"].iloc[-1])
    if px_first <= 0:
        return 0.0
    px_change = (px_last - px_first) / px_first
    cvd_range = max(abs(window["cvd"].max() - window["cvd"].min()), 1e-9)
    cvd_change = (cvd_last - cvd_first) / cvd_range  # normalized to [-1, +1] range

    if side == "SHORT":
        # price up but CVD weak/down -> +ve score
        if px_change > 0:
            return float(np.clip(px_change * 100 - cvd_change, -1.0, 1.0))
        return 0.0
    else:  # LONG
        # price down but CVD weak/up -> +ve score
        if px_change < 0:
            return float(np.clip(-px_change * 100 + cvd_change, -1.0, 1.0))
        return 0.0


def _cyclical(value: float, period: float) -> tuple[float, float]:
    """Encode a cyclical variable as (sin, cos) to avoid 23h->0h discontinuity."""
    angle = 2 * math.pi * (value / period)
    return math.sin(angle), math.cos(angle)


def build_context(
    *,
    side: str,
    init_pct: float,
    rev_pct: float,
    sl_distance_pct: float,
    intraday_df: pd.DataFrame,
    regime: Optional[Regime],
    funding_now: Optional[float],
    funding_history: Optional[pd.DataFrame],
    oi_history: Optional[pd.DataFrame],
    cvd_df: Optional[pd.DataFrame],
    now_utc: Optional[datetime] = None,
) -> ContextFeatures:
    """Single entry point. Any missing input becomes 0 — model will learn
    that missing-data setups are noisier and weight accordingly."""
    now_utc = now_utc or datetime.now(timezone.utc)
    hsin, hcos = _cyclical(now_utc.hour + now_utc.minute / 60.0, 24.0)
    dsin, dcos = _cyclical(now_utc.weekday(), 7.0)

    fz, fnow = funding_zscore(funding_history, funding_now)
    oi_chg = oi_change_pct(oi_history)
    cvd_score = cvd_divergence_score(cvd_df, side) if cvd_df is not None else 0.0
    atr_p = atr_pct(intraday_df)
    reg_conf = confluence_with_setup_side(regime, side) if regime else 0.0

    return ContextFeatures(
        init_pct=float(init_pct),
        rev_pct=float(rev_pct),
        atr_pct=float(atr_p),
        sl_distance_pct=float(sl_distance_pct),
        btc_trend_signal=float(regime.trend_signal) if regime else 0.0,
        vol_zscore=float(regime.vol_zscore) if regime else 0.0,
        regime_confluence=float(reg_conf),
        funding_zscore=float(fz),
        oi_change_pct=float(oi_chg),
        cvd_div_score=float(cvd_score),
        hour_sin=hsin, hour_cos=hcos,
        dow_sin=dsin, dow_cos=dcos,
        regime_label=regime.label if regime else "unknown",
        funding_rate_now=float(fnow),
    )
