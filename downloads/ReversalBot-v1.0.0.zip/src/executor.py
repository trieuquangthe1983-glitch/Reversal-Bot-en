"""OKX testnet executor via ccxt.

Wraps the API to:
  - set leverage per symbol
  - place limit/market entry
  - attach SL + TP brackets
  - poll fill status
  - close positions
"""
from __future__ import annotations
import os
import time
from typing import Optional

import ccxt

from .playbook import TradeSetup
from .risk_manager import SizingResult
from .utils import setup_logger

log = setup_logger("executor")


class OKXExecutor:
    def __init__(self,
                 api_key: str | None = None,
                 api_secret: str | None = None,
                 passphrase: str | None = None,
                 testnet: bool = True,
                 dry_run: bool = True):
        self.dry_run = dry_run
        self.exchange = ccxt.okx({
            "apiKey": api_key or os.getenv("EXCHANGE_API_KEY"),
            "secret": api_secret or os.getenv("EXCHANGE_API_SECRET"),
            "password": passphrase or os.getenv("EXCHANGE_PASSPHRASE", ""),
            "enableRateLimit": True,
            "options": {"defaultType": "swap"},
        })
        if testnet:
            self.exchange.set_sandbox_mode(True)
        try:
            self.exchange.load_markets()
        except Exception as e:
            log.warning("could not load markets (will retry on first call): %s", e)

    # ------------------------------------------------------------------
    def set_leverage(self, symbol: str, leverage: int) -> None:
        if self.dry_run:
            log.info("[DRY] set_leverage %s -> %dx", symbol, leverage)
            return
        try:
            self.exchange.set_leverage(leverage, symbol, params={"mgnMode": "isolated"})
        except Exception as e:
            log.warning("set_leverage failed for %s: %s", symbol, e)

    def place_entry(self,
                    setup: TradeSetup,
                    sizing: SizingResult,
                    use_limit: bool = True,
                    limit_offset_bps: float = 5.0) -> dict:
        side_action = "sell" if setup.side == "SHORT" else "buy"
        if use_limit:
            offset = setup.entry * limit_offset_bps / 10000.0
            limit_price = setup.entry + (offset if setup.side == "SHORT" else -offset)
            order_type = "limit"
            price = limit_price
        else:
            order_type = "market"
            price = None

        params = {"tdMode": "isolated"}

        if self.dry_run:
            log.info("[DRY] place_entry %s %s %s qty=%s price=%s",
                     setup.symbol, side_action, order_type, sizing.contracts, price)
            return {"id": "DRY-RUN", "status": "open", "price": price}

        self.set_leverage(setup.symbol, sizing.leverage)
        order = self.exchange.create_order(
            symbol=setup.symbol,
            type=order_type,
            side=side_action,
            amount=sizing.contracts,
            price=price,
            params=params,
        )
        log.info("placed entry order %s", order.get("id"))
        return order

    def attach_brackets(self, setup: TradeSetup, sizing: SizingResult,
                        entry_order: dict | None = None) -> dict:
        """Place reduce-only TP and SL orders after entry is filled.

        `entry_order` is accepted for signature parity with GateioExecutor
        (which uses it to recover the converted contract qty); OKX ignores it.
        """
        _ = entry_order  # unused on OKX
        close_side = "buy" if setup.side == "SHORT" else "sell"
        results = {}
        legs = [
            ("sl", setup.sl, sizing.contracts),
            ("tp1", setup.tp1, sizing.contracts * 0.5),
            ("tp2", setup.tp2, sizing.contracts * 0.3),
            ("tp3", setup.tp3, sizing.contracts * 0.2),
        ]
        for name, price, qty in legs:
            if self.dry_run:
                log.info("[DRY] bracket %s %s @ %s qty=%s", name, close_side, price, qty)
                results[name] = {"id": f"DRY-{name}", "price": price}
                continue
            try:
                # OKX trigger order params
                params = {
                    "reduceOnly": True,
                    "tdMode": "isolated",
                    "ordType": "conditional",
                    "slTriggerPx": price if name == "sl" else None,
                    "tpTriggerPx": price if name.startswith("tp") else None,
                    "slOrdPx": -1 if name == "sl" else None,
                    "tpOrdPx": -1 if name.startswith("tp") else None,
                }
                params = {k: v for k, v in params.items() if v is not None}
                o = self.exchange.create_order(
                    symbol=setup.symbol,
                    type="limit",
                    side=close_side,
                    amount=qty,
                    price=price,
                    params=params,
                )
                results[name] = o
            except Exception as e:
                log.error("bracket %s failed: %s", name, e)
                results[name] = {"error": str(e)}
        return results

    # ------------------------------------------------------------------
    def wait_for_fill(self, order_id: str, symbol: str, timeout_s: int = 90) -> Optional[dict]:
        if self.dry_run:
            return {"id": order_id, "status": "filled", "filled": 1.0}
        deadline = time.time() + timeout_s
        while time.time() < deadline:
            try:
                o = self.exchange.fetch_order(order_id, symbol)
                if o.get("status") in {"closed", "filled"}:
                    return o
            except Exception as e:
                log.warning("fetch_order error: %s", e)
            time.sleep(2.0)
        return None

    def get_balance(self) -> float:
        if self.dry_run:
            return float(os.getenv("ACCOUNT_BALANCE_USDT", "10000"))
        try:
            bal = self.exchange.fetch_balance()
            usdt = bal.get("USDT", {})
            return float(usdt.get("free", 0.0))
        except Exception as e:
            log.warning("balance fetch failed: %s", e)
            return 0.0

    def get_open_positions(self) -> list[dict]:
        if self.dry_run:
            return []
        try:
            return self.exchange.fetch_positions()
        except Exception as e:
            log.warning("positions fetch failed: %s", e)
            return []

    def cancel_all_for_symbol(self, symbol: str) -> None:
        if self.dry_run:
            return
        try:
            self.exchange.cancel_all_orders(symbol)
        except Exception as e:
            log.warning("cancel_all failed for %s: %s", symbol, e)
