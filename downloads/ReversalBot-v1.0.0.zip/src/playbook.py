"""Converts a detected pattern into a concrete trade setup.

Supports two strategies:
  - reversal  (original daily GMT+7 reversal pattern)
  - ltr       (Liquidity Trap Reversal — sweep + rejection on HTF swing pool)

Both produce the same `TradeSetup` dataclass so the rest of the pipeline
(sizing, executor, learner, DB) doesn't have to branch on strategy.
"""
from __future__ import annotations
from dataclasses import dataclass, field

from .pattern_detector import ReversalPattern
from .ltr_detector import LTRPattern


@dataclass
class TradeSetup:
    symbol: str
    side: str                # "SHORT" or "LONG"
    entry: float
    sl: float
    tp1: float
    tp2: float
    tp3: float
    risk_pct: float          # SL distance as % of entry
    rr_at_tp1: float
    rr_at_tp2: float
    rr_at_tp3: float
    pattern_date: str
    initial_move_pct: float
    reversal_pct: float
    confidence: float        # 0..1 -- filled by learner
    strategy: str = "reversal"   # "reversal" | "ltr" | "confluence"
    notes: str = ""
    # LTR-specific extras (kept as a dict so DB columns stay flat)
    meta: dict = field(default_factory=dict)

    def as_dict(self) -> dict:
        d = self.__dict__.copy()
        # Don't leak the dict-typed meta into legacy callers that JSON it
        d["meta"] = dict(d.get("meta") or {})
        return d


def build_setup(
    pattern: ReversalPattern,
    sl_buffer_pct: float = 0.30,
    tp_r_multiples: tuple[float, ...] = (1.0, 2.0, 3.0),
) -> TradeSetup:
    """Pure function: given a reversal pattern, build a trade setup."""
    entry = pattern.trigger_price
    if pattern.side == "SHORT":
        sl = pattern.extreme * (1 + sl_buffer_pct / 100.0)
        risk_pct = (sl - entry) / entry * 100.0
        tp1 = entry - tp_r_multiples[0] * (sl - entry)
        tp2 = entry - tp_r_multiples[1] * (sl - entry)
        tp3 = entry - tp_r_multiples[2] * (sl - entry)
    else:
        sl = pattern.extreme * (1 - sl_buffer_pct / 100.0)
        risk_pct = (entry - sl) / entry * 100.0
        tp1 = entry + tp_r_multiples[0] * (entry - sl)
        tp2 = entry + tp_r_multiples[1] * (entry - sl)
        tp3 = entry + tp_r_multiples[2] * (entry - sl)

    return TradeSetup(
        symbol=pattern.symbol,
        side=pattern.side,
        entry=round(entry, 6),
        sl=round(sl, 6),
        tp1=round(tp1, 6),
        tp2=round(tp2, 6),
        tp3=round(tp3, 6),
        risk_pct=round(risk_pct, 3),
        rr_at_tp1=tp_r_multiples[0],
        rr_at_tp2=tp_r_multiples[1],
        rr_at_tp3=tp_r_multiples[2],
        pattern_date=pattern.date_gmt7,
        initial_move_pct=round(pattern.initial_move_pct, 3),
        reversal_pct=round(pattern.reversal_pct, 3),
        confidence=0.5,
        strategy="reversal",
    )


def build_ltr_setup(
    pattern: LTRPattern,
    sl_buffer_pct: float = 0.15,           # tighter than reversal — SL is invalidation-tight
    tp_r_multiples: tuple[float, ...] = (1.5, 3.0, 5.0),  # asymmetric R:R
) -> TradeSetup:
    """Build a trade setup from an LTR pattern.

    LTR philosophy: SL sits just outside the rejection wick (structural
    invalidation), entry is a retrace into the wick. The TP ladder is wider
    than reversal — the trap fuel powers larger moves on the wins.
    """
    entry = pattern.trigger_price
    if pattern.side == "SHORT":
        sl = pattern.sweep_extreme * (1 + sl_buffer_pct / 100.0)
        risk_pct = (sl - entry) / entry * 100.0
        tp1 = entry - tp_r_multiples[0] * (sl - entry)
        tp2 = entry - tp_r_multiples[1] * (sl - entry)
        tp3 = entry - tp_r_multiples[2] * (sl - entry)
    else:
        sl = pattern.sweep_extreme * (1 - sl_buffer_pct / 100.0)
        risk_pct = (entry - sl) / entry * 100.0
        tp1 = entry + tp_r_multiples[0] * (entry - sl)
        tp2 = entry + tp_r_multiples[1] * (entry - sl)
        tp3 = entry + tp_r_multiples[2] * (entry - sl)

    return TradeSetup(
        symbol=pattern.symbol,
        side=pattern.side,
        entry=round(entry, 6),
        sl=round(sl, 6),
        tp1=round(tp1, 6),
        tp2=round(tp2, 6),
        tp3=round(tp3, 6),
        risk_pct=round(risk_pct, 3),
        rr_at_tp1=tp_r_multiples[0],
        rr_at_tp2=tp_r_multiples[1],
        rr_at_tp3=tp_r_multiples[2],
        pattern_date=pattern.date_gmt7,
        initial_move_pct=round(pattern.initial_move_pct, 3),
        reversal_pct=round(pattern.reversal_pct, 3),
        confidence=0.5,
        strategy="ltr",
        meta={
            "swept_level": pattern.swept_level,
            "wick_pct": round(pattern.rejection_wick_pct, 3),
            "confluence_score": round(pattern.confluence_score, 3),
            "funding_zscore": round(pattern.funding_zscore, 3),
            "oi_change_pct": round(pattern.oi_change_pct, 3),
            "cvd_divergence_score": round(pattern.cvd_divergence_score, 3),
        },
    )


def combine_setups(rev: TradeSetup, ltr: TradeSetup) -> TradeSetup:
    """When reversal + LTR fire on the same symbol + same side at the same
    time, merge into a single 'confluence' setup that:
      - uses the BETTER entry (tighter -> smaller risk),
      - uses the TIGHTER SL,
      - keeps the WIDER TP ladder (LTR's),
      - inherits LTR's meta + a confluence flag.

    Caller must ensure rev.side == ltr.side and same symbol.
    """
    assert rev.side == ltr.side and rev.symbol == ltr.symbol, \
        "combine_setups: setups must match on symbol+side"

    if rev.side == "SHORT":
        # better entry = HIGHER for shorts (sell higher = closer to top)
        entry = max(rev.entry, ltr.entry)
        sl = min(rev.sl, ltr.sl)   # tighter = closer to entry from above? no, smaller SL
        # actually tighter for SHORT means SL closer to entry -> smaller (sl - entry).
        # min(rev.sl, ltr.sl) picks the lower SL — that's TIGHTER for shorts.
    else:
        # LONG: better entry = LOWER (buy cheaper)
        entry = min(rev.entry, ltr.entry)
        sl = max(rev.sl, ltr.sl)   # higher SL = tighter for LONG

    # Use LTR's wider TP ladder
    if rev.side == "SHORT":
        tp1 = entry - ltr.rr_at_tp1 * (sl - entry)
        tp2 = entry - ltr.rr_at_tp2 * (sl - entry)
        tp3 = entry - ltr.rr_at_tp3 * (sl - entry)
        risk_pct = (sl - entry) / entry * 100.0
    else:
        tp1 = entry + ltr.rr_at_tp1 * (entry - sl)
        tp2 = entry + ltr.rr_at_tp2 * (entry - sl)
        tp3 = entry + ltr.rr_at_tp3 * (entry - sl)
        risk_pct = (entry - sl) / entry * 100.0

    meta = dict(ltr.meta or {})
    meta["confluence"] = True
    meta["reversal_init_pct"] = rev.initial_move_pct
    meta["reversal_pct_orig"] = rev.reversal_pct

    return TradeSetup(
        symbol=rev.symbol, side=rev.side,
        entry=round(entry, 6), sl=round(sl, 6),
        tp1=round(tp1, 6), tp2=round(tp2, 6), tp3=round(tp3, 6),
        risk_pct=round(risk_pct, 3),
        rr_at_tp1=ltr.rr_at_tp1, rr_at_tp2=ltr.rr_at_tp2, rr_at_tp3=ltr.rr_at_tp3,
        pattern_date=rev.pattern_date,
        initial_move_pct=rev.initial_move_pct,
        reversal_pct=rev.reversal_pct,
        confidence=0.5,    # learner will overwrite
        strategy="confluence",
        meta=meta,
    )
