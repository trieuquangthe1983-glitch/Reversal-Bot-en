"""Historical & live OHLCV fetcher via ccxt.

Binance is used for historical data (free, no key, broadest coverage).
OKX is used for live execution. We can also poll OKX for live OHLCV.

Extensions for LTR strategy:
  - fetch_funding_rate / fetch_open_interest / compute_tick_rule_cvd are
    sourced from Binance USD-margined futures (`binanceusdm`) which is the
    most liquid reference perp regardless of which exchange the bot trades on.
"""
from __future__ import annotations
import time
from pathlib import Path
from typing import Iterable, Optional

import ccxt
import pandas as pd

from .utils import PROJECT_ROOT, setup_logger, ensure_dir

log = setup_logger("data_fetcher")
DATA_DIR = ensure_dir(PROJECT_ROOT / "data")


def _spot_to_perp(symbol: str) -> str:
    """Convert 'BTC/USDT' -> 'BTC/USDT:USDT' (ccxt unified perp format)."""
    if ":" in symbol:
        return symbol
    if "/" in symbol:
        base_quote = symbol
    else:
        return symbol
    quote = base_quote.split("/")[1]
    return f"{base_quote}:{quote}"


class DataFetcher:
    """Caches OHLCV to parquet in data/. Re-fetches only missing tail."""

    _perp_ex: Optional[ccxt.Exchange] = None  # class-level shared perp client

    def __init__(self, exchange_id: str = "binance"):
        self.exchange_id = exchange_id
        ex_class = getattr(ccxt, exchange_id)
        self.exchange = ex_class({"enableRateLimit": True})
        self.exchange.load_markets()

    @classmethod
    def _get_perp(cls) -> ccxt.Exchange:
        """Lazily create the binanceusdm client used for funding/OI/CVD."""
        if cls._perp_ex is None:
            cls._perp_ex = ccxt.binanceusdm({"enableRateLimit": True})
            try:
                cls._perp_ex.load_markets()
            except Exception as e:
                log.warning("binanceusdm load_markets failed: %s", e)
        return cls._perp_ex

    # -- public API -----------------------------------------------------
    def fetch_history(
        self,
        symbol: str,
        timeframe: str = "1h",
        days: int = 730,
        force_refresh: bool = False,
    ) -> pd.DataFrame:
        """Return DataFrame indexed by UTC datetime with columns
        ['open', 'high', 'low', 'close', 'volume']."""
        cache_path = self._cache_path(symbol, timeframe)
        if cache_path.exists() and not force_refresh:
            df = pd.read_parquet(cache_path)
            log.info("loaded %d bars from cache %s", len(df), cache_path.name)
            # incremental update from last bar
            last = df.index.max()
            now = pd.Timestamp.utcnow().tz_localize(None)
            if (now - last) > self._tf_to_timedelta(timeframe):
                fresh = self._fetch_since(symbol, timeframe, last + self._tf_to_timedelta(timeframe))
                if not fresh.empty:
                    df = pd.concat([df, fresh])
                    df = df[~df.index.duplicated(keep="last")].sort_index()
                    df.to_parquet(cache_path)
            return df

        # full fetch
        since = pd.Timestamp.utcnow().tz_localize(None) - pd.Timedelta(days=days)
        df = self._fetch_since(symbol, timeframe, since)
        df.to_parquet(cache_path)
        log.info("cached %d bars to %s", len(df), cache_path.name)
        return df

    def fetch_recent(self, symbol: str, timeframe: str = "1h", limit: int = 48) -> pd.DataFrame:
        """For the live bot: just last `limit` bars, uncached."""
        ohlcv = self.exchange.fetch_ohlcv(symbol, timeframe=timeframe, limit=limit)
        return self._to_df(ohlcv)

    # -- internal -------------------------------------------------------
    def _fetch_since(self, symbol: str, timeframe: str, since: pd.Timestamp) -> pd.DataFrame:
        since_ms = int(since.timestamp() * 1000)
        all_rows: list[list[float]] = []
        tf_ms = int(self._tf_to_timedelta(timeframe).total_seconds() * 1000)
        limit = 1000
        while True:
            try:
                batch = self.exchange.fetch_ohlcv(symbol, timeframe=timeframe, since=since_ms, limit=limit)
            except ccxt.BadSymbol:
                log.warning("symbol %s not listed on %s -- skipping", symbol, self.exchange_id)
                return pd.DataFrame()
            except Exception as e:
                log.warning("fetch error %s; retrying after 2s", e)
                time.sleep(2.0)
                continue
            if not batch:
                break
            all_rows.extend(batch)
            last_ts = batch[-1][0]
            if last_ts <= since_ms:
                break
            since_ms = last_ts + tf_ms
            if len(batch) < limit:
                break
            time.sleep(self.exchange.rateLimit / 1000.0)
        return self._to_df(all_rows)

    @staticmethod
    def _to_df(rows: Iterable) -> pd.DataFrame:
        if not rows:
            return pd.DataFrame(columns=["open", "high", "low", "close", "volume"])
        df = pd.DataFrame(rows, columns=["ts", "open", "high", "low", "close", "volume"])
        df["ts"] = pd.to_datetime(df["ts"], unit="ms", utc=True).dt.tz_localize(None)
        return df.set_index("ts").sort_index()

    @staticmethod
    def _tf_to_timedelta(tf: str) -> pd.Timedelta:
        unit = tf[-1]
        n = int(tf[:-1])
        return {"m": pd.Timedelta(minutes=n), "h": pd.Timedelta(hours=n), "d": pd.Timedelta(days=n)}[unit]

    def _cache_path(self, symbol: str, timeframe: str) -> Path:
        safe = symbol.replace("/", "_").replace("-", "_")
        return DATA_DIR / f"{self.exchange_id}_{safe}_{timeframe}.parquet"

    # -- LTR support: funding / OI / CVD --------------------------------
    # All sourced from binanceusdm (most liquid reference perp).
    def fetch_funding_rate(self, symbol: str) -> Optional[float]:
        """Latest funding rate for the perp of `symbol` (spot format).
        Returns None on failure. Rate is fraction (e.g. 0.0001 = 1bp)."""
        perp = self._get_perp()
        try:
            data = perp.fetch_funding_rate(_spot_to_perp(symbol))
            return float(data.get("fundingRate", 0.0))
        except Exception as e:
            log.debug("funding fetch failed %s: %s", symbol, e)
            return None

    def fetch_funding_history(self, symbol: str, limit: int = 30) -> pd.DataFrame:
        """Recent funding-rate history (8h candles on most perps)."""
        perp = self._get_perp()
        try:
            rows = perp.fetch_funding_rate_history(_spot_to_perp(symbol), limit=limit)
        except Exception as e:
            log.debug("funding history failed %s: %s", symbol, e)
            return pd.DataFrame(columns=["funding_rate"])
        if not rows:
            return pd.DataFrame(columns=["funding_rate"])
        df = pd.DataFrame([{"ts": r["timestamp"],
                           "funding_rate": r.get("fundingRate", 0.0)}
                          for r in rows])
        df["ts"] = pd.to_datetime(df["ts"], unit="ms", utc=True).dt.tz_localize(None)
        return df.set_index("ts").sort_index()

    def fetch_open_interest(self, symbol: str) -> Optional[float]:
        """Latest OI (in contracts) for the perp of `symbol`."""
        perp = self._get_perp()
        try:
            data = perp.fetch_open_interest(_spot_to_perp(symbol))
            return float(data.get("openInterestAmount") or
                         data.get("openInterest") or 0.0)
        except Exception as e:
            log.debug("OI fetch failed %s: %s", symbol, e)
            return None

    def fetch_open_interest_history(self, symbol: str, timeframe: str = "5m",
                                    limit: int = 30) -> pd.DataFrame:
        """OI history. binanceusdm supports fetchOpenInterestHistory."""
        perp = self._get_perp()
        try:
            rows = perp.fetch_open_interest_history(
                _spot_to_perp(symbol), timeframe=timeframe, limit=limit,
            )
        except Exception as e:
            log.debug("OI history failed %s: %s", symbol, e)
            return pd.DataFrame(columns=["oi"])
        if not rows:
            return pd.DataFrame(columns=["oi"])
        df = pd.DataFrame([{"ts": r.get("timestamp"),
                           "oi": float(r.get("openInterestAmount") or
                                      r.get("openInterest") or 0.0)}
                          for r in rows if r.get("timestamp")])
        if df.empty:
            return df
        df["ts"] = pd.to_datetime(df["ts"], unit="ms", utc=True).dt.tz_localize(None)
        return df.set_index("ts").sort_index()

    def compute_tick_rule_cvd(self, symbol: str, timeframe: str = "1m",
                              limit: int = 60) -> pd.DataFrame:
        """Approximate CVD from OHLCV via tick rule:
            if close > open:  +volume   (aggressor buyer)
            if close < open:  -volume   (aggressor seller)
            if close == open: 0
        Returns DataFrame with columns [close, signed_vol, cvd]."""
        perp = self._get_perp()
        try:
            ohlcv = perp.fetch_ohlcv(_spot_to_perp(symbol),
                                     timeframe=timeframe, limit=limit)
        except Exception as e:
            log.debug("tick-rule fetch failed %s: %s", symbol, e)
            return pd.DataFrame(columns=["close", "signed_vol", "cvd"])
        if not ohlcv:
            return pd.DataFrame(columns=["close", "signed_vol", "cvd"])
        df = pd.DataFrame(ohlcv, columns=["ts", "open", "high", "low",
                                          "close", "volume"])
        df["ts"] = pd.to_datetime(df["ts"], unit="ms", utc=True).dt.tz_localize(None)
        df = df.set_index("ts").sort_index()
        sign = (df["close"] > df["open"]).astype(int) - (df["close"] < df["open"]).astype(int)
        df["signed_vol"] = sign * df["volume"]
        df["cvd"] = df["signed_vol"].cumsum()
        return df[["close", "signed_vol", "cvd"]]
