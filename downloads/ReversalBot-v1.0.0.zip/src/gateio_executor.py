"""Gate.io USDT-perpetual executor via ccxt.

Mirrors the OKXExecutor interface so the bot can swap exchanges via a
factory. Specifics for Gate.io:

  - Account: ccxt `defaultType=swap`, `defaultSettle=usdt`. If the user
    has enabled Unified Account (Portfolio Margin) on Gate.io's UI, spot
    and futures share one collateral pool; we fetch that pool via
    `params={'unifiedAccount': True}` on fetch_balance.
  - Margin mode: ISOLATED per-symbol. Set via set_margin_mode before
    placing the order, and `marginMode='isolated'` on every order.
  - Leverage: default 15x; configurable.
  - Quantity: Gate.io futures are quoted in CONTRACTS, not coin. Each
    contract = `market['contractSize']` coin units (e.g. BTC/USDT:USDT
    has contractSize=0.0001 BTC). We convert `sizing.contracts`
    (coin-denominated, from risk_manager) -> gate contracts, then
    amount_to_precision().
  - Symbol format: unified ccxt `BTC/USDT:USDT`. The watchlist's
    `gateio_symbol` column stores this.
  - SL/TP: attached via ccxt unified `stopLossPrice` / `takeProfitPrice`
    params with reduceOnly=True.
"""
from __future__ import annotations
import os
import time
from typing import Optional

import ccxt

from .playbook import TradeSetup
from .risk_manager import SizingResult
from .utils import setup_logger

log = setup_logger("gateio_executor")


class OrderRejectedByExchange(RuntimeError):
    """Raised when min-size, leverage, or precision causes the order to be
    refused — caller should skip rather than treat as a transient error."""


class GateioExecutor:
    DEFAULT_LEVERAGE = 15
    DEFAULT_MARGIN_MODE = "isolated"

    def __init__(self,
                 api_key: str | None = None,
                 api_secret: str | None = None,
                 passphrase: str | None = None,    # unused; kept for signature parity
                 testnet: bool = True,
                 dry_run: bool = True,
                 default_leverage: int | None = None,
                 unified_account: bool = True):
        self.dry_run = dry_run
        self.default_leverage = default_leverage or self.DEFAULT_LEVERAGE
        self.unified_account = unified_account
        self.exchange = ccxt.gateio({
            "apiKey": api_key or os.getenv("EXCHANGE_API_KEY"),
            "secret": api_secret or os.getenv("EXCHANGE_API_SECRET"),
            "enableRateLimit": True,
            "options": {
                "defaultType": "swap",
                "defaultSettle": "usdt",
                "createMarketBuyOrderRequiresPrice": False,
            },
        })
        if testnet:
            self.exchange.set_sandbox_mode(True)
        try:
            self.exchange.load_markets()
        except Exception as e:
            log.warning("could not load markets (will retry on first call): %s", e)
        self._leverage_set: set[str] = set()
        self._margin_mode_set: set[str] = set()

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    def _market(self, symbol: str) -> dict:
        try:
            return self.exchange.market(symbol)
        except Exception:
            self.exchange.load_markets(reload=True)
            return self.exchange.market(symbol)

    def _coin_to_contracts(self, symbol: str, coin_qty: float) -> float:
        """Convert coin-denominated qty -> Gate.io contract qty, rounded
        to the exchange's amount precision."""
        m = self._market(symbol)
        contract_size = float(m.get("contractSize") or 1.0)
        if contract_size <= 0:
            contract_size = 1.0
        raw = coin_qty / contract_size
        try:
            return float(self.exchange.amount_to_precision(symbol, raw))
        except Exception:
            return round(raw, 4)

    def _ensure_margin_isolated(self, symbol: str) -> None:
        if symbol in self._margin_mode_set or self.dry_run:
            return
        try:
            self.exchange.set_margin_mode(self.DEFAULT_MARGIN_MODE, symbol,
                                          params={"leverage": self.default_leverage})
            log.info("set margin_mode=isolated for %s", symbol)
        except ccxt.ExchangeError as e:
            # Gate.io often returns "POSITION_HOLDING" or "no change" -- harmless
            msg = str(e).lower()
            if "no change" in msg or "holding" in msg or "already" in msg:
                pass
            else:
                log.warning("set_margin_mode failed for %s: %s", symbol, e)
        except Exception as e:
            log.warning("set_margin_mode unexpected error for %s: %s", symbol, e)
        self._margin_mode_set.add(symbol)

    # ------------------------------------------------------------------
    # Public API (mirrors OKXExecutor)
    # ------------------------------------------------------------------
    def set_leverage(self, symbol: str, leverage: int) -> None:
        lev = int(leverage or self.default_leverage)
        if self.dry_run:
            log.info("[DRY] set_leverage %s -> %dx", symbol, lev)
            return
        self._ensure_margin_isolated(symbol)
        try:
            self.exchange.set_leverage(lev, symbol,
                                       params={"marginMode": self.DEFAULT_MARGIN_MODE})
            self._leverage_set.add(symbol)
        except Exception as e:
            log.warning("set_leverage failed for %s: %s", symbol, e)

    def place_entry(self,
                    setup: TradeSetup,
                    sizing: SizingResult,
                    use_limit: bool = True,
                    limit_offset_bps: float = 5.0) -> dict:
        side_action = "sell" if setup.side == "SHORT" else "buy"
        if use_limit:
            offset = setup.entry * limit_offset_bps / 10000.0
            limit_price = setup.entry + (offset if setup.side == "SHORT" else -offset)
            order_type = "limit"
            price = limit_price
        else:
            order_type = "market"
            price = None

        gate_contracts = self._coin_to_contracts(setup.symbol, sizing.contracts)
        if gate_contracts <= 0:
            raise OrderRejectedByExchange(
                f"{setup.symbol}: sizing.contracts={sizing.contracts} -> 0 gate "
                f"contracts after rounding (contractSize too large for size)")

        if self.dry_run:
            log.info("[DRY] place_entry %s %s %s qty=%s (coin=%s) price=%s lev=%dx",
                     setup.symbol, side_action, order_type, gate_contracts,
                     sizing.contracts, price, sizing.leverage or self.default_leverage)
            return {"id": "DRY-RUN", "status": "open", "price": price,
                    "filled": gate_contracts, "contracts": gate_contracts}

        self.set_leverage(setup.symbol, sizing.leverage or self.default_leverage)
        params = {
            "marginMode": self.DEFAULT_MARGIN_MODE,
            "reduceOnly": False,
        }
        # Retry transient network errors up to 3 times with backoff.
        # NOT retried: InvalidOrder (caller logic problem, not network).
        last_err: Exception | None = None
        for attempt in range(3):
            try:
                order = self.exchange.create_order(
                    symbol=setup.symbol,
                    type=order_type,
                    side=side_action,
                    amount=gate_contracts,
                    price=price,
                    params=params,
                )
                break
            except ccxt.InvalidOrder as e:
                raise OrderRejectedByExchange(f"{setup.symbol}: {e}") from e
            except (ccxt.NetworkError, ccxt.ExchangeNotAvailable,
                    ccxt.RequestTimeout) as e:
                last_err = e
                backoff = 2 ** attempt   # 1s, 2s, 4s
                log.warning("place_entry network error (attempt %d/3): %s — "
                            "retrying in %ds", attempt + 1, e, backoff)
                time.sleep(backoff)
        else:
            raise OrderRejectedByExchange(
                f"{setup.symbol}: 3 network retries exhausted: {last_err}")
        log.info("placed entry order %s qty=%s", order.get("id"), gate_contracts)
        # Stash converted qty so attach_brackets re-uses it
        order["_gate_contracts"] = gate_contracts
        return order

    def attach_brackets(self, setup: TradeSetup, sizing: SizingResult,
                        entry_order: dict | None = None) -> dict:
        """Place reduce-only TP and SL orders after entry is filled.

        Gate.io accepts ccxt-unified `stopLossPrice` / `takeProfitPrice`
        params on a reduce-only limit order to create a server-side
        trigger.
        """
        close_side = "buy" if setup.side == "SHORT" else "sell"
        results: dict = {}
        # Re-use converted qty so SL/TP match the filled entry size
        if entry_order and "_gate_contracts" in entry_order:
            total_contracts = float(entry_order["_gate_contracts"])
        else:
            total_contracts = self._coin_to_contracts(setup.symbol, sizing.contracts)

        legs = [
            ("sl", setup.sl, total_contracts, "stopLossPrice"),
            ("tp1", setup.tp1, total_contracts * 0.5, "takeProfitPrice"),
            ("tp2", setup.tp2, total_contracts * 0.3, "takeProfitPrice"),
            ("tp3", setup.tp3, total_contracts * 0.2, "takeProfitPrice"),
        ]
        for name, trigger_price, qty, trigger_key in legs:
            try:
                qty_p = float(self.exchange.amount_to_precision(setup.symbol, qty))
            except Exception:
                qty_p = round(qty, 4)
            if qty_p <= 0:
                log.warning("bracket %s skipped: rounded qty=0", name)
                continue
            if self.dry_run:
                log.info("[DRY] bracket %s %s qty=%s trigger=%s",
                         name, close_side, qty_p, trigger_price)
                results[name] = {"id": f"DRY-{name}", "price": trigger_price}
                continue
            try:
                params = {
                    "reduceOnly": True,
                    "marginMode": self.DEFAULT_MARGIN_MODE,
                    trigger_key: float(trigger_price),
                }
                o = self.exchange.create_order(
                    symbol=setup.symbol,
                    type="market",
                    side=close_side,
                    amount=qty_p,
                    price=None,
                    params=params,
                )
                results[name] = o
            except Exception as e:
                log.error("bracket %s failed: %s", name, e)
                results[name] = {"error": str(e)}
        return results

    # ------------------------------------------------------------------
    def wait_for_fill(self, order_id: str, symbol: str, timeout_s: int = 90) -> Optional[dict]:
        if self.dry_run:
            return {"id": order_id, "status": "filled", "filled": 1.0}
        deadline = time.time() + timeout_s
        while time.time() < deadline:
            try:
                o = self.exchange.fetch_order(order_id, symbol)
                if o.get("status") in {"closed", "filled"}:
                    return o
            except Exception as e:
                log.warning("fetch_order error: %s", e)
            time.sleep(2.0)
        return None

    def get_balance(self) -> float:
        """Returns free USDT. If unified_account, reads from the unified
        cross-product pool; else reads the swap subaccount."""
        if self.dry_run:
            return float(os.getenv("ACCOUNT_BALANCE_USDT", "10000"))
        try:
            if self.unified_account:
                try:
                    bal = self.exchange.fetch_balance(params={"unifiedAccount": True})
                except Exception:
                    bal = self.exchange.fetch_balance()
            else:
                bal = self.exchange.fetch_balance()
            usdt = bal.get("USDT", {})
            return float(usdt.get("free", 0.0) or 0.0)
        except Exception as e:
            log.warning("balance fetch failed: %s", e)
            return 0.0

    def get_open_positions(self) -> list[dict]:
        if self.dry_run:
            return []
        try:
            return self.exchange.fetch_positions()
        except Exception as e:
            log.warning("positions fetch failed: %s", e)
            return []

    def cancel_all_for_symbol(self, symbol: str) -> None:
        if self.dry_run:
            return
        try:
            self.exchange.cancel_all_orders(symbol)
        except Exception as e:
            log.warning("cancel_all failed for %s: %s", symbol, e)
