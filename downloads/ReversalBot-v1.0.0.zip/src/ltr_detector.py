"""Liquidity Trap Reversal (LTR) detector.

Concept
-------
Big players hunt obvious liquidity pools (swing highs/lows, equal H/L, round
numbers). When price *sweeps* a pool then immediately rejects without
follow-through, the breakout buyers/sellers who entered the sweep are trapped.
We fade them — entering as the trap closes.

Inputs (all needed; missing -> reject signal):
  - HTF bars (4h default): to find structural swing pool that just got swept
  - LTF bars (1h or 15m): to confirm rejection wick + close-back
  - Funding rate now & history: pressure check
  - Open Interest recent change: trap fuel check
  - CVD recent (tick-rule): divergence check

Output: `LTRPattern` analogous to `ReversalPattern`, so the rest of the
pipeline (playbook → sizing → executor) can consume it uniformly.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import timedelta
from typing import Optional

import numpy as np
import pandas as pd


@dataclass
class LTRPattern:
    symbol: str
    date_gmt7: str
    side: str                     # "SHORT" (sweep high) | "LONG" (sweep low)
    swept_level: float            # the swing high/low that got taken
    sweep_extreme: float          # the actual peak/valley of the sweep
    sweep_time_utc: pd.Timestamp
    close_back_price: float       # close of the rejection bar
    rejection_wick_pct: float     # wick portion of the bar (0..1)
    trigger_price: float          # bot's intended entry (limit at retrace)
    trigger_time_utc: pd.Timestamp
    funding_rate: float           # at signal time
    funding_zscore: float
    oi_change_pct: float          # OI delta around sweep
    cvd_divergence_score: float   # +1..-1
    confluence_score: float       # combined 0..1 quality score
    initial_move_pct: float = 0.0 # filler so it matches reversal interface
    reversal_pct: float = 0.0
    notes: str = ""

    def to_dict(self) -> dict:
        d = asdict(self)
        d["sweep_time_utc"] = pd.Timestamp(self.sweep_time_utc).isoformat()
        d["trigger_time_utc"] = pd.Timestamp(self.trigger_time_utc).isoformat()
        d["strategy"] = "ltr"
        return d


# ---------------------------------------------------------------------------
# Swing structure helpers
# ---------------------------------------------------------------------------
def find_swing_levels(htf_df: pd.DataFrame, lookback: int = 30,
                     pivot_window: int = 3) -> dict:
    """Identify the most recent significant swing high and swing low in the
    HTF window. A pivot is a bar whose high (low) is the max (min) within
    +/- pivot_window neighbors.

    Returns {'swing_high': float, 'swing_high_idx': Timestamp, 'swing_low': ..}
    """
    if htf_df is None or len(htf_df) < lookback:
        return {}
    window = htf_df.iloc[-lookback:]
    n = len(window)
    swing_high, swing_high_idx = None, None
    swing_low, swing_low_idx = None, None
    for i in range(pivot_window, n - pivot_window):
        hi = window["high"].iloc[i]
        lo = window["low"].iloc[i]
        left_hi = window["high"].iloc[i - pivot_window:i].max()
        right_hi = window["high"].iloc[i + 1:i + pivot_window + 1].max()
        if hi > left_hi and hi > right_hi:
            if swing_high is None or hi > swing_high:
                swing_high, swing_high_idx = float(hi), window.index[i]
        left_lo = window["low"].iloc[i - pivot_window:i].min()
        right_lo = window["low"].iloc[i + 1:i + pivot_window + 1].min()
        if lo < left_lo and lo < right_lo:
            if swing_low is None or lo < swing_low:
                swing_low, swing_low_idx = float(lo), window.index[i]
    out = {}
    if swing_high is not None:
        out["swing_high"] = swing_high
        out["swing_high_idx"] = swing_high_idx
    if swing_low is not None:
        out["swing_low"] = swing_low
        out["swing_low_idx"] = swing_low_idx
    return out


def detect_sweep_rejection(
    ltf_df: pd.DataFrame,
    swept_level: float,
    side: str,
    min_wick_ratio: float = 0.5,
    lookback_bars: int = 5,
) -> Optional[dict]:
    """Look at the last `lookback_bars` LTF candles for a sweep+rejection.

    SHORT side:
      bar.high > swept_level (sweep up) AND
      bar.close < swept_level (rejected back below) AND
      upper_wick / bar_range >= min_wick_ratio

    LONG side: symmetric.

    Returns dict {bar_idx, extreme, close, wick_pct} or None.
    """
    if ltf_df is None or len(ltf_df) < lookback_bars:
        return None
    recent = ltf_df.iloc[-lookback_bars:]
    for ts, bar in recent.iloc[::-1].iterrows():  # newest first
        o, h, l, c = float(bar["open"]), float(bar["high"]), float(bar["low"]), float(bar["close"])
        rng = max(h - l, 1e-9)
        if side == "SHORT":
            if h > swept_level and c < swept_level:
                upper_wick = h - max(o, c)
                if upper_wick / rng >= min_wick_ratio:
                    return {"bar_idx": ts, "extreme": h, "close": c,
                            "wick_pct": upper_wick / rng}
        else:  # LONG
            if l < swept_level and c > swept_level:
                lower_wick = min(o, c) - l
                if lower_wick / rng >= min_wick_ratio:
                    return {"bar_idx": ts, "extreme": l, "close": c,
                            "wick_pct": lower_wick / rng}
    return None


def _funding_pressure(funding_zscore: float, side: str) -> float:
    """Positive funding (longs paying) supports SHORT trap; negative supports LONG.
    Returns a [0, 1] score: how aligned funding is with our setup."""
    if side == "SHORT":
        # we want funding positive & elevated (longs trapped)
        return float(np.clip((funding_zscore - 0.0) / 2.0, 0.0, 1.0))
    else:
        return float(np.clip((-funding_zscore) / 2.0, 0.0, 1.0))


def _oi_pressure(oi_change_pct: float, side: str) -> float:
    """Positive OI growth during a sweep = fresh positions to liquidate.
    Aligned for either side (the trap direction is set by the sweep)."""
    return float(np.clip(oi_change_pct / 3.0, 0.0, 1.0))  # 3%+ -> full score


def _cvd_pressure(cvd_score: float) -> float:
    return float(np.clip(cvd_score, 0.0, 1.0))


def compute_confluence_score(
    funding_zscore: float,
    oi_change_pct: float,
    cvd_score: float,
    wick_pct: float,
    side: str,
    weights: tuple[float, float, float, float] = (0.30, 0.20, 0.30, 0.20),
) -> float:
    """Aggregate the 4 sub-signals into a 0..1 quality score.
    Weights default: funding 30%, OI 20%, CVD 30%, wick strength 20%.
    """
    f = _funding_pressure(funding_zscore, side)
    o = _oi_pressure(oi_change_pct, side)
    c = _cvd_pressure(cvd_score)
    w = float(np.clip((wick_pct - 0.5) / 0.5, 0.0, 1.0))  # 0.5..1.0 -> 0..1
    score = (weights[0] * f + weights[1] * o + weights[2] * c + weights[3] * w)
    return float(np.clip(score, 0.0, 1.0))


# ---------------------------------------------------------------------------
# Top-level detector
# ---------------------------------------------------------------------------
def check_ltr(
    *,
    symbol: str,
    htf_df: pd.DataFrame,
    ltf_df: pd.DataFrame,
    funding_rate: Optional[float],
    funding_zscore: float,
    oi_change_pct: float,
    cvd_score_short: float,
    cvd_score_long: float,
    htf_lookback: int = 30,
    pivot_window: int = 3,
    min_wick_ratio: float = 0.5,
    min_confluence: float = 0.45,
    retrace_to_entry: float = 0.50,
    sweep_recency_bars: int = 5,
) -> Optional[LTRPattern]:
    """Single-symbol live LTR check. Returns a pattern or None.

    `cvd_score_short` and `cvd_score_long` are computed externally (one of
    them will be picked depending on which side the sweep fires)."""
    if htf_df is None or htf_df.empty or ltf_df is None or ltf_df.empty:
        return None

    swings = find_swing_levels(htf_df, lookback=htf_lookback, pivot_window=pivot_window)

    # Try SHORT first (sweep up of swing high), then LONG.
    for side in ("SHORT", "LONG"):
        level_key = "swing_high" if side == "SHORT" else "swing_low"
        if level_key not in swings:
            continue
        swept_level = swings[level_key]
        sweep = detect_sweep_rejection(ltf_df, swept_level, side,
                                       min_wick_ratio=min_wick_ratio,
                                       lookback_bars=sweep_recency_bars)
        if sweep is None:
            continue

        cvd_score = cvd_score_short if side == "SHORT" else cvd_score_long
        confluence = compute_confluence_score(
            funding_zscore=funding_zscore,
            oi_change_pct=oi_change_pct,
            cvd_score=cvd_score,
            wick_pct=sweep["wick_pct"],
            side=side,
        )
        if confluence < min_confluence:
            continue

        # Compute trigger price: retrace of the rejection bar
        extreme = sweep["extreme"]
        close_back = sweep["close"]
        if side == "SHORT":
            trigger_price = close_back + (extreme - close_back) * retrace_to_entry
            init_move_pct = (extreme - swept_level) / swept_level * 100.0
            reversal_pct = (extreme - close_back) / extreme * 100.0
        else:
            trigger_price = close_back - (close_back - extreme) * retrace_to_entry
            init_move_pct = (swept_level - extreme) / swept_level * 100.0
            reversal_pct = (close_back - extreme) / extreme * 100.0

        ts = pd.Timestamp(sweep["bar_idx"])
        gmt7_date = (ts + timedelta(hours=7)).strftime("%Y-%m-%d")

        return LTRPattern(
            symbol=symbol,
            date_gmt7=gmt7_date,
            side=side,
            swept_level=float(swept_level),
            sweep_extreme=float(extreme),
            sweep_time_utc=ts,
            close_back_price=float(close_back),
            rejection_wick_pct=float(sweep["wick_pct"]),
            trigger_price=float(trigger_price),
            trigger_time_utc=ts,
            funding_rate=float(funding_rate or 0.0),
            funding_zscore=float(funding_zscore),
            oi_change_pct=float(oi_change_pct),
            cvd_divergence_score=float(cvd_score),
            confluence_score=float(confluence),
            initial_move_pct=float(init_move_pct),
            reversal_pct=float(reversal_pct),
        )
    return None
